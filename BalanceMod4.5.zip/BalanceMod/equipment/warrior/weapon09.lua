﻿-- chunkname: @equipment/warrior/weapon09.lua

return SettingsAux.override_settings("equipment/warrior/weapon11", {})
