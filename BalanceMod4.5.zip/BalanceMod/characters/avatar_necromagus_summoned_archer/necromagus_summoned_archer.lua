﻿-- chunkname: @characters/avatar_necromagus_summoned_archer/necromagus_summoned_archer.lua

local LIFETIME = 20
local DAMAGE = 10
local t = SettingsAux.override_settings("characters/enemy_base", {
	animation_driven_movement = true,
	bloodtype = "bone",
	discovery_disabled = true,
	enemy_type = "skeleton_archer",
	global_ability_cooldown = 1,
	hitpoints = 15,
	is_ranged_attacker = true,
	movespeed = 4,
	movespeed_0_to_100_duration = 1,
	preferred_distance = 12,
	preferred_distance_buffer = 0.5,
	preferred_distance_max = 25,
	preferred_distance_min = 8,
	refresh_target_time = 0.25,
	use_simple_mover = false,
	faction = {
		"good",
	},
	hit_reacts = require("characters/hit_reacts_fodder"),
	animation_merge_options = {
		clock_fidelity = 0.75,
		max_drift = 0.2,
		max_start_time = 0.2,
	},
	scale_info = {
		scale = 1.05,
		variation = 0.05,
	},
	spawn_info = {
		default = {
			animation = "awaken",
			duration = 25,
			flow_event_dormant = "spawn_generator",
			invincibility_duration = 8,
			wakeup_delay = 0,
		},
	},
	move_settings = {
		max_state_duration = 1.5,
		max_state_variation = 0,
		min_state_duration = 0.5,
		min_state_variation = 0,
	},
	instakill_on = {
		breaker = true,
	},
	ability_selection = {
		shoot_windup = {
			cooldown = 1,
			max_distance = 25,
			min_distance = 1,
			request_execution = true,
			use_target_unit = true,
			weight = 1,
		},
	},
	abilities = {
		spawn = {
			duration = 5,
			events = {
				{
					damage_amount = 0,
					damage_type = "lightning",
					effect_type = "axe",
					event_duration = 1,
					event_start = 1,
					friendly_fire = false,
					hit_react = "thrust_heavy",
					radius = 2,
					type = "sphere",
					origin = {
						x = 0,
						y = 0,
						z = 0,
					},
				},
			},
		},
		shoot_windup = {
			animation = "attack_shoot_windup",
			duration = 15,
			execute = true,
			target_type = "target_unit",
			flow_events = {},
			on_complete = {
				ability = "shoot",
			},
		},
		shoot = {
			animation = "attack_shoot",
			clear_target_unit = true,
			duration = 30,
			rotation_lock_start = 0,
			flow_events = {
				{
					event_name = "on_shoot",
					time = 0,
				},
				{
					event_name = "on_done",
					time = 30,
				},
			},
			events = {
				{
					angle = 0,
					damage_type = "pierce",
					duration = 1,
					effect_type = "arrow",
					event_start = 0,
					friendly_fire = false,
					hit_react = "thrust",
					radius = 0.8,
					speed = 50,
					speed_multiplier = 1,
					stagger_origin_type = "direction",
					type = "projectile",
					unit_path = "necromagus_summoned_archer_arrow",
					damage_amount = DAMAGE,
					origin = {
						x = -0.3,
						y = 1,
						z = 0,
					},
				},
			},
		},
	},
	gibs = {
		decapitated = {
			{
				node = "j_head",
				pitch = 130,
				pitch_variation = 10,
				power = 15,
				power_variation = 1,
				unit_path = "characters/avatar_necromagus_summoned_archer/gib/gib_head",
				yaw = 0,
				yaw_variation = 20,
			},
		},
		headshot = {
			{
				keep_attachment_weight = 1,
				node = "j_head",
				pitch = 0,
				pitch_variation = 0,
				power = 3000,
				power_variation = 1,
				unit_path = "characters/avatar_necromagus_summoned_archer/gib/gib_head",
				yaw = 0,
				yaw_variation = 0,
			},
		},
		exploded = {
			{
				amount = 1,
				node = "j_head",
				pitch = 130,
				pitch_variation = 10,
				power = 15,
				power_variation = 10,
				unit_path = "characters/avatar_necromagus_summoned_archer/gib/gib_head",
				yaw = 0,
				yaw_variation = 20,
			},
			{
				amount = 1,
				node = "j_spine3",
				pitch = 40,
				pitch_variation = 100,
				power = 10,
				power_variation = 10,
				unit_path = "characters/skeleton_soldier/gib_ribcage",
				yaw = 90,
				yaw_variation = 90,
			},
			{
				amount = 4,
				node = "j_spine3",
				pitch = 40,
				pitch_variation = 100,
				power = 15,
				power_variation = 10,
				unit_path = "characters/skeleton_soldier/gib_bone",
				yaw = 90,
				yaw_variation = 90,
			},
			{
				amount = 4,
				node = "j_hips",
				pitch = 40,
				pitch_variation = 100,
				power = 10,
				power_variation = 10,
				unit_path = "characters/skeleton_soldier/gib_bone",
				yaw = -90,
				yaw_variation = 90,
			},
		},
		blasted = {
			{
				amount = 1,
				node = "j_head",
				pitch = 0,
				pitch_variation = 20,
				power = 20,
				power_variation = 1,
				unit_path = "characters/avatar_necromagus_summoned_archer/gib/gib_head",
				yaw = 150,
				yaw_variation = 10,
			},
			{
				amount = 1,
				node = "j_spine3",
				pitch = 0,
				pitch_variation = 20,
				power = 15,
				power_variation = 1,
				unit_path = "gib_ribcage",
				yaw = 150,
				yaw_variation = 10,
			},
			{
				amount = 2,
				node = "j_spine3",
				pitch = 0,
				pitch_variation = 20,
				power = 15,
				power_variation = 1,
				unit_path = "gib_bone",
				yaw = 150,
				yaw_variation = 10,
			},
			{
				amount = 2,
				node = "j_hips",
				pitch = 0,
				pitch_variation = 20,
				power = 20,
				power_variation = 1,
				unit_path = "gib_bone",
				yaw = 150,
				yaw_variation = 10,
			},
		},
		split_vertical = {
			{
				amount = 1,
				node = "j_head",
				pitch = -90,
				pitch_variation = 10,
				power = 25,
				power_variation = 10,
				unit_path = "characters/avatar_necromagus_summoned_archer/gib/gib_head",
				yaw = 0,
				yaw_variation = 30,
			},
			{
				amount = 1,
				node = "j_spine3",
				pitch = -90,
				pitch_variation = 10,
				power = 5,
				power_variation = 10,
				unit_path = "characters/skeleton_soldier/gib_ribcage",
				yaw = 0,
				yaw_variation = 20,
			},
			{
				amount = 4,
				node = "j_spine3",
				pitch = -90,
				pitch_variation = 0,
				power = 15,
				power_variation = 20,
				unit_path = "characters/skeleton_soldier/gib_bone",
				yaw = 0,
				yaw_variation = 40,
			},
			{
				amount = 4,
				node = "j_hips",
				pitch = -90,
				pitch_variation = 40,
				power = 10,
				power_variation = 20,
				unit_path = "characters/skeleton_soldier/gib_bone",
				yaw = 0,
				yaw_variation = 90,
			},
		},
	},
})

t.on_created_by_ability = function (unit, parent_ability)
	if EntityAux.owned(unit) then
		local stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(parent_ability.owner_unit)

		Unit.set_data(unit, "stat_creditor_go_id", stat_creditor_go_id)
	end
end

t.on_entity_registered = function (unit)
	if EntityAux.owned(unit) then
		local command = TempTableFactory:get_map("ability_name", "spawn", "ability_event_listeners", nil)

		EntityAux.queue_command_master(unit, "ability", "execute_ability", command)

		local time_in_seconds = LIFETIME - 1 + math.random() * 2

		Game.scheduler:delay_action(time_in_seconds, function ()
			if Unit.alive(unit) then
				EntityAux.call_interface(unit, "i_hit_receiver", "hit", {
					damage_amount = 99999,
					settings = {
						hit_react = "push",
					},
					modifiers = {},
					direction = Vector3Aux.box_temp(-UnitAux.unit_forward(unit)),
					position = Vector3Aux.box_temp(Unit.world_position(unit, 0)),
					random_seed = math.random() * 1000,
				})
			end
		end)
	end
end

t.states = function (component)
	local cache_component_states = closure(StateCommon.cache_component_states, component)

	return StateCommonBuilderFodder.build_default_advanced(component, {
		attack = {
			on_enter = {
				closure(StateCommon.attack_enter_owned, component),
			},
			pre_transitions = {
				{
					action = closure(StateCommon.compulsory_checks, component),
				},
			},
			update = {
				closure(StateCommon.rotate_towards_target, component),
			},
			post_transitions = {
				{
					next_state = "select_action",
					action = closure(StateCommon.attack_update, component),
				},
			},
			on_exit = {},
		},
	}, t.start_state), cache_component_states
end

return t
