﻿-- chunkname: @characters/avatar_wizard/abilities/spell_storm_bomb_projectile.lua

local t = {
	abilities = {
		storm_bomb_detonate = {
			duration = 70,
			ignore_interrupt = true,
			events = {
				{
					behind_wall_test = true,
					breaker = true,
					damage_amount = 1,
					damage_type = "lightning",
					event_duration = 1,
					event_start = 55,
					hit_react = "thrust",
					ignore_rotation = true,
					on_enter_flow = "ability_first_wave",
					origin_type = "center",
					radius = 3,
					stagger_origin_type = "query",
					type = "sphere",
					faction = {
						"good",
					},
					origin = {
						x = 0,
						y = 0,
						z = 0,
					},
				},
				{
					behind_wall_test = true,
					breaker = true,
					damage_amount = 64,
					damage_hit_delay = 3,
					damage_type = "lightning",
					event_duration = 1,
					event_start = 60,
					hit_react = "shockwave",
					ignore_rotation = true,
					on_enter_flow = "ability_second_wave",
					origin_type = "center",
					radius = 3,
					stagger_origin_type = "query",
					type = "sphere",
					faction = {
						"good",
					},
					origin = {
						x = 0,
						y = 0,
						z = 0,
					},
				},
			},
			on_exit = {
				flow_event = "on_explode",
			},
		},
	},
}

t.on_created_by_ability = function (unit, parent_ability)
	if EntityAux.owned(unit) then
		local owner = parent_ability.owner_unit
		local command = TempTableFactory:get_map("ability_name", "storm_bomb_detonate", "owner_unit", owner)

		EntityAux.queue_command_master(unit, "ability", "execute_ability", command)
	end
end

return t
