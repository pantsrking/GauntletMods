﻿-- chunkname: @lua/components/static_pose_component.lua

require("foundation/lua/component/base_component")

StaticPoseComponent = class("StaticPoseComponent", "BaseComponent")

StaticPoseComponent.init = function (self, creation_context)
	BaseComponent.init(self, "static_pose", creation_context)
end

StaticPoseComponent.update = function ()
	return
end
