﻿-- chunkname: @lua/components/pickup_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/managers/broadphase_manager")

PickupComponent = class("PickupComponent", "BaseComponent")

PickupComponent.init = function (self, creation_context)
	BaseComponent.init(self, "pickup", creation_context)
	self:register_events("on_pickup_result")
	self:register_rpc_events("rpc_pickup_result", "rpc_pickup_request")
end

PickupComponent.destroy = function (self)
	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
	end

	BaseComponent.destroy(self)
end

PickupComponent.remove_slave = function (self, unit, context)
	BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
end

PickupComponent.reload_slave = function (self, unit, context)
	self:setup_reloadables(unit, context)

	if context.state.enabled then
		BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
		BroadphaseManager:add(InteractableComponent.BROADPHASE_ID, unit, UnitAux.unit_center(unit), context.state.radius)

		context.state.previous_enabled = true
	end
end

PickupComponent.setup_reloadables = function (self, unit, context)
	local state, settings = context.state, context.settings

	if settings.pickup_radius then
		state.radius = settings.pickup_radius
	else
		local extents = UnitAux.unit_extents(unit)

		state.radius = math.max(extents.x, extents.y)
		state.radius = math.max(state.radius, 0.5)
	end
end

PickupComponent.setup_slave = function (self, unit, context)
	local state, settings = context.state, context.settings

	self:setup_reloadables(unit, context)

	local delay = settings.pickup_enable_delay

	if delay and delay > 0 then
		state.enabled = false

		Game:delay_action(delay, function ()
			if EntityAux.is_alive_entity(unit) then
				state.enabled = true

				BroadphaseManager:add(InteractableComponent.BROADPHASE_ID, unit, UnitAux.unit_center(unit), state.radius)
			end
		end)
	else
		state.enabled = true

		BroadphaseManager:add(InteractableComponent.BROADPHASE_ID, unit, UnitAux.unit_center(unit), state.radius)
	end
end

PickupComponent.update = function (self, dt)
	return
end

PickupComponent.call_master_pickup_request = function (self, unit, context, interactor_unit)
	if not Unit.alive(interactor_unit) then
		return
	end

	local slave_state = EntityAux._state_raw(unit, self.name)
	local success = slave_state.enabled

	slave_state.enabled = false

	local settings_path = LuaSettingsManager:get_settings_path_by_unit_path(Unit.get_data(unit, "unit_path"))

	self:trigger_event("on_pickup_result", unit, interactor_unit, success, settings_path)
	self:trigger_rpc_event_to_others("rpc_pickup_result", unit, interactor_unit, success, settings_path)

	if success then
		self.scheduler:delay_action(0.2, function ()
			if EntityAux.is_alive_entity(unit) then
				self.entity_spawner:despawn_entity(unit)
			end
		end)
	end
end

PickupComponent.on_pickup_result = function (self, pickup_unit, interactor_unit, success, pickup_settings_path)
	if not interactor_unit then
		success = false
	end

	if pickup_unit then
		local settings = LuaSettingsManager:get_settings_by_settings_path(pickup_settings_path)

		settings.pickup_result(self, pickup_unit, interactor_unit, success)
	end
end

PickupComponent.rpc_pickup_request = function (self, sender, pickup_unit, interactor_unit, pickup_settings_path)
	if not pickup_unit then
		local success = false

		self:trigger_event("on_pickup_result", nil, interactor_unit, success, pickup_settings_path)
		self:trigger_rpc_event_to_others("rpc_pickup_result", nil, interactor_unit, success, pickup_settings_path)

		return
	end

	if not interactor_unit then
		return
	end

	self:call_master_pickup_request(pickup_unit, EntityAux._context_raw(pickup_unit, self.name), interactor_unit)
end

PickupComponent.rpc_pickup_result = function (self, sender, pickup_unit, interactor_unit, success, pickup_settings_path)
	if pickup_unit == nil then
		self:trigger_event("on_pickup_result", nil, interactor_unit, false, pickup_settings_path)

		return
	end

	if EntityAux.owner(pickup_unit) ~= sender then
		return
	end

	self:trigger_event("on_pickup_result", pickup_unit, interactor_unit, success, pickup_settings_path)
end
