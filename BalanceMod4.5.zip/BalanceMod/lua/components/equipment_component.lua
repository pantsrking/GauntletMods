﻿-- chunkname: @lua/components/equipment_component.lua

require("foundation/lua/component/base_component")
require("lua/settings/items")

EquipmentComponent = class("EquipmentComponent", "BaseComponent")
EQUIPMENT_SLOTS = {
	"head",
	"torso",
	"legs",
	"weapon",
	"shield",
	"relic",
	"talisman",
	"cape",
}

local SLOTS_MAP = table.make_bimap(EQUIPMENT_SLOTS)

EquipmentComponent.init = function (self, creation_context)
	BaseComponent.init(self, "equipment", creation_context)

	self.unit_paths = creation_context.unit_paths
end

EquipmentComponent.reload_master = function (self, unit, context)
	self.event_delegate:trigger("on_equipment_changed", unit)
end

EquipmentComponent.reload_slave = function (self, unit, context)
	local state = context.state
	local world = self.world_proxy:get_world()
	local slots = state.slots

	for eq_type, slot in pairs(slots) do
		if slot and Unit.alive(slot.unit) then
			UnitAux.unskin_item(slot.unit, world)
			EquipmentComponent.attach_item(world, unit, eq_type, slot.unit)
		end
	end
end

EquipmentComponent.attach_item = function (world, avatar_unit, eq_type, item_unit)
	if eq_type == "weapon" then
		local hero_settings = LuaSettingsManager:get_settings_by_unit(avatar_unit)
		local attach_joint = hero_settings.inventory.weapon[1].node
		local unit_attach_joint_index = Unit.node(avatar_unit, attach_joint)

		World.link_unit(world, item_unit, 0, avatar_unit, unit_attach_joint_index)
	elseif eq_type == "shield" then
		local hero_settings = LuaSettingsManager:get_settings_by_unit(avatar_unit)
		local attach_joint = hero_settings.inventory.shield_node
		local unit_attach_joint_index = Unit.node(avatar_unit, attach_joint)

		World.link_unit(world, item_unit, 0, avatar_unit, unit_attach_joint_index)
	else
		UnitAux.skin_item(avatar_unit, item_unit, world, false)
	end

	local num_cloths = Unit.num_cloths(item_unit)

	for ci = 1, num_cloths do
		local cloth = Unit.cloth(item_unit, ci - 1)

		Cloth.set_physical_lod(cloth, 1)
	end
end

local function setup_slots(state)
	local slots = {}

	for i, key in ipairs(EQUIPMENT_SLOTS) do
		slots[key] = {}
	end

	state.slots = slots
end

EquipmentComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	setup_slots(state)

	if setup_info then
		local loadout_ids = setup_info.loadout_ids

		if loadout_ids then
			local slave_state = EntityAux._state_raw(unit, self.name)

			for eq_type, item_id in pairs(setup_info.loadout_ids) do
				state[eq_type] = item_id
				slave_state[eq_type] = item_id
			end
		end

		self.event_delegate:trigger("on_equipment_changed", unit)
	end
end

EquipmentComponent.setup_slave = function (self, unit, context)
	local state = context.state

	setup_slots(state)
	self:update_slots_slave(unit, state)

	if EntityAux.owned(unit) then
		self.replicator:write_fields(EntityAux._context_master_raw(unit, self.name))
	end
end

EquipmentComponent.remove_slave = function (self, unit, context)
	local state = context.state
	local world = self.world_proxy:get_world()

	for item_type, slot in pairs(state.slots) do
		if Unit.alive(slot.unit) then
			World.destroy_unit(world, slot.unit)
		end

		slot.unit = nil
		slot.item_id = nil
	end
end

EquipmentComponent.call_master_set = function (self, unit, context, data)
	local state = context.state
	local eq_type = data.eq_type
	local item_id = data.item_id

	state[eq_type] = item_id
	state.dirty = true

	self.event_delegate:trigger("on_equipment_changed", unit)
end

EquipmentComponent.call_slave_drop_weapons = function (self, unit, context, data)
	local state = context.state

	for i, item_type in ipairs(data) do
		state.enabled = false

		local slot = state.slots[item_type]

		if slot.unit then
			Unit.flow_event(slot.unit, "dropped")
		end

		slot.unit = nil
	end
end

EquipmentComponent.update_cape_visibility = function (torso, cape, owner_unit)
	if torso then
		if cape then
			local settings = LuaSettingsManager:get_settings_by_unit(owner_unit)

			if settings.hide_torso_on_cape_equip == false then
				Unit.set_unit_visibility(torso, true)
			else
				local num_cloths = Unit.num_cloths(torso)

				for i = 1, num_cloths do
					Unit.set_cloth_visibility(torso, i - 1, false)
				end
			end

			Unit.set_unit_visibility(cape, false)

			local num_cloths = Unit.num_cloths(cape)

			for i = 1, num_cloths do
				Unit.set_cloth_visibility(cape, i - 1, true)
			end
		else
			local num_cloths = Unit.num_cloths(torso)

			for i = 1, num_cloths do
				Unit.set_cloth_visibility(torso, i - 1, true)
			end
		end

		if Unit.has_visibility_group(torso, "cape") then
			Unit.set_visibility(torso, "cape", false)
		end
	end
end

EquipmentComponent.update = function (self, dt)
	Profiler.start(self.name)

	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	self:update_slaves(slave_entities, dt)
	Profiler.stop()
end

EquipmentComponent.update_slots_slave = function (self, unit, state)
	if state.enabled == false then
		return
	end

	local slots = state.slots
	local changed = false

	for _, eq_type in ipairs(EQUIPMENT_SLOTS) do
		local item_id = state[eq_type]
		local slot = slots[eq_type]
		local slot_item_id = slot.item_id

		if item_id ~= slot_item_id then
			if slot_item_id then
				local old_unit = slot.unit

				if old_unit then
					local world = self.world_proxy:get_world()

					World.destroy_unit(world, old_unit)
				end

				slot.unit = nil
				slot.item_id = nil
				changed = true
			end

			if item_id then
				slot.item_id = item_id

				if eq_type == "relic" then
					self:trigger_event("on_relic_aquired", unit, item_id)
				elseif eq_type == "talisman" then
					-- Nothing
				else
					local world = self.world_proxy:get_world()
					local unit_path = ItemLookup.item_id_to_path(item_id)
					local item_unit = World.spawn_unit(world, unit_path)

					Unit.set_flow_variable(item_unit, "owner", unit)
					EquipmentComponent.attach_item(world, unit, eq_type, item_unit)

					local flow_variable_name = sprintf("equipment_%s", eq_type)

					Unit.set_flow_variable(unit, flow_variable_name, item_unit)

					slot.unit = item_unit
				end

				changed = true
			end

			if eq_type == "torso" or eq_type == "cape" then
				EquipmentComponent.update_cape_visibility(slots.torso.unit, slots.cape.unit, unit)
			end
		end
	end

	if changed then
		self:trigger_event("on_equipment_updated", unit)
	end
end

EquipmentComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		self:update_slots_slave(unit, state)
	end
end

EquipmentComponent.setup_console_library = function (self)
	local heads = {}
	local head_sets_lookup = {}

	for i, unit_path in ipairs(PluginComponentAux.unit_path_autocomplete()) do
		local set = string.match(unit_path, ".*itemsets/(set%d+)/.*_head")

		if set then
			head_sets_lookup[set] = unit_path
			heads[#heads + 1] = unit_path
		end
	end

	local torsos = {}
	local torso_sets_lookup = {}

	for i, unit_path in ipairs(PluginComponentAux.unit_path_autocomplete()) do
		local set = string.match(unit_path, ".*itemsets/(set%d+)/.*_torso")

		if set then
			torso_sets_lookup[set] = unit_path
			torsos[#torsos + 1] = unit_path
		end
	end

	local legs = {}
	local leg_sets_lookup = {}

	for i, unit_path in ipairs(PluginComponentAux.unit_path_autocomplete()) do
		local set = string.match(unit_path, ".*itemsets/(set%d+)/.*_legs")

		if set then
			leg_sets_lookup[set] = unit_path
			legs[#legs + 1] = unit_path
		end
	end

	local head_sets = table.map_keys_to_array(head_sets_lookup)
	local torso_sets = table.map_keys_to_array(torso_sets_lookup)
	local leg_sets = table.map_keys_to_array(leg_sets_lookup)

	array.append(heads, head_sets)
	array.append(torsos, torso_sets)
	array.append(legs, leg_sets)
	table.sort(heads)
	table.sort(torsos)
	table.sort(legs)

	return {
		text = "Can set equipment.",
		parts = {
			set = {
				text = "Sets a piece of equipment.",
				usage = "<set_name|head|torso|legs|weapon|relic|talisman|cape> <set_name|unit_path|nil> [go_id|all]",
				auto_complete = {
					head = heads,
					torso = torsos,
					legs = legs,
				},
				fun = function (eq_type, unit_path, target)
					if not SLOTS_MAP[eq_type] then
						local head_unit_path = head_sets_lookup[eq_type]
						local torso_unit_path = torso_sets_lookup[eq_type]
						local legs_unit_path = leg_sets_lookup[eq_type]
						local _, msg

						if head_unit_path then
							_, msg = PluginComponentAux.path_exists(head_unit_path)
							msg = PluginComponentAux.execute_command(self, "set", {
								type = "head",
								unit_path = head_unit_path,
							}, target) or msg
						end

						if torso_sets_lookup then
							_, msg = PluginComponentAux.path_exists(torso_unit_path)
							msg = PluginComponentAux.execute_command(self, "set", {
								type = "torso",
								unit_path = torso_unit_path,
							}, target) or msg
						end

						if leg_sets_lookup then
							_, msg = PluginComponentAux.path_exists(legs_unit_path)
							msg = PluginComponentAux.execute_command(self, "set", {
								type = "legs",
								unit_path = legs_unit_path,
							}, target) or msg
						end

						msg = msg or sprintf("Setting equipment types to set %q for %s.", eq_type, PluginComponentAux.target_description(target))

						return msg
					else
						if eq_type == "head" and head_sets_lookup[unit_path] then
							unit_path = head_sets_lookup[unit_path]
						elseif eq_type == "torso" and torso_sets_lookup[unit_path] then
							unit_path = torso_sets_lookup[unit_path]
						elseif eq_type == "legs" and torso_sets_lookup[unit_path] then
							unit_path = leg_sets_lookup[unit_path]
						end

						local path_exists, msg = PluginComponentAux.path_exists(unit_path)

						if not SLOTS_MAP[eq_type] then
							return {
								error = sprintf("Invalid type %q given", eq_type),
							}
						end

						msg = sprintf("Setting equipment type %q to %q for %s.", eq_type, unit_path, PluginComponentAux.target_description(target))
						msg = PluginComponentAux.execute_command(self, "set", {
							type = eq_type,
							unit_path = path_exists and unit_path or nil,
						}, target) or msg

						return msg
					end
				end,
			},
		},
	}
end
