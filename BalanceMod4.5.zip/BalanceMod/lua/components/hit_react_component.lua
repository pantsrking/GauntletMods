﻿-- chunkname: @lua/components/hit_react_component.lua

require("foundation/lua/component/base_component")
require("lua/settings/gore_effect_settings")

HitReactComponent = class("HitReactComponent", "BaseComponent")

HitReactComponent.init = function (self, creation_context)
	BaseComponent.init(self, "hit_react", creation_context)
	self:register_interfaces("i_hit_receiver")

	self.jobs = {}

	local function cb(any_hit, position, distance, normal, actor, job_id)
		local job = self.jobs[job_id]

		self.jobs[job_id] = nil

		self:raycast_callback(any_hit, position, distance, normal, actor, job)
	end

	local physics_world = World.physics_world(self.world_proxy:get_world())

	self.raycast = PhysicsWorld.make_raycast(physics_world, cb, "closest", "types", "both", "collision_filter", "surface_effect")
	self.all_hit_reacts = {}
end

local function handle_inheritance(info, settings)
	if info.inherit_from then
		local parent_info = settings[info.inherit_from]

		handle_inheritance(parent_info, settings)
		SettingsAux.recursive_inheritance(info, parent_info)
	end
end

HitReactComponent.on_script_reload = function (self)
	self.all_hit_reacts = {}

	BaseComponent.on_script_reload(self)
end

HitReactComponent.reload_slave = function (self, unit, context)
	local settings_path = Unit.get_data(unit, "settings_path")
	local hit_reacts = self.all_hit_reacts[settings_path]

	if hit_reacts == nil then
		hit_reacts = table.clone(context.settings.hit_reacts)

		for key, data in pairs(hit_reacts) do
			if data.inherit_from then
				handle_inheritance(data, hit_reacts)
			end
		end

		self.all_hit_reacts[settings_path] = hit_reacts
	end

	context.state.hit_reacts = hit_reacts
	context.num_commands = 0
end

HitReactComponent.setup_slave = function (self, unit, context, setup_info)
	self:reload_slave(unit, context)
end

HitReactComponent.update = function (self, dt)
	return
end

HitReactComponent.call_master_hit = function (self, unit, context, data)
	self:call_slave_hit(unit, EntityAux._context_raw(unit, self.name), data)
end

HitReactComponent.call_slave_hit = function (self, unit, context, data)
	self:play_hit_react(unit, context, data)
end

HitReactComponent.play_hit_react = function (self, unit, context, hit)
	hit.position = Vector3Aux.unbox(hit.position)
	hit.direction = Vector3Aux.unbox(hit.direction)

	local valid_effect = self:setup_effect(unit, context, hit)

	if not valid_effect then
		return
	end

	local hit_settings = hit.settings
	local bloodtype = hit.bloodtype
	local position = hit.position
	local damage_amount = hit.damage_amount or 0
	local blood_effect
	local blocked = hit.blocked

	if blocked then
		local ignore_block = hit.settings.ignore_block

		if ignore_block and ignore_block[self.name] then
			blocked = false
		end
	end

	if hit.gore_effect_type then
		local blood_direction = hit.blood_direction
		local gore_effect_type = hit.gore_effect_type
		local settings = context.settings
		local effect_node = settings.blood_effect_node
		local gore_settings = GoreEffectSettings[gore_effect_type]

		gore_settings = gore_settings[bloodtype] or gore_settings.default

		if blocked then
			local blocking_effects = EffectSettings[settings.block_type or "block_metal"]
			local blocker_state = EntityAux.state(unit, "blocker")
			local block_damage = hit.settings.block_damage or hit.hit_react_info.block_damage

			if block_damage then
				if blocker_state.block_health - block_damage <= 0 then
					gore_settings = blocking_effects.block_broken
				else
					gore_settings = blocking_effects.block_damage
				end

				if EntityAux.has_component_master(unit, "blocker") then
					EntityAux.call_master(unit, "blocker", "block_damage", block_damage)
				end
			elseif AbilityEventAux.is_projectile_by_type(hit_settings.type) then
				gore_settings = blocking_effects.block_deflect_projectile
			else
				gore_settings = blocking_effects.block_deflect
			end

			if settings.block_effect_node then
				effect_node = settings.block_effect_node
			end
		end

		if damage_amount > 0 and Game.gore_enabled then
			local pfx = gore_settings.particle
			local world = self.world_proxy:get_world()

			if pfx then
				local id = SurfaceEffectManager:play_pfx_effect(pfx, position, blood_direction)
				local unit_rotation = Unit.local_rotation(unit, 0)
				local q = Quaternion.look(-blood_direction, Vector3.up())

				q = Quaternion.multiply(Quaternion.conjugate(q), unit_rotation)

				local pose = Matrix4x4.from_quaternion_position(q, Vector3(0, 0, hit_settings.blood_offset_z or 0))
				local node = 0

				if effect_node then
					node = Unit.node(unit, effect_node)
				end

				World.link_particles(world, id, unit, node, pose, "destroy")
			end

			local effect_unit_path = gore_settings.effect_unit_path

			if effect_unit_path then
				local node = gore_settings.effect_unit_node and Unit.node(unit, gore_settings.effect_unit_node) or 0
				local position = Unit.world_position(unit, node)
				local effect_unit = World.spawn_unit(world, effect_unit_path, position)

				World.link_unit(world, effect_unit, node, unit)
			end
		end

		local audio = gore_settings.audio

		if audio then
			SurfaceEffectManager:play_sound_fx_effect(audio, position, nil, blood_direction)
		end

		blood_effect = gore_settings.blood_effect
	elseif bloodtype then
		blood_effect = sprintf("blood_%s", bloodtype)
	end

	if Game.gore_enabled and blood_effect and damage_amount > 0 and not blocked then
		local decal_direction = hit.decal_direction
		local job_id = #self.jobs + 1

		self.jobs[job_id] = {
			blood_effect = blood_effect,
			direction = Vector3Aux.box(TempTableFactory:get(), decal_direction),
		}

		self.raycast:cast(position, decal_direction, 5, job_id)
	end
end

HitReactComponent.setup_effect = function (self, unit, context, hit)
	local state, settings = context.state, context.settings

	if hit.immune then
		return false
	end

	local hit_settings = hit.settings
	local direction = hit.direction
	local hit_react_key = settings.hit_react_override or hit_settings.hit_react

	if hit_react_key then
		local flat_direction = Vector3(direction.x, direction.y, 0)
		local info = state.hit_reacts[hit_react_key] or settings.hit_react_default and state.hit_reacts[settings.hit_react_default]

		if info == nil then
			hit_react_key = nil
		else
			hit.hit_react_info = info
			hit.blood_direction = self:get_effect_direction(flat_direction, info.yaw, info.yaw_variation, info.blood_pitch, info.blood_pitch_variation)
			hit.decal_direction = self:get_effect_direction(flat_direction, info.yaw, info.yaw_variation, info.decal_pitch, info.decal_pitch_variation)
			hit.bloodtype = settings.bloodtype
			hit.gore_effect_type = hit.gore_effect_type or hit.settings.damage_type
			hit.effect_type = hit.settings.effect_type
		end
	end

	return hit_react_key ~= nil
end

HitReactComponent.get_effect_direction = function (self, hit_direction, yaw, yaw_variation, pitch, pitch_variation)
	local yaw_variation_r = (math.random() * 2 - 1) * (yaw_variation or 0)
	local pitch_variation_r = (math.random() * 2 - 1) * (pitch_variation or 0)
	local new_yaw = math.rad(yaw + yaw_variation_r)
	local new_pitch = math.rad(pitch + pitch_variation_r)
	local rotation = Quaternion.from_yaw_pitch_roll(new_yaw, new_pitch, 0)
	local effect_direction = Quaternion.forward(rotation)
	local rotation = Quaternion.look(-hit_direction, Vector3.up())

	return Quaternion.rotate(rotation, effect_direction)
end

HitReactComponent.raycast_callback = function (self, any_hit, position, distance, normal, actor, job)
	if not any_hit or not actor then
		return
	end

	local unit = Actor.unit(actor)

	if not unit then
		return
	end

	local blood_effect = job.blood_effect
	local direction = Vector3Aux.unbox(job.direction)

	SurfaceEffectManager:play_effect(unit, blood_effect, position, normal, direction)
end
