﻿-- chunkname: @lua/components/ability_event_handler.lua

require("lua/components/ability_aux")
require("lua/components/prediction_aux")
require("lua/components/ability_event_aux")
require("lua/ability/ability_modifiers")
require("foundation/lua/managers/lua_settings_manager")
require("foundation/lua/managers/broadphase_manager")
require("lua/managers/entity_event_modifier_manager")
require("lua/components/faction_component")
require("lua/ability/common_events_aux")
require("lua/ability/animated_physic_queries/swipe_physic_query")
require("lua/ability/animated_physic_queries/projectile_physic_query")
require("lua/ability/animated_physic_queries/projectile_grounded_physic_query")
require("lua/ability/animated_physic_queries/projectile_lob_physic_query")
require("lua/ability/animated_physic_queries/projectile_homing_physic_query")
require("lua/ability/animated_physic_queries/projectile_serpent_physic_query")
require("lua/ability/animated_physic_queries/projectile_spiral_physic_query")
require("lua/ability/animated_physic_queries/sphere_physic_query")
require("lua/ability/animated_physic_queries/box_physic_query")
require("lua/ability/animated_physic_queries/box_growing_physic_query")
require("lua/ability/animated_physic_queries/box_sweep_physic_query")

AbilityEventHandler = class("AbilityEventHandler")

local MAX_NR_HITS_PER_FRAME = 5

AbilityEventHandler.init = function (self, ability_component, creation_context)
	self.world_proxy = creation_context.world_proxy
	self.physics_world = World.physics_world(self.world_proxy:get_world())
	self.event_delegate = creation_context.event_delegate
	self.flow_router = creation_context.flow_router
	self.network_router = creation_context.network_router
	self.entity_spawner = creation_context.entity_spawner
	self.despawner = creation_context.despawner
	self.entity_manager = creation_context.entity_manager
	self.randomizer = Randomizer(creation_context.seed)
	self.ability_component = ability_component

	self.event_delegate:register(self, "on_entity_unregistering", "on_remove_units")
	self.flow_router:register(self, "flow_ability_event", "environment_death")
	self.network_router:register(self, "rpc_apply_hit", "rpc_apply_hit_advanced", "rpc_apply_status_effect_hit")

	self.cache_index = 0
	self.table_cache = {}
	self.active_events = {}
	self.queued_hits = {}
	self.queued_network_hits = {}
	self.queries = {
		sphere = SpherePhysicQuery(self.physics_world),
		box = BoxPhysicQuery(self.physics_world),
		box_sweep = BoxSweepPhysicQuery(self.physics_world),
		box_growing = BoxGrowingPhysicQuery(self.physics_world),
		swipe = SwipePhysicQuery(self.physics_world),
		projectile = ProjectilePhysicQuery(self.physics_world),
		projectile_grounded = ProjectileGroundedPhysicQuery(self.physics_world),
		projectile_lob = ProjectileLobPhysicQuery(self.physics_world, self.world_proxy),
		projectile_serpent = ProjectileSerpentPhysicQuery(self.physics_world),
		projectile_spiral = ProjectileSpiralPhysicQuery(self.physics_world),
		projectile_homing = ProjectileHomingPhysicQuery(self.physics_world),
	}
	self.good_faction = FactionComponent.faction_mask("good")

	DifficultyManager:register(self)

	self.enemy_damage_multiplier = DifficultyManager:enemy_damage_multiplier()
	self.avatar_damage_multiplier = DifficultyManager:avatar_damage_multiplier()
	self.net_damage_info = Network.type_info("damage")
end

AbilityEventHandler.destroy = function (self)
	self.flow_router:unregister(self)
	self.event_delegate:unregister(self)
	self.network_router:unregister(self)
	DifficultyManager:unregister(self)
end

local function _is_alive_entity(unit)
	if Unit.alive(unit) then
		if EntityAux.is_entity(unit) then
			return EntityAux.go_id(unit) ~= nil
		else
			return true
		end
	end
end

AbilityEventHandler.on_script_reload = function (self)
	self.queued_hits = {}
	self.queued_network_hits = {}
end

AbilityEventHandler.create_ability = function (self, unit, settings_path, ability_name, master_version)
	return self.ability_component:create_ability(unit, settings_path, ability_name, master_version)
end

AbilityEventHandler.get_cached_table_for_queue = function (self)
	self.cache_index = self.cache_index + 1

	local t = self.table_cache[self.cache_index] or {}

	self.table_cache[self.cache_index] = t

	return t
end

AbilityEventHandler.update = function (self, dt)
	Profiler.start("ability_event_handler")

	local original_dt = dt

	Profiler.start("aeh: ability event handler update")

	if #self.active_events > 0 then
		local hits_cache = TempTableFactory:get()

		for _, event in ipairs(self.active_events) do
			repeat
				local owner_unit = event.owner_unit
				local caster_unit = event.caster_unit or event.owner_unit
				local pose

				dt = original_dt

				if not event.is_projectile then
					dt = AbilityAux.scale_delta_time(caster_unit, dt)
					pose = AbilityEventAux.get_pose(event, false)
				elseif event.current_pose == nil then
					pose = AbilityEventAux.get_pose(event, false)
				end

				if event.timer then
					event.timer = event.timer + dt
				end

				Profiler.start("aeh: update_event_query")

				local query_instance = event.query_instance

				if query_instance then
					hits_cache[#hits_cache + 1] = self:update_event_query(event, pose, dt)
				end

				Profiler.stop()

				event.current_pose = query_instance and query_instance:get_pose(event) or pose

				local event_settings = event.settings

				if not event.unit and event_settings.unit_path and event_settings.unit_path ~= "none" and not event.query_done then
					event.unit = World.spawn_unit(self.world_proxy:get_world(), event_settings.unit_path, event.current_pose)

					Unit.set_flow_variable(event.unit, "caster", caster_unit)

					if event_settings.flow_event_effect_unit_spawned then
						Unit.flow_event(event.unit, event_settings.flow_event_effect_unit_spawned)
					end

					if event_settings.on_effect_unit_spawned then
						event_settings.on_effect_unit_spawned(self, event)
					end
				end

				if event_settings.custom_update then
					event_settings.custom_update(self, event, dt)
				end

				if EntityAux.owned(owner_unit) and event_settings.spawn_entities then
					local info = TempTableFactory:get_map("spawn_entities", event_settings.spawn_entities, "timer", event.timer, "owner_unit", event.owner_unit, "caster_unit", event.caster_unit)

					AbilityBuildingBlocks.update_spawn_entities(info, event.current_pose, self.ability_component)
				end
			until true
		end

		if #hits_cache > 0 then
			Profiler.start("aeh: handle hits")
			self:handle_hits(hits_cache)
			array.remove_all_where(self.active_events, "done", true)
			Profiler.stop()
		end

		Profiler.start("aeh: remove done events")
		self:remove_done_events()
		Profiler.stop()
	end

	Profiler.start("aeh: queued_hits")

	if #self.queued_hits > 0 then
		local size = #self.queued_hits

		for i = 1, math.min(MAX_NR_HITS_PER_FRAME, size) do
			local hit = self.queued_hits[i]

			if _G.GAME_TIME >= (hit.send_time or 0) then
				if _is_alive_entity(hit.unit) then
					hit.owner_unit = Unit.alive(hit.owner_unit) and hit.owner_unit or nil
					hit.caster_unit = Unit.alive(hit.caster_unit) and hit.caster_unit or nil
					hit.position = Vector3Aux.unbox(hit.position_box)
					hit.direction = Vector3Aux.unbox(hit.direction_box)

					EntityEventModifierManager:on_event(hit.unit, "on_hit_send", hit, self.ability_component)
					EntityEventModifierManager:on_event(hit.owner_unit, "on_hit_dealt", hit, self.ability_component)
					self:send_hit(hit)
				end

				hit.consumed = true
			end
		end

		array.remove_all_where(self.queued_hits, "consumed", true)

		if #self.queued_hits + #self.queued_network_hits == 0 then
			self.cache_index = 0
		end
	end

	Profiler.stop()
	Profiler.stop()
	Profiler.stop()
end

AbilityEventHandler.post_update = function (self, dt)
	if #self.queued_network_hits > 0 then
		for i, hit in ipairs(self.queued_network_hits) do
			hit.owner_unit = Unit.alive(hit.owner_unit) and hit.owner_unit or nil
			hit.caster_unit = Unit.alive(hit.caster_unit) and hit.caster_unit or nil
			hit.position = Vector3Aux.unbox(hit.position_box)
			hit.direction = Vector3Aux.unbox(hit.direction_box)
			hit.victim_position = Vector3Aux.unbox(hit.victim_position_box)
			hit.attack_origin = Vector3Aux.unbox(hit.attack_origin_box)

			self:send_network_hit_to_others(hit)
		end

		table.clear(self.queued_network_hits)

		if #self.queued_hits + #self.queued_network_hits == 0 then
			self.cache_index = 0
		end
	end
end

AbilityEventHandler.update_event_query = function (self, event, pose, dt)
	local query_instance = event.query_instance
	local settings = event.settings
	local include_caster = settings.self_damage

	if settings.refresh_hitlist_time then
		local hitlist = query_instance:get_hitlist(event)

		for unit, hit in pairs(hitlist) do
			repeat
				if (unit ~= event.caster_unit or include_caster) and type(hit) == "table" then
					local refresh_hitlist_time = settings.refresh_hitlist_time

					hit.timer = (hit.timer or refresh_hitlist_time) - dt

					if hit.timer <= 0 then
						query_instance:remove_from_hitlist(event, unit)

						event.hitlist[unit] = nil
					end
				end
			until true
		end
	end

	Profiler.start("aeh: query update")

	local new_hits = query_instance:update(event, dt, pose)

	Profiler.stop()

	if event.unit then
		pose = query_instance:get_pose(event)

		if event.settings.rotation_angles then
			local angles = event.settings.rotation_angles
			local rotation = Quaternion.from_yaw_pitch_roll(math.rad(angles.z), math.rad(angles.x), math.rad(angles.y))

			pose = Matrix4x4.from_quaternion_position(Quaternion.multiply(Matrix4x4.rotation(pose), rotation), Matrix4x4.translation(pose))
		end

		if event.update_unit_position ~= false then
			Unit.set_local_pose(event.unit, 0, pose)
		end
	elseif pose == nil then
		pose = query_instance:get_pose(event)
	end

	if #new_hits == 0 then
		return
	end

	for i = #new_hits, 1, -1 do
		local hit = new_hits[i]

		if not _is_alive_entity(hit.unit) then
			array.remove_at(new_hits, i)
		elseif event.hitlist[hit.unit] then
			array.remove_at(new_hits, i)
		end
	end

	if #new_hits > 0 then
		local hit_info = TempTableFactory:get()

		hit_info.query_direction = query_instance:get_direction(event)
		hit_info.query_origin = query_instance:calculate_origin(event, pose)
		hit_info.event = event

		for i, hit in ipairs(new_hits) do
			hit.modifiers = TempTableFactory:get()
			hit.position = Vector3Aux.unbox(hit.position)
			hit.actor = hit.actor and ActorBox.unbox(hit.actor)
			hit.event = event
			hit.settings = protect(event.settings)
			hit.settings_path = event.settings_path
			hit.ability_name = event.ability_name
			hit.index = event.index
			hit.owner_unit = event.owner_unit
			hit.caster_unit = event.caster_unit
			hit.direction, hit.attack_origin = AbilityEventAux.calculate_direction(event.settings, hit, hit_info)
			hit.to_hit = hit.position - hit.attack_origin
			hit.distance = Vector3.length(hit.to_hit)

			if event.is_projectile and hit.actor then
				local shapes = Actor.shapes(hit.actor)

				if shapes[1] then
					local shape = shapes[1]

					if shape.type == Actor.SPHERE or shape.type == Actor.CAPSULE then
						hit.distance = math.max(hit.distance - shape.radius, 0)
					end
				end
			end

			hit.is_authorative = PredictionAux.is_event_authorative(event.owner_unit or event.caster_unit, hit.unit)
		end

		table.sort(new_hits, function (a, b)
			return a.distance < b.distance
		end)
		AbilityEventAux.filter_friendly_fire(event, settings, new_hits)
		AbilityEventAux.filter_query_hits(settings.query_filters, new_hits, pose, event, hit_info)

		if #new_hits > 0 then
			hit_info.hits = new_hits

			return hit_info
		end
	end

	return nil
end

AbilityEventHandler.handle_hits = function (self, hits_cache)
	for i, hit_collection in ipairs(hits_cache) do
		repeat
			local event = hit_collection.event

			if event.power and event.power <= 0 or event.done then
				break
			end

			local hits = hit_collection.hits

			for i, hit in ipairs(hits) do
				local hit_unit = hit.unit
				local is_projectile = event.is_projectile
				local valid_hit = false

				if hit.player_vs_player_hit then
					valid_hit = true
				else
					valid_hit = (not hit.fake_wall or false) and EntityAux.has_interface(hit_unit, "i_hit_receiver")
					hit.valid_hit = valid_hit

					EntityEventModifierManager:on_event(hit_unit, "hit", hit)

					local event = hit.event

					if is_projectile then
						self:handle_projectile_hit(hit, event)

						if event.done then
							break
						end
					elseif hit.modifiers.reflected then
						self:reflect_hit(hit, event)

						if event.done then
							break
						end
					else
						local valid_reflect = EntityAux.has_component(event.caster_unit, "shock_receiver")

						if valid_reflect and valid_hit then
							local vitim_settings = LuaSettingsManager:get_settings_by_unit(hit_unit)

							if vitim_settings and vitim_settings.stun_on_hit and not hit.ally then
								local ability_name = "reflected_melee_self"
								local settings_path = "characters/generic_abilities"
								local info = self:create_ability(event.caster_unit, settings_path, ability_name, true)
								local ability_event = info.events[1]
								local temp = TempTableFactory:get_map("settings", ability_event, "settings_path", settings_path, "ability_name", ability_name, "index", 1, "owner_unit", hit_unit, "caster_unit", event.caster_unit, "event_id", nil, "stat_creditor_go_id", event.stat_creditor_go_id)

								self:execute_event(temp, event.parent_ability)
							end
						end
					end

					local ability_event_listeners = event.ability_event_listeners

					if ability_event_listeners then
						for i, listener in ipairs(ability_event_listeners) do
							if listener.filter(event.owner_unit, hit) then
								listener.callback(event.owner_unit, hit)
							end
						end
					end
				end

				if valid_hit then
					if hit.is_authorative then
						for k, v in pairs(hit.modifiers) do
							hit[k] = v
						end

						self:on_valid_hit(event, hit)
					end
				elseif event.settings.on_non_valid_hit then
					self:handle_event_callback(event, event.settings.on_non_valid_hit, hit)
				end

				if not EntityAux.has_component(hit_unit, "hit_react") then
					local effect_type = event.settings.effect_type
					local normal = Vector3Aux.unbox(hit.normal)

					SurfaceEffectManager:play_effect(hit_unit, effect_type, hit.position, -normal)
				end

				if not hit.player_vs_player_hit and valid_hit and is_projectile and event.power <= 0 then
					break
				end
			end
		until true
	end
end

AbilityEventHandler.handle_projectile_hit = function (self, hit, event)
	local power = event.power or hit.settings.power or 1
	local hit_settings = LuaSettingsManager:get_settings_by_unit(hit.unit)

	if hit.stopping_power == nil then
		hit.stopping_power = hit_settings and hit_settings.stopping_power or 1
	end

	if hit.modifiers.reflected then
		self:reflect_hit(hit, event)

		hit.destroy_event = true
	end

	local stop_projectile = not hit_settings

	if not stop_projectile then
		local stopping_power = hit.stopping_power or 1

		if stopping_power == -1 then
			stop_projectile = true
		else
			power = power - stopping_power
			stop_projectile = power <= 0
		end
	end

	if hit.settings.type == "projectile_homing" then
		stop_projectile = false
	end

	event.power = power

	if stop_projectile and event.unit then
		Unit.set_flow_variable(event.unit, "position", hit.position)
		Unit.set_flow_variable(event.unit, "incident_direction", hit.direction)
		Unit.set_flow_variable(event.unit, "blocking_unit", hit.unit)

		local is_blocked = hit.modifiers.blocked
		local is_deflected = hit_settings and hit_settings.deflect_projectiles == true or false

		Unit.set_flow_variable(event.unit, "is_blocked", is_blocked)
		Unit.set_flow_variable(event.unit, "is_deflected", is_blocked or is_deflected)
		Unit.set_local_position(event.unit, 0, hit.position)
	end

	if stop_projectile then
		event.query_info.done = true
		event.power = 0
	end

	if hit.destroy_event then
		if event.unit and not event.keep_event_unit then
			World.destroy_unit(self.world_proxy:get_world(), event.unit)

			event.unit = nil
		end

		event.done = true
	end
end

AbilityEventHandler.reflect_hit = function (self, hit, event)
	local caster_unit = event.caster_unit
	local owner_unit = event.owner_unit
	local is_projectile = event.is_projectile

	if caster_unit == nil and not is_projectile then
		return
	end

	local new_caster_unit = hit.unit
	local new_owner_unit = new_caster_unit

	if owner_unit then
		local is_owner_a_player = Unit.get_data(owner_unit, "is_player")

		new_owner_unit = is_owner_a_player and owner_unit or new_caster_unit
	end

	local stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(new_owner_unit)

	if is_projectile then
		Unit.flow_event(new_caster_unit, "blocking_reflect")

		if EntityAux.has_component_master(new_owner_unit, "animation") then
			EntityAux.queue_command_master(new_owner_unit, "animation", "trigger_event", "reflected_hit")
		end

		local settings_data = table.clone(event.settings)

		settings_data.damage_amount = (settings_data.damage_amount or 0) * 5

		if event.settings.type == "projectile" then
			settings_data.speed = math.min(settings_data.speed * 4, 150)
		elseif event.settings.type == "projectile_lob" then
			settings_data.speed_multiplier = settings_data.speed_multiplier * 3
		elseif event.settings.type == "projectile_serpent" then
			-- Nothing
		elseif event.settings.type == "projectile_spiral" then
			-- Nothing
		elseif event.settings.type == "projectile_grounded" then
			-- Nothing
		end

		local target_position

		if owner_unit then
			target_position = Unit.local_position(owner_unit, 0) + Vector3.up()
		else
			target_position = Unit.world_position(new_caster_unit, 0) + Vector3.up() + UnitAux.unit_forward(new_caster_unit) * 5
		end

		local rotation = Quaternion.look(Vector3.normalize(target_position - hit.position), Vector3.up())
		local override_pose = Matrix4x4Box(Matrix4x4.from_quaternion_position(rotation, hit.position))

		settings_data.origin = settings_data.origin or {}
		settings_data.origin.x = 0
		settings_data.origin.y = 0
		settings_data.origin.z = 0
		settings_data.angle = 0

		if event.unit then
			Unit.flow_event(event.unit, "on_reflected")
		end

		if EntityAux.has_component_master(new_caster_unit, "animation") then
			EntityAux.queue_command_master(new_caster_unit, "animation", "trigger_event", "block_deflect_projectile")
		end

		local temp = TempTableFactory:get_map("settings", settings_data, "settings_path", event.settings_path, "ability_name", event.ability_name, "override_pose", override_pose, "target_position_box", Vector3Aux.box({}, target_position), "index", event.index, "owner_unit", new_owner_unit, "caster_unit", new_caster_unit, "event_id", nil, "stat_creditor_go_id", stat_creditor_go_id)
		local new_event = self:execute_event(temp, event.parent_ability)

		new_event.unit = event.unit
		event.unit = nil
	elseif hit.settings.type == "swipe" then
		-- Nothing
	elseif EntityAux.has_interface(caster_unit, "i_hit_receiver") then
		local ability_name = "reflected_melee"
		local settings_path = "characters/generic_abilities"
		local info = self:create_ability(new_caster_unit, settings_path, ability_name, true)
		local ability_event = info.events[1]

		if EntityAux.has_component_master(new_caster_unit, "animation") then
			EntityAux.queue_command_master(new_caster_unit, "animation", "trigger_event", "block_deflect_melee")
		end

		local temp = TempTableFactory:get_map("settings", ability_event, "settings_path", settings_path, "ability_name", ability_name, "index", 1, "owner_unit", new_owner_unit, "caster_unit", new_caster_unit, "event_id", nil, "stat_creditor_go_id", stat_creditor_go_id)

		self:execute_event(temp, event.parent_ability)
	elseif EntityAux.has_component_master(new_caster_unit, "animation") then
		EntityAux.queue_command_master(new_caster_unit, "animation", "trigger_event", "block_deflect_melee")
	end
end

AbilityEventHandler.handle_event_callback = function (self, event, info, last_hit)
	local unit = event.caster_unit

	if unit then
		if not EntityAux.is_entity(unit) and event.owner_unit then
			unit = event.owner_unit
		end

		if EntityAux.owned(unit) then
			if info.filter_hit and not info.filter_hit(self, event, last_hit) then
				return
			end

			if info.condition then
				if info.condition == "max_distance_reached" then
					local q_info = event.query_info

					if q_info.distance < q_info.max_distance then
						return
					end
				elseif info.condition == "only_evil" and last_hit then
					local hit_unit = last_hit.unit
					local is_evil = EntityAux.has_component(hit_unit, "faction") and FactionComponent.is_evil(EntityAux.state(hit_unit, "faction").faction)

					if not is_evil then
						return
					end
				end
			end

			if last_hit and last_hit.unit and info.predicates then
				local hit_unit = last_hit.unit
				local passed_all = true
				local temp = TempTableFactory:get()

				for _, predicate in ipairs(info.predicates) do
					if not predicate(self.ability_component, unit, temp, hit_unit) then
						passed_all = false

						break
					end
				end

				if not passed_all then
					return
				end
			end

			local override_pose, target_unit

			if not info.use_caster_as_origin then
				if info.use_last_hit_as_target then
					if event.query_instance or event.unit then
						local target = Vector3Aux.unbox(last_hit.position)
						local pose = event.query_instance and event.query_instance:get_pose(event) or Unit.world_pose(event.unit, 0)
						local position = Matrix4x4.translation(pose)
						local direction = Vector3.normalize(target - position)
						local rotation = Quaternion.look(direction)

						override_pose = Matrix4x4Box(Matrix4x4.from_quaternion_position(rotation, position))
					end
				elseif last_hit then
					local direction = Vector3Aux.unbox(last_hit.direction)
					local position = Vector3Aux.unbox(last_hit.position)

					direction.z = 0

					local rot = Quaternion.look(Vector3.normalize(direction))

					override_pose = Matrix4x4Box(Matrix4x4.from_quaternion_position(rot, position))
				elseif event.query_instance or event.unit then
					local pose = event.query_instance and event.query_instance:get_pose(event) or Unit.world_pose(event.unit, 0)
					local rotation = Matrix4x4.rotation(pose)
					local forward = Quaternion.forward(rotation)

					forward.z = 0
					rotation = Quaternion.look(Vector3.normalize(forward))

					Matrix4x4.set_rotation(pose, rotation)

					override_pose = Matrix4x4Box(pose)
				end
			end

			if override_pose == nil then
				local node = 0

				if info.node then
					node = Unit.node(unit, info.node)
				end

				override_pose = Matrix4x4Box(Unit.world_pose(event.caster_unit, node))
			end

			local ability_name = info.ability

			if ability_name then
				local inherited_hitlist, hitlist = nil, event.hitlist

				hitlist.steps = (hitlist.steps or 0) + 1

				local cancel_next_ability = false

				if info.max_steps then
					cancel_next_ability = hitlist.steps > info.max_steps
				end

				if info.inherit_hitlist then
					inherited_hitlist = hitlist
				elseif info.set_hit_unit_as_hitlist then
					inherited_hitlist = {
						[last_hit.unit] = true,
					}
					inherited_hitlist.steps = hitlist.steps
				end

				if info.use_last_hit_as_target then
					target_unit = last_hit.unit

					if info.clear_last_target_from_hitlist ~= false then
						event.hitlist[last_hit.unit] = nil
					end
				end

				if not cancel_next_ability then
					self:execute_ability(unit, info, event, target_unit, override_pose, inherited_hitlist)
				else
					info.set_event_as_done = false
				end
			end

			if info.spawn_entities then
				local info = TempTableFactory:get_map("spawn_entities", info.spawn_entities, "timer", 10000, "owner_unit", event.owner_unit, "caster_unit", event.caster_unit)
				local pose = Matrix4x4Box.unbox(override_pose)

				AbilityBuildingBlocks.update_spawn_entities(info, pose, self.ability_component, 0)
			end
		elseif EntityAux.is_entity(unit) and info.ability and info.set_event_unit_as_caster then
			self:execute_ability(unit, info, event, nil, nil, nil)
		end
	end

	if info.set_event_as_done then
		event.done = true

		event.query_instance:set_as_done(event)

		event.power = 0
	end

	local queue_hit = true

	if info.custom_callback then
		queue_hit = info.custom_callback(self, event, last_hit)
	end

	if event.unit then
		local destroy_event_unit = info.destroy_event_unit

		if not destroy_event_unit and not Unit.alive(event.caster_unit) then
			destroy_event_unit = event.settings.destroy_event_unit_on_caster_removed
		end

		if destroy_event_unit then
			World.destroy_unit(self.world_proxy:get_world(), event.unit)

			event.unit = nil
			event.done = true
			event.power = 0
		end
	end

	if unit then
		if last_hit and info.flow_variables then
			for key, name in pairs(info.flow_variables) do
				if last_hit[name] then
					Unit.set_flow_variable(unit, key, last_hit[name])
				end
			end
		end

		if info.flow_event then
			Unit.flow_event(unit, info.flow_event)
		end
	end

	return queue_hit
end

AbilityEventHandler.execute_ability = function (self, unit, info, event, target_unit, override_pose, inherited_hitlist)
	if info.set_event_unit_as_caster then
		local ability_id = 0
		local msg = TempTableFactory:get_map("caster_unit", event.unit, "ability_name", info.ability, "settings_path", event.settings_path, "execute_local_only", true, "force_execution", true, "ability_id", ability_id, "stat_creditor_go_id", event.stat_creditor_go_id, "target_unit", target_unit)

		EntityAux.queue_command(unit, "ability", "execute_ability", msg)
	elseif info.broadcast_ability then
		if EntityAux.owned(unit) then
			local msg = TempTableFactory:get_map("ability_name", info.ability, "settings_path", event.settings_path, "stat_creditor_go_id", event.stat_creditor_go_id, "target_unit", target_unit)

			EntityAux.queue_command_master(unit, "ability", "execute_ability", msg)
		end
	else
		local msg = TempTableFactory:get_map("ability_name", info.ability, "settings_path", event.settings_path, "override_pose", override_pose, "inherited_hitlist", inherited_hitlist, "stat_creditor_go_id", event.stat_creditor_go_id, "target_unit", target_unit)

		EntityAux.queue_command(unit, "ability", "append_ability", msg)
	end
end

AbilityEventHandler.remove_done_events = function (self)
	local active_events = self.active_events

	if #active_events == 0 then
		return
	end

	local dirty = false

	for i, event in pairs(active_events) do
		if event.done or AbilityEventAux.is_event_done(event) then
			dirty = true

			self:on_event_exit(event)
		end
	end

	if dirty then
		array.remove_all_where(active_events, "done", true)
	end
end

AbilityEventHandler.on_event_exit = function (self, event)
	local settings = event.settings

	if event.unit then
		Profiler.start("on_event_complete")
		Unit.flow_event(event.unit, "on_event_complete")

		if not Unit.alive(event.unit) then
			event.unit = nil
		end

		Profiler.stop()
	end

	if settings.on_event_complete ~= nil then
		self:handle_event_callback(event, settings.on_event_complete, nil)
	end

	local caster_unit = event.caster_unit

	if caster_unit and settings.on_exit_flow then
		Unit.flow_event(caster_unit, settings.on_exit_flow)
	end

	if settings.on_exit_custom then
		settings.on_exit_custom(self, event)
	end

	if caster_unit and settings.ignore_shock then
		EntityAux.queue_command(caster_unit, "shock_receiver", "enable_shocks")
	end

	if event.query_instance then
		event.query_instance:destroy_query(event)
	end

	event.query_instance = nil
	event.done = true
	event.unit = nil
end

AbilityEventHandler.execute_event = function (self, event_data, parent_ability)
	local event = table.clone(event_data)

	Profiler.start("AbilityEventHandler:execute_event %s", event.settings_path)

	local settings = event.settings
	local caster_unit = event.caster_unit
	local owner_unit = event.owner_unit
	local settings_path = event.settings_path
	local ability_name = event.ability_name
	local owner_goid = EntityAux.go_id(owner_unit or caster_unit)

	event.parent_ability = parent_ability
	event.id = event_data.event_id or AbilityAux.generate_event_id(owner_goid, parent_ability.ability_id, event.index)
	event.hit_id_counter = 1

	if settings.use_caster_as_target then
		event.target_unit = caster_unit
	end

	if event.target_unit then
		local target_position

		if Unit.alive(event.target_unit) then
			target_position = Unit.local_position(event.target_unit, 0)
		else
			local position = Unit.local_position(caster_unit, 0)

			target_position = position + UnitAux.unit_forward(caster_unit) * 5
		end

		if settings.set_movements_forward == "towards_target" then
			local my_position = Unit.world_position(caster_unit, 0)
			local vector = target_position - my_position
			local forward = Vector3.normalize(vector)

			parent_ability.stored_forward = Vector3Aux.box({}, forward)
		end

		event.target_position_box = Vector3Aux.box({}, target_position)
	end

	event.randomizer = self.randomizer
	parent_ability.test_hitlist = parent_ability.test_hitlist or {}
	event.hitlist = settings.share_hitlist and parent_ability.test_hitlist or {}
	event.timer = 0
	event.event_duration = settings.event_duration
	event.is_projectile = AbilityEventAux.is_projectile(event)

	local query_instance = AbilityEventAux.construct_query(self.queries, event)

	if query_instance then
		if settings.behind_wall_test == nil then
			event.behind_wall_test = event.stat_creditor_go_id ~= nil
		else
			event.behind_wall_test = settings.behind_wall_test
		end

		if not settings.self_damage then
			query_instance:add_to_hitlist(event, caster_unit)
			query_instance:add_to_hitlist(event, owner_unit)
		end

		if parent_ability.inherited_hitlist then
			for unit, value in pairs(parent_ability.inherited_hitlist) do
				if unit ~= event.target_unit then
					query_instance:add_to_hitlist(event, unit)

					event.hitlist[unit] = value
				end
			end
		end
	elseif parent_ability.inherited_hitlist then
		for unit, value in pairs(parent_ability.inherited_hitlist) do
			if unit ~= event.target_unit then
				event.hitlist[unit] = value
			end
		end
	end

	event.query_instance = query_instance
	event.event_faction = AbilityEventAux.calculate_event_faction(event)
	event.owner_settings = LuaSettingsManager:get_settings_by_unit(owner_unit)

	if settings.on_enter_flow then
		local pose = AbilityEventAux.get_pose(event, true)
		local position

		if event.query_instance then
			position = event.query_instance:calculate_origin(event, pose)
		else
			position = Matrix4x4.translation(pose)
		end

		Unit.set_flow_variable(caster_unit, "event_position", position)
		Unit.set_flow_variable(caster_unit, "event_rotation", Matrix4x4.rotation(pose))
		Unit.flow_event(caster_unit, settings.on_enter_flow)
	end

	if settings.on_enter_custom then
		settings.on_enter_custom(self, event)
	end

	if settings.target_type == "self" then
		if EntityAux.owned(owner_unit) then
			local position = Unit.local_position(caster_unit, 0)
			local direction = -UnitAux.unit_forward(caster_unit)

			self:on_valid_hit(event, AbilityEventAux.build_hit_from_ability_event(caster_unit, ability_name, settings_path, settings, event.index, position, direction, true), true)
		end
	elseif settings.target_type == "allies" then
		self:hit_all_targets(event, true)
	elseif settings.target_type == "avatars" then
		local entities = TempTableFactory:get()

		for go_id, player_info in PlayerManager:avatars_iterator() do
			entities[#entities + 1] = player_info.avatar_unit
		end

		local settings = event.settings
		local settings_path = event.settings_path
		local ability_name = event.ability_name

		if event.settings.target_filter then
			entities = event.settings.target_filter(event, entities)
		end

		for _, target_unit in ipairs(entities) do
			local passed_all = true
			local temp = TempTableFactory:get()

			for _, predicate in ipairs(settings.target_predicates) do
				if not predicate(self.ability_component, owner_unit, temp, target_unit) then
					passed_all = false

					break
				end
			end

			if passed_all then
				local is_authorative = PredictionAux.is_event_authorative(owner_unit, target_unit)
				local position = Unit.local_position(target_unit, 0)
				local direction = UnitAux.unit_forward(target_unit)

				self:on_valid_hit(event, AbilityEventAux.build_hit_from_ability_event(target_unit, ability_name, settings_path, settings, event.index, position, direction, is_authorative), true)
			end
		end
	elseif settings.target_type == "enemies" then
		self:hit_all_targets(event, false)
	elseif settings.target_type == "random_enemy" then
		if EntityAux.owned(owner_unit) then
			self:hit_random_target(event, false)
		end
	elseif settings.target_type == "target_unit" then
		local target_unit = event.target_unit

		if not target_unit then
			-- Nothing
		elseif _is_alive_entity(target_unit) then
			local position = Unit.world_position(target_unit, 0)
			local caster_position = Unit.world_position(caster_unit, 0)
			local direction = UnitAux.unit_forward(target_unit)

			if settings.stagger_origin_type == "character" then
				direction = Vector3.normalize(position - caster_position)
			end

			local is_authorative = PredictionAux.is_event_authorative(owner_unit, target_unit)

			self:on_valid_hit(event, AbilityEventAux.build_hit_from_ability_event(target_unit, ability_name, settings_path, settings, event.index, position, direction, is_authorative), true)
		end
	end

	if not Unit.alive(event.target_unit) then
		event.target_unit = nil
	end

	local dirty = false
	local pre_event_unit = event.unit

	for i, other_event in ipairs(self.active_events) do
		if other_event.unit ~= nil and other_event.unit == pre_event_unit then
			dirty = true
			other_event.destroyed = true
			other_event.unit = nil
		end
	end

	if dirty then
		array.remove_all_where(self.active_events, "destroyed", true)
	end

	self.active_events[#self.active_events + 1] = event

	Profiler.stop()

	return event
end

AbilityEventHandler.hit_all_targets = function (self, event, ally_targets)
	local caster_unit = event.caster_unit
	local owner_unit = event.owner_unit
	local settings = event.settings
	local settings_path = event.settings_path
	local ability_name = event.ability_name
	local my_position = Unit.local_position(caster_unit, 0)
	local my_faction = EntityAux.state(owner_unit, "faction").faction
	local radius = settings.target_range or FactionComponent.BROADPHASE_MAX_RADIUS

	radius = math.min(radius, FactionComponent.BROADPHASE_MAX_RADIUS)

	local entities = TempTableFactory:get()
	local broadphase_id = settings.target_broadphase or FactionComponent.BROADPHASE_ID

	BroadphaseManager:query(broadphase_id, my_position, radius, entities, ally_targets and Broadphase.INCLUSIVE or Broadphase.EXCLUSIVE, my_faction)

	if event.settings.target_filter then
		entities = event.settings.target_filter(event, entities)
	end

	for _, target_unit in ipairs(entities) do
		local passed_all = true
		local temp = TempTableFactory:get()

		for _, predicate in ipairs(settings.target_predicates) do
			if not predicate(self.ability_component, owner_unit, temp, target_unit) then
				passed_all = false

				break
			end
		end

		if passed_all then
			local is_authorative = PredictionAux.is_event_authorative(owner_unit, target_unit)
			local position = Unit.local_position(target_unit, 0)
			local direction = UnitAux.unit_forward(target_unit)

			self:on_valid_hit(event, AbilityEventAux.build_hit_from_ability_event(target_unit, ability_name, settings_path, settings, event.index, position, direction, is_authorative), true)
		end
	end
end

AbilityEventHandler.hit_random_target = function (self, event, get_ally_target)
	local caster_unit, owner_unit = event.caster_unit, event.owner_unit
	local settings = event.settings
	local target_predicates = settings.target_predicates or {}

	target_predicates[#target_predicates + 1] = function (component, unit, context, target_unit)
		return event.hitlist[target_unit] == nil
	end

	local target_unit = StateAux.get_random_target(self.ability_component, caster_unit, nil, settings.target_range, get_ally_target, target_predicates)

	event.target_unit = target_unit

	if not target_unit then
		if settings.on_non_valid_hit then
			self:handle_event_callback(event, settings.on_non_valid_hit, nil)
		end

		return
	end

	local position = Unit.local_position(target_unit, 0)
	local is_authorative = PredictionAux.is_event_authorative(owner_unit, target_unit)
	local origin_type = settings.stagger_origin_type or "character"
	local direction

	if origin_type == "character" then
		local caster_unit = caster_unit
		local attack_origin = Unit.world_position(caster_unit, 0) + Vector3.up()
		local to_hit = position - attack_origin

		direction = Vector3.normalize(to_hit)
	else
		direction = UnitAux.unit_forward(target_unit)
	end

	self:on_valid_hit(event, AbilityEventAux.build_hit_from_ability_event(target_unit, event.ability_name, event.settings_path, settings, event.index, position, direction, is_authorative), true)

	return target_unit
end

AbilityEventHandler.on_remove_units = function (self)
	table.clear(self.active_events)
	table.clear(self.queued_hits)
end

AbilityEventHandler.difficulty_changed = function (self, difficulty)
	self.enemy_damage_multiplier = DifficultyManager:enemy_damage_multiplier()
	self.avatar_damage_multiplier = DifficultyManager:avatar_damage_multiplier()
end

AbilityEventHandler.on_entity_unregistering = function (self, unit)
	local dirty = false

	for i, event in ipairs(self.active_events) do
		if event.owner_unit == unit then
			event.owner_unit = nil
		end

		if event.target_unit == unit then
			event.target_unit = nil
		end

		if event.caster_unit == unit then
			if AbilityEventAux.is_dependant_on_caster(event) then
				event.destroyed = true
				dirty = true
			elseif event.settings.remove_caster_on_entity_destroy ~= false then
				event.caster_unit = nil
			end
		end
	end

	if dirty then
		dirty = false

		for i, event in pairs(self.active_events) do
			if event.destroyed then
				dirty = true

				if event.query_instance then
					event.query_instance:destroy_query(event)
				end

				event.query_instance = nil

				self:on_event_exit(event)
			end
		end

		if dirty then
			array.remove_all_where(self.active_events, "destroyed", true)
		end
	end

	dirty = false

	for i, hit in ipairs(self.queued_hits) do
		local recipient_unit = hit.unit

		if recipient_unit == unit then
			hit.done = true
			dirty = true
		end
	end

	if dirty then
		array.remove_all_where(self.queued_hits, "done", true)
	end
end

AbilityEventHandler.on_valid_hit = function (self, event, hit, hit_already_approved)
	hit.event = event

	local queue_hit = self:calculate_damage_amount(hit)

	if hit_already_approved then
		queue_hit = true
	end

	if event.hitlist then
		event.hitlist[hit.unit] = true
	end

	if queue_hit and event.settings.on_valid_hit then
		queue_hit = self:handle_event_callback(event, event.settings.on_valid_hit, hit) ~= false
	end

	if queue_hit then
		self:queue_hit(hit)
	end
end

AbilityEventHandler.queue_hit = function (self, hit)
	local event = hit.event

	if hit.is_authorative and event and event.settings.damage_hit_delay then
		hit.send_time = _G.GAME_TIME + (event.settings.damage_hit_delay or 0) / 30
	end

	hit.modifiers.ally_hit = hit.ally_hit
	hit.modifiers = table.clone(hit.modifiers)
	hit.position_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.position)
	hit.direction_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.direction)
	hit.attack_origin_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.attack_origin or hit.position)
	self.queued_hits[#self.queued_hits + 1] = hit
end

AbilityEventHandler.queue_network_hit = function (self, hit)
	hit.position_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.position)
	hit.direction_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.direction)
	hit.victim_position_box = Vector3Aux.box(self:get_cached_table_for_queue(), hit.victim_position)
	hit.modifiers = table.clone(hit.modifiers)
	self.queued_network_hits[#self.queued_network_hits + 1] = hit
end

AbilityEventHandler.calculate_damage_amount = function (self, hit)
	local queue_hit = true

	if hit.is_remote_hit then
		return queue_hit
	end

	hit.stat_creditor_go_id = hit.event.stat_creditor_go_id

	if hit.stat_creditor_go_id then
		local player_info = PlayerManager:get_player_info(hit.stat_creditor_go_id)

		if not player_info then
			hit.stat_creditor_go_id = nil
		end
	end

	local damage_amount = hit.damage_amount or hit.settings.damage_amount or 0

	if type(damage_amount) == "table" then
		local damage_range = damage_amount
		local min, max = damage_range[1], damage_range[2]

		damage_amount = math.random(min, max)
	end

	local recipient_unit = hit.unit

	if hit.stat_creditor_go_id then
		local faction_state = EntityAux.state(recipient_unit, "faction")
		local owner_faction = hit.event.event_faction

		if owner_faction and faction_state and FactionComponent.are_allies_mask(owner_faction, faction_state.original_faction) then
			local is_recipient_a_player = Unit.get_data(recipient_unit, "is_player")

			hit.ally_hit = true

			if is_recipient_a_player then
				damage_amount = 0

				local status_state = EntityAux.state(recipient_unit, "status_receiver")

				queue_hit = not hit.settings.status_effects and (status_state.frozen or status_state.confused)
			end
		end

		if EntityAux.has_component(hit.caster_unit, "scale") then
			local scale_state = EntityAux.state(hit.caster_unit, "scale")

			damage_amount = damage_amount * scale_state.current_scale
		end

		local perk = hit.settings.perk

		if perk == "furious_charge" then
			local is_enemy = EntityAux.has_component(recipient_unit, "enemy")

			if is_enemy then
				PerkManager:increment(hit.stat_creditor_go_id, "furious_charge")
			end
		end
	end

	if EntityAux.has_component(recipient_unit, "damage_receiver") and damage_amount > 0 then
		local faction_state = EntityAux.state(recipient_unit, "faction")

		if faction_state and FactionComponent.are_allies_mask(faction_state.faction, self.good_faction) then
			damage_amount = math.round(damage_amount * self.avatar_damage_multiplier)
		else
			damage_amount = math.round(damage_amount * self.enemy_damage_multiplier)
		end
	end

	hit.damage_amount = math.round(math.clamp(damage_amount, self.net_damage_info.min, self.net_damage_info.max))

	return queue_hit
end

AbilityEventHandler.send_hit = function (self, hit)
	if not hit.is_authorative then
		return
	end

	local recipient_unit = hit.unit
	local interfaces = EntityAux.cache_interfaces[recipient_unit]
	local component_names = interfaces.i_hit_receiver
	local paused = false

	for i, component_name in ipairs(component_names) do
		paused = self.entity_manager:is_paused(recipient_unit, component_name)

		if paused then
			break
		end
	end

	if hit.is_remote_hit then
		if paused then
			EntityCullingManager:uncull_unit(recipient_unit)
		end

		EntityAux.call_interface(recipient_unit, "i_hit_receiver", "hit", hit)
	else
		if paused then
			return
		end

		if AbilityEventAux.is_invincible_against(recipient_unit, hit) then
			return
		end

		local event = hit.event

		if event.is_projectile then
			hit.modifiers.event_done = event.done
		end

		hit.victim_position = Unit.world_position(recipient_unit, 0)
		hit.id = event.id + event.hit_id_counter
		event.hit_id_counter = (event.hit_id_counter + 1) % 2^AbilityAux.BITS_HIT
		hit.random_seed = hit.id * event.index

		self:queue_network_hit(hit)
		EntityAux.call_interface(recipient_unit, "i_hit_receiver", "hit", hit)
	end
end

AbilityEventHandler.send_network_hit_to_others = function (self, hit)
	local settings_path = hit.settings_path
	local ability_name = hit.ability_name
	local event_index = hit.index
	local mask = ModifierHandler.pack_modifiers(hit.modifiers)
	local rotation_angle = math.normalized_angle_from_direction(hit.direction)
	local recipient_unit = hit.unit

	if hit.stat_creditor_go_id then
		local hit_origin_distance = hit.attack_origin and Vector3.length(hit.position - hit.attack_origin) or 0

		self.network_router:transmit_to_all_others("rpc_apply_hit_advanced", hit.unit, hit.victim_position, hit.position, rotation_angle, hit_origin_distance, ability_name, settings_path, hit.damage_amount or 0, mask, hit.id, hit.stat_creditor_go_id)
	else
		self.network_router:transmit_to_all_others("rpc_apply_hit", hit.unit, hit.position, rotation_angle, ability_name, settings_path, mask, hit.id)
	end
end

AbilityEventHandler.send_status_effect_hit_to_others = function (self, hit, status_effect)
	EntityEventModifierManager:on_event(hit.unit, "hit", hit)
	EntityAux.call_master_interface(hit.unit, "i_hit_receiver", "hit", hit)

	local modifier_mask = ModifierHandler.pack_modifiers(hit.modifiers)

	self.network_router:transmit_to_all_others("rpc_apply_status_effect_hit", hit.unit, hit.ability_name, hit.settings_path, status_effect, hit.damage_amount, modifier_mask, hit.stat_creditor_go_id)
end

AbilityEventHandler.rpc_apply_status_effect_hit = function (self, sender, unit, ability_name, settings_path, status_effect, damage, modifier_mask, stat_creditor_go_id)
	local hit = StatusEffects.build_damage_hit_network(unit, ability_name, settings_path, status_effect, damage, stat_creditor_go_id)

	ModifierHandler.unpack_modifiers(hit, modifier_mask)
	EntityEventModifierManager:on_event(unit, "hit", hit)
	EntityAux.call_interface(unit, "i_hit_receiver", "hit", hit)
end

AbilityEventHandler.rpc_apply_hit_advanced = function (self, sender, victim_unit, victim_position, position, rotation_angle, hit_origin_distance, ability_name, settings_path, damage_amount, modifier_mask, id, stat_creditor_go_id)
	if victim_unit == nil then
		return
	end

	self:handle_apply_hit(sender, victim_unit, victim_position, position, rotation_angle, hit_origin_distance, ability_name, settings_path, damage_amount, modifier_mask, id, stat_creditor_go_id)
end

AbilityEventHandler.rpc_apply_hit = function (self, sender, victim_unit, position, rotation_angle, ability_name, settings_path, modifier_mask, id)
	if victim_unit == nil then
		return
	end

	self:handle_apply_hit(sender, victim_unit, nil, position, rotation_angle, 0, ability_name, settings_path, nil, modifier_mask, id, nil)
end

AbilityEventHandler.handle_apply_hit = function (self, sender, victim_unit, victim_position, position, rotation_angle, hit_origin_distance, ability_name, settings_path, damage_amount, modifier_mask, id, stat_creditor_go_id)
	local event_index = AbilityAux.event_from_hit_id(id)
	local ability = self:create_ability(nil, settings_path, ability_name, false)
	local event_settings = ability.events[event_index]
	local rotation = math.normalized_angle_to_quaternion(rotation_angle)
	local direction = Quaternion.forward(rotation)
	local hit = AbilityEventAux.build_hit_from_ability_event(victim_unit, ability_name, settings_path, event_settings, event_index, position, direction, true)

	ModifierHandler.unpack_modifiers(hit, modifier_mask)

	hit.stat_creditor_go_id = stat_creditor_go_id
	hit.id = id
	hit.sender = sender
	hit.victim_position = victim_position
	hit.attack_origin_box = Vector3Aux.box({}, position - direction * hit_origin_distance)
	hit.is_remote_hit = true
	hit.random_seed = hit.id * event_index
	hit.damage_amount = damage_amount or hit.settings.damage_amount or 0

	if hit.event_done then
		local event_id = AbilityAux.event_id_from_hit_id(hit.id)
		local dirty = false

		for i, event in ipairs(self.active_events) do
			if event_id == event.id then
				local pose = Matrix4x4.from_quaternion_position(rotation, position)

				if event.query_instance then
					event.query_instance:set_pose(event, pose)
				end

				if event.unit then
					if event.update_unit_position ~= false then
						Unit.set_local_pose(event.unit, 0, pose)
						World.update_unit(self.world_proxy:get_world(), event.unit)
					end

					if event.is_projectile then
						Unit.set_flow_variable(event.unit, "position", hit.position)
						Unit.set_flow_variable(event.unit, "incident_direction", hit.direction)
						Unit.set_flow_variable(event.unit, "blocking_unit", hit.unit)
						Unit.set_flow_variable(event.unit, "is_blocked", hit.blocked)
					end
				end

				dirty = true
				event.destroyed = true

				self:on_event_exit(event)
			end
		end

		if dirty then
			array.remove_all_where(self.active_events, "destroyed", true)
		end
	end

	self:send_hit(hit)
end

AbilityEventHandler.flow_ability_event = function (self, params)
	local unit = params.unit
	local ability_name = params.ability_name
	local victim = params.victim
	local valid_hit = EntityAux.has_interface(victim, "i_hit_receiver")

	if valid_hit then
		local position = params.position or Unit.local_position(victim, 0)
		local is_authorative = PredictionAux.is_event_authorative(unit, victim)

		if not is_authorative then
			return
		end

		local settings_path = Unit.get_data(unit, "settings_path")
		local info = self:create_ability(unit, settings_path, ability_name)
		local event_settings = info.events[1]
		local attacker_position = Unit.world_position(unit, 0)
		local hit = AbilityEventAux.build_hit_from_ability_event(victim, ability_name, settings_path, event_settings, 1, position, Vector3.normalize(position - attacker_position), is_authorative)
		local event = {
			index = 1,
			settings = event_settings,
			owner_unit = unit,
			caster_unit = unit,
		}

		event.id = AbilityAux.generate_event_id(EntityAux.go_id(unit), 0, 1)
		event.hit_id_counter = 1

		self:on_valid_hit(event, hit)
	end
end

AbilityEventHandler.environment_death = function (self, params)
	local victim = params.unit
	local death_type = params.type
	local valid_hit = EntityAux.has_interface(victim, "i_hit_receiver")

	if valid_hit then
		local position = Unit.world_position(victim, 0)
		local direction = -UnitAux.unit_forward(victim)
		local is_authorative = EntityAux.owned(victim)

		if not is_authorative then
			return
		end

		local settings_path = "characters/generic_abilities"
		local ability_name = death_type or "environment"
		local info = self:create_ability(victim, settings_path, ability_name)
		local event_settings = info.events[1]
		local hit = AbilityEventAux.build_hit_from_ability_event(victim, ability_name, settings_path, event_settings, 1, position, direction, is_authorative)
		local event = {
			index = 1,
			settings = event_settings,
		}

		event.id = AbilityAux.generate_event_id(EntityAux.go_id(victim), 0, 1)
		event.hit_id_counter = 1

		self:on_valid_hit(event, hit)
	end
end
