﻿-- chunkname: @lua/components/shock_receiver_component.lua

require("foundation/lua/component/base_component")
require("lua/managers/entity_event_modifier_manager")

ShockReceiverComponent = class("ShockReceiverComponent", "BaseComponent")

local MAX_GORY_DEATHS_PER_FRAME = 10

ShockReceiverComponent.init = function (self, creation_context)
	BaseComponent.init(self, "shock_receiver", creation_context, true)

	self.randomizer = Randomizer(creation_context.seed)

	self:register_dependencies("motion", "ability", "animation", "rotation")
	self:register_rpc_events("rpc_release_hit_id")
	self:register_interfaces("i_hit_receiver")

	self.nr_gory_deaths = 0
end

ShockReceiverComponent.reload_master = function (self, unit, context)
	context.num_commands = 0
end

ShockReceiverComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

ShockReceiverComponent.update = function (self, ...)
	self.nr_gory_deaths = 0

	BaseComponent.update(self, ...)
end

ShockReceiverComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.current_shock then
			self:update_shock(unit, context, dt)
		end
	end
end

ShockReceiverComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.current_shock then
			self:update_shock(unit, context, dt)
		end
	end
end

ShockReceiverComponent.update_shock = function (self, unit, context, dt)
	local state = context.state
	local info = state.current_shock

	info.timer = info.timer + dt

	if info.vacuum then
		if state.vacuum_origin then
			if not state.has_landed then
				local origin = Vector3Aux.unbox(state.vacuum_origin)
				local my_position = Unit.local_position(unit, 0)
				local towards_origin = origin - my_position
				local duration = (info.vacuum.duration or 30) / 30

				if duration > info.timer then
					EntityAux.command_immediately(unit, "motion", "set_velocity", towards_origin * (info.vacuum.force or 3))
				else
					EntityAux.command_immediately(unit, "motion", "set_velocity", Vector3.zero())

					state.has_landed = true
				end
			elseif EntityAux.owned(unit) then
				local settings = context.settings

				if info.play_getup_timestamp and info.timer >= info.play_getup_timestamp then
					info.play_getup_timestamp = nil
					info.hit_released = true

					self:trigger_rpc_event_to_others("rpc_release_hit_id", unit, info.id)
					EntityAux.queue_command_master(unit, "animation", "trigger_event", settings.getup_animation)
				end

				if info.timer >= info.duration then
					EntityAux.queue_command_master(unit, "motion", "clear_velocity")
					self:on_shock_exit(unit, state)
				end
			end
		end
	elseif info.knockback then
		if EntityAux.has_component_master(unit, "motion") then
			if not state.has_landed then
				if info.timer >= (state.make_sure_of_liftoff_time or 0.2) then
					state.has_landed = true

					local event = info.animation_event_touch_ground

					EntityAux.queue_command_master(unit, "animation", "trigger_event", event)
					Unit.flow_event(unit, "on_knockback_land")
				end
			else
				local settings = context.settings

				if info.play_getup_timestamp and info.timer >= info.play_getup_timestamp then
					info.play_getup_timestamp = nil
					info.hit_released = true

					self:trigger_rpc_event_to_others("rpc_release_hit_id", unit, info.id)
					EntityAux.queue_command_master(unit, "animation", "trigger_event", settings.getup_animation)
				end

				if info.timer >= info.duration then
					EntityAux.queue_command_master(unit, "motion", "clear_velocity")

					local knockdown_passout_duration = info.is_deathblow and 0 or (settings.knockdown_passout_duration or 0) / 30

					if knockdown_passout_duration > 0 and not info.knockback_hibrination then
						info.knockback_hibrination = true
						info.duration = info.duration + knockdown_passout_duration * math.random(0.9, 1.1)
						info.play_getup_timestamp = info.duration - (settings.getup_duration or 15) / 30
					else
						self:on_shock_exit(unit, state)
					end
				end
			end
		end
	else
		if not context.settings.animation_driven_movement then
			local movements = info.movements

			if movements then
				local forward = Quaternion.forward(Unit.local_rotation(unit, 0))

				for i, movement in ipairs(movements) do
					local window = movement.window

					if info.timer >= window[1] and info.timer < window[2] then
						local velocity = movement.speed * forward

						EntityAux.call(unit, "motion", "wanted_velocity", velocity)
					end
				end
			end
		end

		if info.exit_animation_frame and info.timer >= info.exit_animation_frame / 30 then
			EntityAux.queue_command_slave(unit, "animation", "trigger_event", info.exit_animation)

			info.exit_animation_frame = nil
		end

		if info.timer >= info.duration then
			self:on_shock_exit(unit, state)
		end
	end
end

ShockReceiverComponent.call_master_hit = function (self, unit, context, hit)
	if context.state.ignore_shocks and not hit.is_deathblow then
		return
	end

	self:handle_hit(unit, context, hit)
end

ShockReceiverComponent.call_prediction_hit = function (self, unit, context, hit)
	local state = context.state

	if state.ignore_shocks and not hit.is_deathblow then
		return
	end

	self:handle_hit(unit, context, hit)
end

ShockReceiverComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "clear" then
		self:on_shock_exit(unit, state)
	elseif command_name == "enable_shocks" then
		state.ignore_shocks = false
	elseif command_name == "disable_shocks" then
		self:on_shock_exit(unit, state)

		state.ignore_shocks = true
	end
end

ShockReceiverComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "release_hit_id" then
		EntityAux.command_immediately(unit, "animation", "set_ignore_rpc_animations", TempTableFactory:get_map("id", "shock", "state", "off"))

		if state.knockback_hits and state.knockback_hits[data.id] then
			if state.current_shock == nil or state.current_shock.id == data.id then
				self:on_hit_react_exit(unit, state, state.knockback_hits[data.id])
			end

			state.knockback_hits[data.id] = nil
		end
	end
end

ShockReceiverComponent.select_death = function (self, deaths, seed)
	local gore_enabled = Game.gore_enabled
	local total_weight = 0

	for key, data in pairs(deaths) do
		repeat
			if not gore_enabled and data.gore then
				break
			end

			total_weight = total_weight + (data.weight or 1)
		until true
	end

	local _, number = Math.next_random(seed)

	for key, data in pairs(deaths) do
		repeat
			if not gore_enabled and data.gore then
				break
			end

			number = number - (data.weight or 1) / total_weight

			if number <= 0 then
				return data
			end
		until true
	end
end

ShockReceiverComponent.should_interrupt = function (self, unit)
	local should_interrupt = true

	if EntityAux.has_component(unit, "ability") then
		local current_ability

		if EntityAux.has_component_master(unit, "ability") then
			current_ability = EntityAux.state_master(unit, "ability").current_ability
		else
			current_ability = EntityAux.state(unit, "ability").current_ability
		end

		should_interrupt = not current_ability or not current_ability.ignore_interrupt
	end

	return should_interrupt
end

ShockReceiverComponent.setup_knockback = function (self, unit, context, data, hit)
	local state = context.state

	EntityEventModifierManager:on_event(unit, "knockbacked", hit)

	local initiate_knockback = hit.victim_position ~= nil

	if initiate_knockback and context.settings.knockbackable_on_death == false and hit.is_deathblow then
		initiate_knockback = false
	end

	if initiate_knockback then
		EntityAux.queue_command(unit, "motion", "force_set_position", Vector3Aux.box({}, hit.victim_position))
		EntityAux.queue_command(unit, "motion", "clear_velocity")
		EntityAux.queue_command(unit, "motion", "clear_wanted_velocity")

		state.timer_on_ground = 0

		if not EntityAux.owned(unit) then
			EntityAux.queue_command(unit, "motion", "set_override_movement", true)
			EntityAux.queue_command_predictor(unit, "rotation", "lock_prediction")
		end

		EntityAux.queue_command(unit, "motion", "change_state", "dynamic")

		state.motion_state = "dynamic"

		Unit.flow_event(unit, "on_knockback")

		if data.vacuum then
			state.vacuum_origin = Vector3Aux.box_copy({}, hit.attack_origin_box)
			state.has_landed = false
		else
			local upward_speed = data.knockback.upward_speed
			local directional_speed = data.knockback.directional_speed

			if upward_speed == 0 then
				state.has_landed = true

				local event = data.animation_event_touch_ground

				if event then
					EntityAux.queue_command(unit, "animation", "trigger_event_local", event)
				end

				Unit.flow_event(unit, "on_knockback_land")
			else
				state.make_sure_of_liftoff_time = 0.2
				state.has_landed = false
			end

			local direction = Vector3Aux.unbox(data.direction)
			local velocity = Vector3.up() * upward_speed + direction * directional_speed

			EntityAux.queue_command(unit, "motion", "set_velocity", Vector3Aux.box(TempTableFactory:get(), velocity))
		end
	end

	if hit.settings and hit.settings.trigger_chained_knockback_ability ~= false and EntityAux.has_component(unit, "avatar") and data.knockback and not data.vacuum then
		local ability_name = data.knockback.ability_name or "knockback_breaker"
		local settings_path = "characters/generic_abilities"
		local ability_id = 0
		local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "stat_creditor_go_id", hit.stat_creditor_go_id, "execute_local_only", true, "ability_id", ability_id)

		EntityAux.queue_command(unit, "ability", "execute_ability", command)
	end
end

ShockReceiverComponent.select_hit_react = function (self, unit, context, hit)
	local hit_react_info = hit.hit_react_info
	local hit_react
	local blocked = hit.blocked

	if blocked then
		local ignore_block = hit.settings.ignore_block

		if ignore_block and ignore_block[self.name] then
			blocked = false
		end
	end

	if hit.is_deathblow then
		local death_hit_react = self:select_death(hit_react_info.death, hit.random_seed)

		hit_react = table.clone(death_hit_react)
		hit_react.duration = hit_react.duration or 30

		local settings = context.settings

		if settings.death_animation_override then
			self:queue_command(unit, "animation", "trigger_event_death", settings.death_animation_override)
		elseif hit_react.animation_event then
			self:queue_command(unit, "animation", "trigger_event_death", hit_react.animation_event)
		end

		if settings.ignore_knockbacks_on_death then
			hit_react.knockback = nil
		end
	elseif blocked then
		local blocker_state = EntityAux.state(unit, "blocker")
		local block_damage = hit.settings.block_damage or hit_react_info.block_damage or 0

		if blocker_state.block_health - block_damage <= 0 then
			hit_react = table.clone(hit_react_info.block_broken)

			if EntityAux.has_component_master(unit, "blocker") then
				EntityAux.call_master(unit, "blocker", "set_blocking", false)
			end

			EntityAux.command_immediately(unit, "ability", "force_interrupt", true)
		elseif block_damage > 0 then
			hit_react = table.clone(hit_react_info.blocked)
		else
			hit_react = table.clone(hit_react_info.blocked_light)
		end
	else
		if hit.ally_hit then
			hit_react = table.clone(hit_react_info.hit_ally or hit_react_info.hit)
		else
			hit_react = table.clone(hit_react_info.hit)
		end

		local is_offset_hit = hit_react.duration == 0 or hit_react.duration == nil

		if not is_offset_hit and EntityAux.has_component_master(unit, "blocker") then
			EntityAux.call_master(unit, "blocker", "set_blocking", false)
		end
	end

	return hit_react
end

ShockReceiverComponent.handle_hit = function (self, unit, context, hit)
	local state = context.state

	if not hit.hit_react_info then
		return
	end

	local hit_react = self:select_hit_react(unit, context, hit)
	local afps = _G.ANIMFRAMES_PER_SECOND

	if hit_react.passout_duration then
		hit_react.passout_duration = (hit_react.passout_duration or 0) / afps
	end

	hit_react.duration = (hit_react.duration or 0) / afps

	local movements = hit_react.movements

	if movements then
		for i, movement in ipairs(movements) do
			local window = {
				movement.window[1] / afps,
				movement.window[2] / afps,
			}

			movement.duration = window[2] - window[1]
			movement.window = window
			movement.speed = movement.translation / movement.duration
		end
	end

	if context.settings.always_ignore_knockbacks then
		hit_react.knockback = nil

		if context.settings.override_knockback_animation ~= false then
			hit_react.animation_event = "hit"
		end
	end

	local direction = hit.direction or -UnitAux.unit_forward(unit)
	local flat_direction_normalized = Vector3.normalize(Vector3(direction.x, direction.y, 0))
	local flat_direction_box = Vector3Aux.box({}, flat_direction_normalized)

	hit_react.direction = Vector3Aux.box_copy({}, flat_direction_box)

	if hit_react.ragdoll then
		if EntityAux.has_component(unit, "scale") then
			EntityAux.call_slave(unit, "scale", "force_reset")
		end

		Game:delay_action((hit_react.delay or 1) / 30, function ()
			if not EntityAux.is_alive_entity(unit) then
				return
			end

			Game:delay_frames(1, function ()
				if not EntityAux.is_alive_entity(unit) then
					return
				end

				Unit.animation_event(unit, "ragdoll")

				local flat_direction = Vector3Aux.unbox(flat_direction_box)
				local num_actors = Unit.num_actors(unit)

				EntityAux.call_slave(unit, "avatar", "set_ragdoll", true)

				for i = 1, num_actors do
					local actor = Unit.actor(unit, i - 1)

					if actor then
						local is_kinematic = Actor.is_kinematic(actor)
						local is_dynamic = Actor.is_dynamic(actor)

						if not is_kinematic and is_dynamic then
							local horizontal_velocity = flat_direction * (hit_react.ragdoll.directional_speed + (math.random() - 0.5))
							local vertical_velocity = Vector3.up() * (hit_react.ragdoll.upward_speed + (math.random() - 0.5))

							Actor.set_velocity(actor, horizontal_velocity + vertical_velocity)
						end
					end
				end
			end)
		end)
	end

	local duration = hit_react.duration
	local animation_event = hit_react.animation_event
	local is_offset_hit = duration == 0
	local is_knockback_hit = hit_react.knockback ~= nil or hit_react.vacuum ~= nil

	hit_react.is_deathblow = hit.is_deathblow

	local should_interrupt = hit.is_deathblow or not is_offset_hit and self:should_interrupt(unit, is_offset_hit)
	local should_predict = not hit.is_remote_hit and not EntityAux.owned(unit)

	if should_interrupt then
		EntityAux.command_immediately(unit, "ability", "interrupt", true)
		self:rotate_towards(unit, hit, should_predict)
		World.update_unit(self.world_proxy:get_world(), unit)
	end

	if hit.is_deathblow then
		if hit_react.gore ~= false and self.nr_gory_deaths <= MAX_GORY_DEATHS_PER_FRAME then
			self.nr_gory_deaths = self.nr_gory_deaths + 1

			if hit_react.flow_event then
				Unit.flow_event(unit, hit_react.flow_event)
			end

			if hit_react.gore_effect_type then
				hit.blocked = false
				hit.gore_effect_type = hit_react.gore_effect_type

				EntityAux.call(unit, "hit_react", "hit", hit)
			end

			if hit_react.gib_type then
				GibManager:gib_unit_lua(unit, hit_react.gib_type)
			end
		end
	elseif hit_react.flow_event then
		Unit.flow_event(unit, hit_react.flow_event)
	end

	hit_react.timer = 0

	if is_offset_hit then
		if animation_event ~= "nil" then
			self:queue_command(unit, "animation", "trigger_event_local", animation_event)
		end

		return
	end

	local set_as_current = false

	if state.current_shock then
		if duration > state.current_shock.timer or is_knockback_hit then
			self:on_hit_react_exit(unit, state, state.current_shock, true)

			set_as_current = true
		end
	else
		set_as_current = true
	end

	if set_as_current then
		if is_knockback_hit then
			EntityAux.queue_command(unit, "motion", "constrain_to_simple_mover", false)
			EntityAux.queue_command(unit, "motion", "set_collision_filter", "level_bound_mover")

			hit_react.id = hit.id

			self:setup_knockback(unit, context, hit_react, hit)

			if hit.id then
				state.knockback_hits = state.knockback_hits or {}
				state.knockback_hits[hit.id] = hit_react
			end

			if should_predict then
				hit_react.ignore_rpc_animations = true

				EntityAux.queue_command_predictor(unit, "rotation", "lock_prediction")
				self:queue_command_predictor(unit, "animation", "set_ignore_rpc_animations", TempTableFactory:get_map("id", "shock", "state", "on"))
			end
		end

		state.current_shock = table.clone(hit_react)
	elseif EntityAux.owned(unit) and hit.id then
		self:trigger_rpc_event_to_others("rpc_release_hit_id", unit, hit.id)
	end

	if animation_event ~= "nil" then
		self:queue_command(unit, "animation", "trigger_event_local", animation_event)
	end
end

ShockReceiverComponent.on_shock_exit = function (self, unit, state, hit_react)
	if state.current_shock == nil then
		return
	end

	self:on_hit_react_exit(unit, state, state.current_shock)

	state.current_shock = nil
end

ShockReceiverComponent.on_hit_react_exit = function (self, unit, state, hit_react, cancel_for_new_hitreact)
	local alive = DamageReceiverComponent.is_alive(unit)

	if hit_react.knockback then
		EntityAux.queue_command(unit, "ability", "force_interrupt")
		EntityAux.queue_command(unit, "motion", "constrain_to_simple_mover", true)
	end

	if state.motion_state == "dynamic" then
		if not EntityAux.owned(unit) and not cancel_for_new_hitreact then
			EntityAux.queue_command(unit, "motion", "set_override_movement", false)
			EntityAux.queue_command_predictor(unit, "rotation", "unlock_prediction")
		end

		if alive then
			EntityAux.queue_command(unit, "motion", "change_state", "default")
		end
	end

	if not hit_react.hit_released and EntityAux.owned(unit) and hit_react.id then
		self:trigger_rpc_event_to_others("rpc_release_hit_id", unit, hit_react.id)
	end

	if hit_react.duration > 0 and alive then
		EntityAux.queue_command(unit, "motion", "set_collision_filter", nil)
	end
end

ShockReceiverComponent.command_slave = function (self, unit, context, command_name, data)
	return
end

ShockReceiverComponent.rotate_towards = function (self, unit, hit, should_predict)
	local direction = hit.direction
	local to_attacker = Vector3.normalize(Vector3(-direction.x, -direction.y, 0))

	Unit.set_local_rotation(unit, 0, Quaternion.look(to_attacker))

	if should_predict then
		self:queue_command_predictor(unit, "rotation", "set_rotation_towards", Vector3Aux.box(TempTableFactory:get(), to_attacker))
	elseif EntityAux.owned(unit) then
		self:queue_command_master(unit, "rotation", "set_rotation_towards", Vector3Aux.box(TempTableFactory:get(), to_attacker))
	end
end

ShockReceiverComponent.rpc_release_hit_id = function (self, sender, victim_unit, id)
	if not victim_unit then
		return
	end

	self:queue_command_predictor(victim_unit, self.name, "release_hit_id", TempTableFactory:get_map("id", id))
end
