﻿-- chunkname: @lua/components/template_component.lua

require("foundation/lua/component/base_component")

TemplateComponent = class("TemplateComponent", "BaseComponent")

TemplateComponent.init = function (self, creation_context)
	BaseComponent.init(self, "template", creation_context)
end

TemplateComponent.reload_master = function (self, unit, context)
	return
end

TemplateComponent.reload_slave = function (self, unit, context)
	return
end

TemplateComponent.setup_master = function (self, unit, context, setup_info)
	return
end

TemplateComponent.setup_slave = function (self, unit, context, setup_info)
	return
end

TemplateComponent.remove_master = function (self, unit, context)
	return
end

TemplateComponent.remove_slave = function (self, unit, context)
	return
end

TemplateComponent.update_masters = function (self, entities, dt)
	return
end

TemplateComponent.update_slaves = function (self, entities, dt)
	return
end

TemplateComponent.command_master = function (self, unit, context, command_name, data)
	return
end

TemplateComponent.command_slave = function (self, unit, context, command_name, data)
	return
end

TemplateComponent.setup_console_plugin = function (self)
	return
end
