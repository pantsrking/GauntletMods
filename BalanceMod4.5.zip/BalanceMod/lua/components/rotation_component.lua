﻿-- chunkname: @lua/components/rotation_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/util/gui_aux")

local DEFAULT_TURNS_PER_SECOND = 0.5
local DEFAULT_ROTATION_SPEED = math.tau * DEFAULT_TURNS_PER_SECOND

RotationComponent = class("RotationComponent", "BaseComponent")

RotationComponent.init = function (self, creation_context)
	BaseComponent.init(self, "rotation", creation_context, true)

	self.use_dirty_optimization = true
	self.rotation_component_aux = RotationComponentAux()
end

local function _add_to_rotation_aux(rotation_component_aux, unit, state)
	state.rotation_state = RotationComponentAux.add_unit(rotation_component_aux, unit)
end

RotationComponent.migrated_away = function (self, unit, slave_context, master_context)
	local num_commands = master_context.num_commands

	for i = 1, num_commands do
		local command = master_context.command_queue[i]

		if command.key == "set_rotation_towards" or command.key == "set_rotation" then
			EntityAux.queue_command_slave(unit, self.name, command.key, command.data)
		end
	end
end

RotationComponent.migrated_to_me = function (self, unit, slave_context, master_context, setup_info)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context, setup_info)
	RotationState.set_game_object_id(master_context.state.rotation_state, EntityAux.go_id(unit))
end

RotationComponent.reload_master = function (self, unit, context)
	context.num_commands = 0

	RotationState.set_rotation_speed(context.state.rotation_state, context.settings.rotationspeed or DEFAULT_ROTATION_SPEED)
end

RotationComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

RotationComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.rotation_angle = math.normalized_angle_from_direction(Quaternion.forward(Unit.world_rotation(unit, 0)))
	state.wanted_rotation_angle = state.rotation_angle

	local ref_handler = self.entity_spawner:get_entity_reference_handler()

	ref_handler:add_handle_by_name(context.state, "rotate_towards_unit")

	state.rotation_disabled_mixer = RefMixer()
	state.rotation_disabled = false

	_add_to_rotation_aux(self.rotation_component_aux, unit, state)
	RotationState.set_rotation_speed(state.rotation_state, context.settings.rotationspeed or DEFAULT_ROTATION_SPEED)
end

RotationComponent.setup_slave = function (self, unit, context, setup_info)
	if EntityAux.has_component_master(unit, self.name) then
		RotationState.set_game_object_id(EntityAux._state_master_raw(unit, self.name).rotation_state, EntityAux.go_id(unit))
	end
end

RotationComponent.remove_master = function (self, unit, context)
	local ref_handler = self.entity_spawner:get_entity_reference_handler()

	ref_handler:remove_handle_by_name(context.state, "rotate_towards_unit")
	RotationComponentAux.remove_unit(self.rotation_component_aux, unit)
end

local function _wrap_norm_angle(r)
	r = r % 1

	if r <= -0.5 then
		return r + 1
	elseif r > 0.5 then
		return r - 1
	else
		return r
	end
end

local function _rotate_norm_angle_towards(source, destination, speed, dt)
	local direction = math.sign(destination - source)
	local distance = math.abs(destination - source)

	if distance > 0.5 then
		direction = -direction
	end

	local next_step = _wrap_norm_angle(source + direction * speed * dt)
	local distance_before = distance
	local distance_after = math.abs(destination - next_step)

	if distance_before > 0.5 then
		distance_before = 1 - distance_before
	end

	if distance_after > 0.5 then
		distance_after = 1 - distance_after
	end

	local was_closer_before = distance_before < distance_after

	return was_closer_before and destination or next_step
end

RotationComponent.update_masters = function (self, entities, dt)
	if dt > math.EPSILON then
		local network_session = self.network_session_handler:get_network_session()

		RotationComponentAux.update(self.rotation_component_aux, network_session, dt)
	end
end

RotationComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local p_state = context.prediction_state

		if p_state.override_rotation then
			state.rotation_angle = p_state.rotation_angle
		elseif p_state.rotation then
			if p_state.override_rotation_timer then
				p_state.override_rotation_timer = p_state.override_rotation_timer - dt

				if p_state.override_rotation_timer <= 0 then
					p_state.rotation = nil
					p_state.override_rotation_timer = nil
				end
			end

			if p_state.rotation then
				state.rotation_angle = math.normalized_angle_from_quaternion(QuaternionAux.unbox(p_state.rotation))
			end
		else
			local target_angle = state.rotation_angle
			local current_angle = p_state.rotation_angle or target_angle

			if not math.equals(current_angle, target_angle, 1e-05) then
				local diff = _wrap_norm_angle(current_angle) - _wrap_norm_angle(target_angle)
				local angle

				if math.abs(diff) > 0.2 then
					angle = target_angle
				else
					local fixed_prediction_rotation_speed = context.settings.fixed_prediction_rotation_speed

					if fixed_prediction_rotation_speed then
						angle = _rotate_norm_angle_towards(current_angle - 0.5, target_angle - 0.5, fixed_prediction_rotation_speed, dt) + 0.5
					else
						local speed = math.abs(target_angle - current_angle) * 3

						angle = _rotate_norm_angle_towards(current_angle - 0.5, target_angle - 0.5, math.clamp(speed, 0.2, 1), dt) + 0.5
					end
				end

				p_state.rotation_angle = angle
				state.rotation_angle = angle
			else
				p_state.rotation_angle = current_angle
			end
		end

		if state.previous_rotation_angle ~= state.rotation_angle then
			state.previous_rotation_angle = state.rotation_angle

			Unit.set_local_rotation(unit, 0, math.normalized_angle_to_quaternion(state.rotation_angle))
		end
	end
end

RotationComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "rotate_towards_unit" then
		RotationState.set_target_unit(state.rotation_state, data)
	elseif command_name == "rotate_towards" then
		RotationState.rotate_towards(state.rotation_state, Vector3Aux.unbox(data))
	elseif command_name == "set_rotation" then
		RotationState.set_rotation(state.rotation_state, QuaternionAux.unbox(data))
	elseif command_name == "set_rotation_towards" then
		RotationState.set_rotation_towards(state.rotation_state, Vector3Aux.unbox(data))
	elseif command_name == "set_rotation_speed" then
		RotationState.set_rotation_speed(state.rotation_state, data)
	elseif command_name == "enable" then
		state.rotation_disabled_mixer:remove(data)

		state.rotation_disabled = state.rotation_disabled_mixer:get()

		RotationState.set_enabled(state.rotation_state, not state.rotation_disabled)
	elseif command_name == "disable" then
		state.rotation_disabled_mixer:add(data, true)

		state.rotation_disabled = state.rotation_disabled_mixer:get()

		RotationState.set_enabled(state.rotation_state, not state.rotation_disabled)
	end
end

RotationComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set_rotation_towards" then
		local p_state = context.prediction_state
		local direction = Vector3Aux.unbox(data)

		if Vector3.length(direction) > math.EPSILON then
			local rotation = Quaternion.look(direction, Vector3.up())

			p_state.rotation = QuaternionAux.box({}, rotation)
			p_state.override_rotation_timer = 0.2 + Network.ping(EntityAux.owner(unit)) * 2
		end

		return true
	elseif command_name == "lock_prediction" then
		local p_state = context.prediction_state

		p_state.override_rotation_timer = nil

		return true
	elseif command_name == "unlock_prediction" then
		local p_state = context.prediction_state

		p_state.rotation = nil

		return true
	elseif command_name == "set_override_rotation" then
		local p_state = context.prediction_state

		p_state.override_rotation = data

		if data then
			p_state.rotation_angle = state.rotation_angle
		else
			p_state.rotation_angle = nil
		end

		return true
	end
end
