﻿-- chunkname: @lua/components/morak_component.lua

require("foundation/lua/component/base_component")

MorakComponent = class("MorakComponent", "BaseComponent")

MorakComponent.init = function (self, creation_context)
	BaseComponent.init(self, "morak", creation_context)
end

MorakComponent.update = function ()
	return
end
