﻿-- chunkname: @lua/components/cutscene_actor_component.lua

require("foundation/lua/component/base_component")
require("lua/managers/cutscene_manager")

CutsceneActorComponent = class("CutsceneActorComponent", "BaseComponent")

CutsceneActorComponent.init = function (self, creation_context)
	BaseComponent.init(self, "cutscene_actor", creation_context)
end

CutsceneActorComponent.update = function (self, dt)
	return
end

CutsceneActorComponent.call_master_start = function (self, unit, context, data)
	context.state.active = true
end

CutsceneActorComponent.call_master_stop = function (self, unit, context, data)
	context.state.active = false
end
