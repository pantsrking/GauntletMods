﻿-- chunkname: @lua/components/animated_interaction_component.lua

require("foundation/lua/component/base_component")

AnimatedInteraction = class("AnimatedInteraction", "BaseComponent")

AnimatedInteraction.init = function (self, creation_context, name)
	BaseComponent.init(self, name or "animated_interaction", creation_context)
	self:register_dependencies("animation")
	self:register_interfaces("i_trap")
	self:register_flow_events("interaction_set_as_done")
	self:register_rpc_events("rpc_interaction_activate_button_mash", "rpc_interaction_deactivate_button_mash")
end

AnimatedInteraction.setup_slave = function (self, unit, context, setup_info)
	if Unit.has_animation_state_machine(unit) then
		context.state.progress_variable = Unit.animation_find_variable(unit, "progress")
	end

	local state = context.state

	if state.done then
		EntityAux.queue_command_slave(unit, self.name, "set_as_done")
	end
end

AnimatedInteraction.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings

		if not state.initiated then
			if settings.start_condition then
				state.initiated = settings.start_condition(unit, state)
			else
				state.initiated = true
			end
		end

		if state.initiated and not state.done then
			if state.active or state.automatic then
				state.timer = (state.timer or 0) + dt

				local stage_info = settings.progression_stages[state.stage]
				local t = math.is_zero(stage_info.duration) and 1 or state.timer / stage_info.duration

				if state.progress == 0 and t > 0 and stage_info.flow_event_enter then
					self:trigger_rpc_event("flow_event", unit, stage_info.flow_event_enter)
				end

				if t >= 1 then
					state.stage = state.stage + 1
					state.timer = 0

					if state.stage > #settings.progression_stages then
						state.done = true
						state.progress = 1
						state.automatic = false

						if stage_info.on_exit then
							stage_info.on_exit(self, unit, context)
						end
					else
						state.progress = 0
						state.activation_time = _G.GAME_TIME

						local new_stage_info = settings.progression_stages[state.stage]

						state.automatic = new_stage_info.automatic

						if new_stage_info.on_enter then
							new_stage_info.on_enter(self, unit, context)
						end
					end

					if stage_info.animation_event then
						self:queue_command_master(unit, "animation", "trigger_event", stage_info.animation_event)
					end

					if stage_info.flow_event_exit then
						self:trigger_rpc_event("flow_event", unit, stage_info.flow_event_exit)
					end
				else
					state.progress = t
				end
			elseif state.progress > 0 then
				state.timer = (state.timer or 0) - dt * (settings.retraction_speed or 1)
				state.timer = math.max(state.timer, 0)

				local stage_info = settings.progression_stages[state.stage]

				state.progress = math.saturate(state.timer / stage_info.duration)

				if state.progress == 0 and stage_info.flow_event_reverted then
					self:trigger_rpc_event("flow_event", unit, stage_info.flow_event_reverted)
				end
			else
				state.timer = 0
			end
		end
	end
end

AnimatedInteraction.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		if Unit.has_animation_state_machine(unit) then
			local state = context.state

			Unit.animation_set_variable(unit, state.progress_variable, state.progress)
		end
	end
end

AnimatedInteraction.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "activate" then
		state.active_ref_count = (state.active_ref_count or 0) + 1
		state.active = true
	elseif command_name == "deactivate" then
		state.active_ref_count = state.active_ref_count - 1
		state.active = state.active_ref_count > 0
	elseif command_name == "activate_button_mash" then
		state.active = true
	elseif command_name == "deactivate_button_mash" then
		state.active = false
	elseif command_name == "set_as_done" then
		state.done = true

		local settings = context.settings

		state.stage = #settings.progression_stages
		state.progress = 1

		local stage_info = settings.progression_stages[#settings.progression_stages]

		if stage_info.animation_event then
			Unit.animation_event(unit, stage_info.animation_event)
		end

		if stage_info.flow_event_exit then
			Unit.flow_event(unit, stage_info.flow_event_exit)
		end
	elseif command_name == "reset" then
		state.done = false
		state.stage = 1
		state.progress = 0

		self:queue_command_master(unit, "animation", "trigger_event", "reset")
	end
end

AnimatedInteraction.command_slave = function (self, unit, context, command_name, data)
	if command_name == "activate" then
		-- Nothing
	elseif command_name == "deactivate" then
		-- Nothing
	elseif command_name == "reset" then
		-- Nothing
	elseif command_name == "set_as_done" then
		local settings = context.settings
		local stage_info = settings.progression_stages[#settings.progression_stages]

		if stage_info.animation_event then
			Unit.animation_event(unit, stage_info.animation_event)
		end

		if stage_info.flow_event_exit then
			Unit.flow_event(unit, stage_info.flow_event_exit)
		end
	end
end

AnimatedInteraction.interaction_set_as_done = function (self, params)
	EntityAux.command_immediately(params.unit, self.name, "set_as_done")
end

AnimatedInteraction.rpc_interaction_activate_button_mash = function (self, sender, unit)
	if unit == nil then
		return
	end

	EntityAux.queue_command_master(unit, self.name, "activate_button_mash")
end

AnimatedInteraction.rpc_interaction_deactivate_button_mash = function (self, sender, unit)
	if unit == nil then
		return
	end

	EntityAux.queue_command_master(unit, self.name, "deactivate_button_mash")
end
