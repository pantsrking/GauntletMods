﻿-- chunkname: @lua/components/interactable_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/managers/broadphase_manager")

InteractableComponent = class("InteractableComponent", "BaseComponent")
InteractableComponent.BROADPHASE_ID = "interactables"
InteractableComponent.BROADPHASE_MAX_RADIUS = 5
InteractableComponent.RESULT_SUCCESS = 0
InteractableComponent.RESULT_CRITERIA_NOT_MET = 1
InteractableComponent.RESULT_INTERACT_DISABLED = 2
InteractableComponent.REQUEST_SUCCESS = 0
InteractableComponent.REQUEST_CRITERIA_NOT_MET = 1
InteractableComponent.MIGRATION_ERROR = -1
InteractableComponent.MIGRATION_DONE = 0
InteractableComponent.MIGRATION_WAIT = 1
InteractableComponent.MIGRATION_WAIT_FOR_ACCEPTED = 2

InteractableComponent.init = function (self, creation_context)
	BaseComponent.init(self, "interactable", creation_context, true)

	self.hud = creation_context.hud

	self:register_events("on_interact_result", "on_entity_unregistering", "on_world_unload")
	self:register_rpc_events("rpc_interact_result", "rpc_interact_request")
	BroadphaseManager:create(InteractableComponent.BROADPHASE_ID, InteractableComponent.BROADPHASE_MAX_RADIUS, 200)

	self.debug_draw = Application.user_setting("slayer", "debug", "interactable") or false
	self.active_interactors = {}
end

InteractableComponent.destroy = function (self)
	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		self:remove_slave(unit, context)
	end

	BroadphaseManager:destroy(InteractableComponent.BROADPHASE_ID)
	BaseComponent.destroy(self)
end

InteractableComponent.on_script_reload = function (self)
	BaseComponent.on_script_reload(self)

	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state

		if state.widget then
			GUI:destroy_widget(state.widget)

			state.widget = nil
		end
	end
end

InteractableComponent.add_interactor_watch = function (self, interactor_unit, interactable_unit)
	local active_interactors = self.active_interactors[interactor_unit] or {}

	active_interactors[interactable_unit] = true
	self.active_interactors[interactor_unit] = active_interactors
end

InteractableComponent.remove_interactor_watch = function (self, interactor_unit, interactable_unit)
	local active_interactors = self.active_interactors[interactor_unit]

	if active_interactors == nil then
		return
	end

	active_interactors[interactable_unit] = nil
end

InteractableComponent.migrated_to_me = function (self, unit, slave_context, master_context, setup_info)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context, setup_info)

	local master_state = master_context.state
	local slave_state = slave_context.state

	if slave_state.cancelled_interaction then
		master_state.enabled = true
		slave_state.enabled = true
		slave_state.cancelled_interaction = nil
		slave_state.accepted_interactor = nil
		slave_state.pending_migrations = nil

		self.replicator:write_fields(master_context)
	elseif slave_state.accepted_interactor then
		master_state.enabled = false

		local interactor_unit = slave_state.accepted_interactor.interactor_unit

		master_state.locked_by_interactor_unit = interactor_unit

		self:add_interactor_watch(interactor_unit, unit)

		slave_state.enabled = false
		slave_state.accepted_interactor = nil
		slave_state.pending_migrations = nil

		self.replicator:write_fields(master_context)
	elseif slave_state.pending_migrations then
		master_state.enabled = true
		slave_state.enabled = true

		for interactor_unit, _ in pairs(slave_state.pending_migrations) do
			self:command_master(unit, master_context, "interact_request", TempTableFactory:get_map("interactor_unit", interactor_unit, "expected_result", InteractableComponent.RESULT_SUCCESS))
		end

		slave_state.pending_migrations = nil

		self.replicator:write_fields(master_context)
	else
		master_state.enabled = true
		slave_state.enabled = true

		self.replicator:write_fields(master_context)
	end
end

InteractableComponent.migrated_away = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_away(self, unit, slave_context, master_context)

	for interactor_unit, interactables in pairs(self.active_interactors) do
		interactables[unit] = nil
	end
end

InteractableComponent.reload_slave = function (self, unit, context)
	self:setup_reloadables(unit, context)

	local state = context.state

	if state.enabled and state.enabled == state.previous_enabled then
		BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
		BroadphaseManager:add(InteractableComponent.BROADPHASE_ID, unit, UnitAux.unit_center(unit), context.state.radius)
	end
end

InteractableComponent.setup_reloadables = function (self, unit, context)
	local state, settings = context.state, context.settings

	if settings.interactable_radius then
		state.radius = settings.interactable_radius
	else
		local extents = UnitAux.unit_extents(unit)

		state.radius = math.max(extents.x, extents.y)
		state.radius = math.max(state.radius, 0.5)
	end
end

InteractableComponent.setup_master = function (self, unit, context)
	local state, settings = context.state, context.settings
	local delay = settings.interactable_enable_delay

	if delay and delay > 0 then
		Game:delay_action(delay, function ()
			if EntityAux.is_alive_entity(unit) then
				self:set_and_sync_enabled(unit, context, true)
			end
		end)
	else
		state.enabled = true
	end

	if settings.interactable_disable_on_death ~= false then
		self:register_unit_events(unit, "unit_on_death")
	end
end

InteractableComponent.remove_master = function (self, unit, context)
	if context.settings.interactable_disable_on_death ~= false then
		self:unregister_unit_event(unit, "unit_on_death")
	end
end

InteractableComponent.setup_slave = function (self, unit, context)
	local state = context.state

	state.previous_enabled = nil

	local position = Unit.world_position(unit, 0)

	state.previous_position = Vector3Aux.box({}, position)

	self:setup_reloadables(unit, context)

	if EntityAux.has_component_master(unit, self.name) then
		local delay = context.settings.interactable_enable_delay

		if not delay or delay == 0 then
			self:set_and_sync_enabled(unit, EntityAux._context_master_raw(unit, self.name), true)
		end
	end
end

InteractableComponent.remove_slave = function (self, unit, context)
	local state = context.state

	if state.widget then
		GUI:destroy_widget(state.widget)

		state.widget = nil
	end

	BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
end

InteractableComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)
	local prediction_entities = entity_manager:get_prediction_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("filter_slave_commands")
	self:filter_slave_commands(prediction_entities)
	Profiler.stop()
	Profiler.start("update_predictors")
	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

InteractableComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local p_state, state = context.prediction_state, context.state

		if p_state.enabled ~= nil then
			state.enabled = p_state.enabled
		end
	end
end

InteractableComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.enabled ~= state.previous_enabled then
			if state.enabled then
				Unit.flow_event(unit, "on_interactable_enabled")
				BroadphaseManager:add(InteractableComponent.BROADPHASE_ID, unit, UnitAux.unit_center(unit), state.radius)
			elseif state.previous_enabled then
				Unit.flow_event(unit, "on_interactable_disabled")
				BroadphaseManager:remove(InteractableComponent.BROADPHASE_ID, unit)
			end

			state.previous_enabled = state.enabled

			if context.settings.on_interact_enabled_changed then
				context.settings.on_interact_enabled_changed(unit, state.enabled)
			end
		end

		if state.enabled then
			local udpate_broadphase = context.settings.interactable_broadphase_move

			if udpate_broadphase and state.enabled then
				local position = UnitAux.unit_center(unit)

				if not Vector3.equal_2d(position, state.previous_position) then
					state.previous_position = Vector3Aux.box(state.previous_position, position)

					BroadphaseManager:move(InteractableComponent.BROADPHASE_ID, unit, position)
				end
			end
		end

		if not context.settings.interact_on_contact then
			self:draw_ui(unit, context, dt)
		end
	end
end

InteractableComponent.set_and_sync_enabled = function (self, unit, context, value)
	context.state.enabled = value

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).enabled = value
end

InteractableComponent.check_interaction_migration_status = function (interactor_unit, interactable_unit)
	if EntityAux.owned(interactable_unit) then
		return InteractableComponent.MIGRATION_DONE
	else
		local state = EntityAux.state(interactable_unit, "interactable")

		if state.accepted_interactor then
			local info = state.accepted_interactor

			if info.original_owner ~= EntityAux.owner(interactable_unit) then
				return InteractableComponent.MIGRATION_ERROR
			end

			return InteractableComponent.MIGRATION_WAIT
		else
			return InteractableComponent.MIGRATION_WAIT_FOR_ACCEPTED
		end
	end
end

InteractableComponent.command_master = function (self, unit, context, command_name, data)
	local state, settings = context.state, context.settings

	if command_name == "interact_request" then
		local interactor_unit = data.interactor_unit

		if not Unit.alive(interactor_unit) then
			return
		end

		local result

		if not state.enabled then
			result = InteractableComponent.RESULT_INTERACT_DISABLED
		else
			local success

			if data.expected_result == InteractableComponent.REQUEST_CRITERIA_NOT_MET then
				success = false
			else
				success = settings.interactable_allow_interact(self, unit, interactor_unit)

				if success and settings.disable_on_interact ~= false then
					self:set_and_sync_enabled(unit, context, false)

					if settings.lock_by_interactor ~= false then
						state.locked_by_interactor_unit = interactor_unit

						self:add_interactor_watch(interactor_unit, unit)
					end
				end
			end

			result = success and InteractableComponent.RESULT_SUCCESS or InteractableComponent.RESULT_CRITERIA_NOT_MET
		end

		local settings_path = LuaSettingsManager:get_settings_path_by_unit_path(Unit.get_data(unit, "unit_path"))

		self:trigger_event("on_interact_result", unit, interactor_unit, result, settings_path)
		self:trigger_rpc_event_to_others("rpc_interact_result", unit, interactor_unit, result, settings_path)

		local success = result == InteractableComponent.RESULT_SUCCESS

		if success and settings.require_migration and not EntityAux.owned(interactor_unit) then
			self:migrate_unit_to(unit, EntityAux.owner(interactor_unit))
		end
	elseif command_name == "set_enabled" then
		self:set_and_sync_enabled(unit, context, data)

		if state.enabled and state.locked_by_interactor_unit then
			self:remove_interactor_watch(state.locked_by_interactor_unit, unit)

			state.locked_by_interactor_unit = nil
		end
	elseif command_name == "destroy" then
		self:set_and_sync_enabled(unit, context, false)

		if state.locked_by_interactor_unit then
			self:remove_interactor_watch(state.locked_by_interactor_unit, unit)

			state.locked_by_interactor_unit = nil
		end
	end
end

InteractableComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local p_state = context.prediction_state

	if command_name == "destroy" then
		p_state.enabled = false

		return true
	elseif command_name == "pending_interact_migration" then
		local state = context.state
		local pending_migrations = state.pending_migrations or {}

		pending_migrations[data] = true
		state.pending_migrations = pending_migrations
	elseif command_name == "set_accepted_interactor" then
		context.state.accepted_interactor = {
			interactor_unit = data,
			original_owner = EntityAux.owner(unit),
		}
	elseif command_name == "set_cancelled_interaction" then
		context.state.cancelled_interaction = true
	end
end

InteractableComponent.unit_on_death = function (self, unit)
	self:queue_command_master(unit, self.name, "set_enabled", false)
end

InteractableComponent.on_entity_unregistering = function (self, unit)
	for interactor_unit, interactables in pairs(self.active_interactors) do
		if unit == interactor_unit then
			for interactable_unit, _ in pairs(interactables) do
				EntityAux.queue_command_master(interactable_unit, self.name, "set_enabled", true)
			end

			self.active_interactors[unit] = nil

			break
		elseif interactables[unit] then
			interactables[unit] = nil
		end
	end
end

InteractableComponent.on_world_unload = function (self)
	self.active_interactors = {}
end

InteractableComponent.on_interact_result = function (self, interactable_unit, interactor_unit, result, interactable_settings_path)
	if result == InteractableComponent.RESULT_INTERACT_DISABLED then
		return
	end

	local success

	success = (interactor_unit or false) and result == InteractableComponent.RESULT_SUCCESS

	local settings = LuaSettingsManager:get_settings_by_unit(interactable_unit)

	settings.interactable_interact_result(self, interactable_unit, interactor_unit, success)

	if success and settings.require_migration and EntityAux.owned(interactor_unit) and not EntityAux.owned(interactable_unit) then
		EntityAux.command_immediately(interactable_unit, self.name, "set_accepted_interactor", interactor_unit)
	end
end

InteractableComponent.rpc_interact_request = function (self, sender, interactable_unit, interactor_unit, expected_result, interactable_settings_path)
	if not interactable_unit then
		local result = InteractableComponent.RESULT_INTERACT_DISABLED

		self:trigger_event("on_interact_result", nil, interactor_unit, result, interactable_settings_path)
		self:trigger_rpc_event_to_others("rpc_interact_result", nil, interactor_unit, result, interactable_settings_path)

		return
	end

	if not interactor_unit then
		return
	end

	if not EntityAux.owned(interactable_unit) then
		return
	end

	self:queue_command_master(interactable_unit, self.name, "interact_request", TempTableFactory:get_map("interactor_unit", interactor_unit, "expected_result", expected_result))
end

InteractableComponent.rpc_interact_result = function (self, sender, interactable_unit, interactor_unit, result, interactable_settings_path)
	if interactable_unit == nil then
		local result = InteractableComponent.RESULT_INTERACT_DISABLED

		self:trigger_event("on_interact_result", nil, interactor_unit, result, interactable_settings_path)

		return
	end

	if EntityAux.owner(interactable_unit) ~= sender then
		return
	end

	self:trigger_event("on_interact_result", interactable_unit, interactor_unit, result, interactable_settings_path)
end

InteractableComponent._get_interactors_for = function (self, interactable_unit)
	local player_infos = TempTableFactory:get()
	local interactor_entities = self.entity_manager:get_master_entities("interactor")

	for interactor_unit, interactor_context in pairs(interactor_entities) do
		local interactor_state = interactor_context.state
		local current_info = interactor_state.best_interactable_info

		if current_info.active and current_info.interactable_unit == interactable_unit then
			local player_info = PlayerManager:get_player_info_by_avatar(interactor_unit)

			if player_info then
				local is_busy = EntityAux.state_master(interactor_unit, "avatar").animation_busy or EntityAux.state_master(interactor_unit, "ability").is_busy

				if not is_busy then
					player_infos[#player_infos + 1] = player_info
				end
			end
		end
	end

	return player_infos
end

InteractableComponent.draw_ui = function (self, interactable_unit, interactable_context, dt)
	Profiler.start("InteractableComponent:draw_ui")

	local interactable_settings = LuaSettingsManager:get_settings_by_unit(interactable_unit)
	local state = interactable_context.state

	state.popup_alpha = state.popup_alpha or 0

	local player_infos = self:_get_interactors_for(interactable_unit)
	local FADE_IN_TIME = 0.2
	local FADE_OUT_TIME = 0.2

	if player_infos and #player_infos > 0 then
		state.popup_alpha = math.saturate(state.popup_alpha + dt / FADE_IN_TIME)

		table.sort(player_infos, function (a, b)
			return a.avatar_go_id < b.avatar_go_id
		end)

		local world_proxy = WorldManager:get_world_proxy("game_world")
		local viewport = world_proxy:viewport("game_viewport")
		local pos_world = UnitAux.unit_center(interactable_unit)
		local pos_pixels = viewport:world_to_screen(pos_world)

		if pos_pixels.z < 0 then
			if state.widget then
				state.widget:set_visible(false)
			end
		else
			local interact_text_layer = 0
			local has_cost = interactable_settings.cost ~= nil
			local widget = state.widget

			if not widget then
				local widget_text = interactable_settings.interact_text

				if has_cost then
					widget = GUI:load_widget_at("gui/interact_price_ui")
				else
					widget = GUI:load_widget_at("gui/interact_ui")
				end

				if widget_text then
					local text_widget = widget:get("interact_text")

					text_widget:set_text(tr(widget_text))

					if has_cost then
						local cost_widget = widget:get("interact_cost")

						cost_widget:set_text(sprintf("%d", interactable_settings.cost))
					end
				end

				widget:finalize_layout(0)
				GUI:add_widget(widget)

				state.widget = widget
			end

			widget:set_visible(true)

			local pos_points = GUI:pixels_to_points(pos_pixels)
			local w, h = widget:get_size()

			pos_points.x = pos_points.x - 0.5 * w
			pos_points.y = pos_points.y - h - 48

			widget:set_pos({
				pos_points.x,
				pos_points.y,
			})
			widget:set_alpha(state.popup_alpha)

			interact_text_layer = 0

			local color = Color.from_normalized_rgba(1, 1, 1, state.popup_alpha)
			local widget_pos_px = GUI:points_to_pixels(pos_points)

			pos_pixels = Vector3(pos_pixels.x, widget_pos_px.y, interact_text_layer)

			local pos_px = Vector3.copy(pos_pixels, 0, -(has_cost and 80 or 70))

			pos_px.z = interact_text_layer

			local button_size_px = Vector2(25, 25)
			local pad_player = false
			local key_player = false

			for _, player_info in ipairs(player_infos) do
				if player_info.controller_name == _G.INPUT_USER_KEYBOARD_MOUSE then
					key_player = true
				else
					pad_player = true
				end
			end

			if pad_player and key_player then
				pos_px.x = pos_px.x - button_size_px.x
			end

			local done_pad_already = false

			for _, player_info in ipairs(player_infos) do
				local controller_name = player_info.controller_name
				local is_pad = controller_name ~= _G.INPUT_USER_KEYBOARD_MOUSE

				if not is_pad or is_pad and not done_pad_already then
					local size_px_copy = Vector2(button_size_px.x, button_size_px.y)
					local actual_size = InteractorComponent.draw_visual_for_button(nil, color, pos_px, size_px_copy, controller_name, "interact", interactable_settings.interact_type)

					if actual_size then
						pos_px.x = pos_px.x + actual_size.x / 2 + 20
					end

					if is_pad then
						done_pad_already = true
					end
				end
			end
		end
	else
		state.popup_alpha = math.saturate(state.popup_alpha - dt / FADE_OUT_TIME)

		if state.widget then
			state.widget:set_alpha(state.popup_alpha)
			state.widget:set_visible(state.popup_alpha > 0)
		end
	end

	Profiler.stop()
end

InteractableComponent.setup_console_plugin = function (self)
	local plugin = {
		interactable = function (argument_array, command_string)
			if argument_array[2] == "draw" then
				local drawer = Debug.drawer("interactable")

				drawer:reset()

				self.debug_draw = not self.debug_draw

				Application.set_user_setting("slayer", "debug", "interactable", self.debug_draw)
				Application.save_user_settings()

				return {
					message = sprintf("%s interactable debug drawing.", self.debug_draw and "Enabled" or "Disabled"),
				}
			elseif argument_array[2] == "set_enabled" then
				local enabled = argument_array[3]
				local target = argument_array[4]
				local msg = {
					message = sprintf("Setting enabled %s to %t.", PluginComponentAux.target_description(target), enabled),
				}

				msg = PluginComponentAux.execute_command(self, "set_enabled", enabled == "true", target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		interactable = {
			"draw",
			"set_enabled",
		},
	}
	local docs = {
		interactable = {
			text = "Shows interactable debug information",
			draw = {
				text = "Toggles rendering all interactable volumes",
				usage = "draw",
			},
			set_enabled = {
				text = "Sets the interactable as enabled or disabled",
				usage = "set_enabled <true|false> [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end
