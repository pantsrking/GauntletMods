﻿-- chunkname: @lua/components/ability_event_aux.lua

AbilityEventAux = {}
AbilityEventAux.ABILITY_ROOT_HEIGHT = 1

AbilityEventAux.construct_query = function (queries, event)
	local settings = event.settings

	if settings.type == nil then
		-- Nothing
	else
		local query_instance = queries[settings.type]

		query_instance:new_query(event)

		return query_instance
	end
end

AbilityEventAux.is_invincible_against = function (unit, hit)
	if EntityAux.has_component_master(unit, "avatar_damage_receiver") then
		local is_projectile = hit.event and hit.event.is_projectile
		local hit_react = hit.settings.hit_react or "none"

		if AvatarDamageReceiverComponent.is_invincible_against(unit, hit_react, is_projectile) then
			return true
		end

		if EntityAux.state(unit, "avatar_damage_receiver").invincible and not hit.settings.instakill and hit.settings.target_type ~= "self" and hit.settings.target_type ~= "allies" then
			return true
		end
	end

	return false
end

AbilityEventAux.send_status_effect_hit = function (hit, status_effect)
	if AbilityEventAux.is_invincible_against(hit.unit, hit) then
		return
	end

	EntityAux.get_component("ability").ability_event_handler:send_status_effect_hit_to_others(hit, status_effect)
end

AbilityEventAux.ability_blocker = function (unit)
	if not EntityAux.is_entity(unit) then
		return true
	end

	local hit_settings = LuaSettingsManager:get_settings_by_unit(unit)

	if hit_settings == nil or hit_settings.stopping_power == -1 then
		return true
	end
end

AbilityEventAux.is_wall = function (unit)
	if not EntityAux.is_entity(unit) then
		return true
	end

	local hit_settings = LuaSettingsManager:get_settings_by_unit(unit)

	if hit_settings == nil then
		return true
	end
end

local GOOD_FACTION = FactionComponent.faction_mask("good")
local FactionComponent_are_allies_mask = FactionComponent.are_allies_mask

AbilityEventAux.filter_friendly_fire = function (event, hit_settings, hits)
	local event_faction = event.event_faction

	if event_faction == nil then
		return
	end

	for i, hit in ipairs(hits) do
		local hit_unit = hit.unit

		if hit_settings.set_no_faction_as_ally and not EntityAux.has_component(hit_unit, "faction") then
			hit.ally = true
		elseif event.stat_creditor_go_id then
			if EntityAux.has_component(hit_unit, "avatar") then
				hit.ally = false
				hit.player_vs_player_hit = FactionComponent_are_allies_mask(GOOD_FACTION, event_faction)
			elseif EntityAux.has_component(hit_unit, "faction") then
				local hit_unit_faction
				local player_vs_ally = hit.caster_unit and EntityAux.has_component(hit.caster_unit, "avatar")

				if player_vs_ally then
					hit_unit_faction = EntityAux.state(hit_unit, "faction").original_faction
				else
					hit_unit_faction = EntityAux.state(hit_unit, "faction").faction
				end

				hit.ally = FactionComponent_are_allies_mask(hit_unit_faction, event_faction)
			end
		else
			if EntityAux.has_component(hit_unit, "faction") then
				local hit_unit_faction = EntityAux.state(hit_unit, "faction").faction

				hit.ally = FactionComponent_are_allies_mask(hit_unit_faction, event_faction)
			end

			if hit.ally and event.is_projectile and EntityAux.has_component(hit_unit, "monster_spawner") then
				hit.ally = false
				hit.fake_wall = true
			end
		end
	end

	local settings = event.owner_settings
	local friendly_fire = settings.friendly_fire or hit_settings.friendly_fire
	local only_friendly_fire = hit_settings.only_friendly_fire

	if not friendly_fire and not only_friendly_fire then
		array.remove_all_where(hits, "ally", true)
	elseif only_friendly_fire then
		array.remove_all_where(hits, "ally", false)
	end
end

AbilityEventAux.filter_query_hits = function (filter, hits, pose, event, hit_info)
	if #hits == 0 or filter == nil then
		return
	end

	if filter.max_angle then
		local max_angle = filter.max_angle
		local min_dot = math.cos(math.rad(max_angle))
		local forward = Quaternion.forward(Matrix4x4.rotation(pose))

		for i, hit in ipairs(hits) do
			local dot = Vector3.dot(hit.direction, forward)

			if dot < min_dot then
				hit.remove = true
			end
		end

		array.remove_all_where(hits, "remove", true)
	end

	if #hits > 0 then
		local max_distance = hits[#hits].distance

		for i = 1, #hits do
			local hit = hits[i]
			local to_hit_direction = Vector3.normalize(hit.to_hit)
			local bias = 1

			if max_distance > math.EPSILON then
				bias = (1 - hit.distance / max_distance) * 0.2
			end

			hit.score = Vector3.dot(hit_info.query_direction, to_hit_direction) + bias
		end

		if filter.select_n_best then
			table.sort(hits, function (a, b)
				return a.score > b.score
			end)

			if filter.select_n_best < #hits then
				for i = filter.select_n_best + 1, #hits do
					hits[i] = nil
				end
			end
		elseif filter.only_closest then
			local best_hit
			local best_score = -1

			for i = 1, #hits do
				local hit = hits[i]

				if best_score < hit.score then
					best_score = hit.score
					best_hit = hit
				end
			end

			table.clear(hits)

			hits[1] = best_hit
		end
	end
end

AbilityEventAux.build_hit_from_ability_event = function (victim_unit, ability_name, settings_path, event_settings, event_index, position, direction, is_authorative)
	local hit = {
		settings = event_settings,
		settings_path = settings_path,
		ability_name = ability_name,
		index = event_index,
		unit = victim_unit,
		position = position,
		direction = direction,
		is_authorative = is_authorative,
		modifiers = {},
	}

	return hit
end

AbilityEventAux.calculate_event_faction = function (event)
	local owner_unit = event.owner_unit

	if event.settings.faction then
		return FactionComponent.faction_array_to_mask(event.settings.faction)
	elseif EntityAux.has_component(owner_unit, "faction") then
		return EntityAux.state(owner_unit, "faction").faction
	end
end

AbilityEventAux.get_pose = function (event, ignore_alignment)
	local pose
	local settings = event.settings
	local caster_unit = event.caster_unit

	if event.override_pose then
		pose = Matrix4x4Box.unbox(event.override_pose)
	elseif event.target_position_box then
		local target_pos = Vector3Aux.unbox(event.target_position_box)

		if settings.target_position_as_origin then
			pose = Matrix4x4.from_quaternion_position(Quaternion.identity(), target_pos)
		elseif caster_unit ~= nil then
			local my_position
			local node_index = 0

			if settings.node then
				node_index = Unit.node(caster_unit, settings.node)
				my_position = Unit.world_position(caster_unit, node_index)
			else
				my_position = Unit.local_position(caster_unit, 0) + Vector3.up() * AbilityEventAux.ABILITY_ROOT_HEIGHT
			end

			local to_target = Vector3.normalize(target_pos - my_position)
			local rotation = Quaternion.look(to_target)

			pose = Matrix4x4.from_quaternion_position(rotation, my_position)

			if settings.node_use_root_rotation then
				Matrix4x4.set_rotation(pose, Unit.world_rotation(caster_unit, 0))
			elseif settings.node_use_identity_rotation then
				Matrix4x4.set_rotation(pose, Quaternion.identity())
			end
		end
	elseif caster_unit ~= nil then
		local node_index

		if settings.node then
			node_index = Unit.node(caster_unit, settings.node)
			pose = Unit.world_pose(caster_unit, node_index)
		else
			pose = Unit.local_pose(caster_unit, 0)
		end

		if node_index == nil then
			Matrix4x4.set_translation(pose, Unit.world_position(caster_unit, 0) + Vector3.up() * AbilityEventAux.ABILITY_ROOT_HEIGHT)
		else
			Matrix4x4.set_translation(pose, Unit.world_position(caster_unit, node_index))
		end

		if settings.node_use_root_rotation then
			Matrix4x4.set_rotation(pose, Unit.world_rotation(caster_unit, 0))
		elseif settings.node_use_identity_rotation then
			Matrix4x4.set_rotation(pose, Quaternion.identity())
		end
	end

	if pose then
		event.pose_backup = Matrix4x4Box(pose)
	elseif event.pose_backup then
		pose = Matrix4x4Box.unbox(event.pose_backup)
	end

	return pose
end

AbilityEventAux.calculate_direction = function (settings, hit, hit_info)
	local attack_origin
	local origin_type = settings.stagger_origin_type or "query"

	if origin_type == "direction" then
		local direction = hit_info.query_direction
		local event = hit_info.event

		attack_origin = event.query_instance:get_start_position(event)

		return direction, attack_origin
	end

	if origin_type == "character" then
		local caster_unit = hit_info.event.caster_unit

		attack_origin = Unit.world_position(caster_unit, 0) + Vector3.up()
	elseif origin_type == "no_change" then
		attack_origin = hit.position + UnitAux.unit_forward(hit.unit)
	elseif origin_type == "query" then
		attack_origin = hit_info.query_origin
	end

	local to_hit = hit.position - attack_origin
	local flat_direction = Vector3(to_hit.x, to_hit.y, 0)

	if Vector3.length_squared(flat_direction) < math.EPSILON then
		to_hit = -UnitAux.unit_forward(hit.unit)
	end

	local direction = Vector3.normalize(to_hit)

	if settings.stagger_origin_modifier == "inverse_direction" then
		direction = -direction
	end

	return direction, attack_origin
end

AbilityEventAux.is_projectile_by_type = function (event_type)
	return event_type == "projectile" or event_type == "projectile_lob" or event_type == "projectile_homing" or event_type == "projectile_serpent" or event_type == "projectile_spiral" or event_type == "projectile_grounded"
end

AbilityEventAux.is_projectile = function (event)
	return AbilityEventAux.is_projectile_by_type(event.settings.type)
end

AbilityEventAux.is_dependant_on_caster = function (event)
	if event.settings.is_dependant_on_caster ~= nil then
		return event.settings.is_dependant_on_caster
	elseif event.is_projectile then
		return false
	elseif event.settings.type == "ground_trail" then
		return false
	end

	return true
end

AbilityEventAux.is_event_done = function (event)
	local settings = event.settings
	local parent_ability = event.parent_ability
	local done = false

	if settings.mode == "infinite" then
		done = parent_ability.interrupted
	else
		if not event.is_projectile and not settings.ignore_interrupt then
			done = parent_ability.interrupted
		end

		local query_instance = event.query_instance

		if query_instance then
			done = done or query_instance:is_done(event)
		else
			done = done or event.timer and event.timer >= event.event_duration
		end
	end

	return done
end
