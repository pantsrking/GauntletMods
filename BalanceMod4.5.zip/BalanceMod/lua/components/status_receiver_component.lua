﻿-- chunkname: @lua/components/status_receiver_component.lua

require("lua/status_effects/status_effects")

local bit = require("bit")
local lshift = bit.lshift
local bor = bit.bor
local band = bit.band
local BITMASKS = {}

for i, status_name in ipairs(StatusEffectsArray) do
	BITMASKS[status_name] = lshift(1, i - 1)
end

require("foundation/lua/component/base_component")

StatusReceiverComponent = class("StatusReceiverComponent", "BaseComponent")

StatusReceiverComponent.init = function (self, creation_context)
	BaseComponent.init(self, "status_receiver", creation_context, true)
	self:register_interfaces("i_hit_receiver")
end

StatusReceiverComponent.setup_master = function (self, unit, context)
	context.state.status_effects = {}
end

StatusReceiverComponent.setup_slave = function (self, unit, context)
	context.state.previous_status_effects = {}
end

StatusReceiverComponent.remove_master = function (self, unit, context)
	self:remove_status_effects(unit, context.state, TempTableFactory:get_map("all", true))
end

StatusReceiverComponent.remove_slave = function (self, unit, context)
	local state = context.state

	for name, _ in pairs(StatusEffects) do
		if state[name] then
			if context.prediction_state then
				local p_state = context.prediction_state

				if p_state.status_effects then
					local existing_effect = p_state.status_effects[name]

					if existing_effect then
						StatusEffects[name].stop_prediction(unit, existing_effect)
					end
				end
			end

			StatusEffects[name].stop_slave(unit)
		end
	end
end

StatusReceiverComponent.set_status_mask_master = function (self, unit, context, status_mask)
	context.state.status_mask = status_mask

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).status_mask = status_mask
end

StatusReceiverComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)

	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

StatusReceiverComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		for status_name, data in pairs(state.status_effects) do
			local done = StatusEffects[status_name].update_master(unit, data, dt)

			if done then
				StatusEffects[status_name].stop_master(unit, data)

				state.status_effects[status_name] = nil
				state[status_name] = false
				state.dirty = true
			end
		end

		if state.dirty then
			local status_mask = 0

			for i, status_name in ipairs(StatusEffectsArray) do
				local is_set = state[status_name]

				if is_set then
					local bit_mask = BITMASKS[status_name]

					status_mask = bor(status_mask, bit_mask)
				end
			end

			self:set_status_mask_master(unit, context, status_mask)

			state.dirty = false
		end
	end
end

StatusReceiverComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local dirty = state.status_mask ~= state.previous_status_mask

		state.previous_status_mask = state.status_mask

		if dirty then
			for i, status_name in ipairs(StatusEffectsArray) do
				local bit_mask = BITMASKS[status_name]
				local is_set = band(state.status_mask, bit_mask) == bit_mask

				state[status_name] = is_set
			end

			local previous = state.previous_status_effects

			for name, _ in pairs(StatusEffects) do
				if state[name] and not previous[name] then
					local has_prediction = false

					if context.prediction_state then
						local p_state = context.prediction_state

						if p_state.status_effects then
							local existing_effect = p_state.status_effects[name]

							if existing_effect then
								has_prediction = true
							end
						end
					end

					if not has_prediction then
						StatusEffects[name].start_slave(unit)
					end
				elseif not state[name] and previous[name] then
					StatusEffects[name].stop_slave(unit)

					if context.prediction_state then
						local p_state = context.prediction_state

						if p_state.status_effects then
							local existing_effect = p_state.status_effects[name]

							if existing_effect then
								StatusEffects[name].stop_prediction(unit, existing_effect)
							end

							p_state.status_effects[name] = nil
						end
					end
				end

				previous[name] = state[name]

				if state[name] then
					StatusEffects[name].update_slave(unit, dt)
				end
			end
		end
	end
end

StatusReceiverComponent.add_status_effects = function (self, unit, state, status_effects, hit_info)
	for status_name, status_data in pairs(status_effects) do
		repeat
			if hit_info and hit_info[status_name] ~= nil then
				status_data = hit_info[status_name]
			end

			local status_effect = StatusEffects[status_name]

			if not status_effect.is_applicable(unit, hit_info or {}) then
				break
			end

			local turn_on = true
			local existing_effect = state.status_effects[status_name]

			if type(status_data) == "boolean" then
				turn_on = status_data

				if turn_on then
					status_data = table.clone(status_effect.default_data)
				elseif existing_effect then
					StatusEffects[status_name].stop_master(unit, existing_effect)

					state.status_effects[status_name] = nil
					state[status_name] = false
					existing_effect = nil
					state.dirty = true
				end
			elseif type(status_data) == "number" then
				if status_data > math.random() then
					status_data = table.clone(status_effect.default_data)
				else
					turn_on = false
				end
			else
				status_data = table.clone(status_data)
			end

			if turn_on then
				if existing_effect then
					status_data = status_effect.merge(unit, existing_effect, status_data)
				end

				state.status_effects[status_name] = status_data

				if hit_info then
					status_data.stat_creditor_go_id = hit_info.stat_creditor_go_id
					status_data.ability_name = hit_info.ability_name
					status_data.settings_path = hit_info.settings_path
				end

				status_effect.start_master(unit, status_data, hit_info)

				state[status_name] = true
				state.dirty = true
			end
		until true
	end
end

StatusReceiverComponent.remove_status_effects = function (self, unit, state, status_effects)
	if status_effects.all then
		status_effects = state.status_effects
	end

	for status_name, _ in pairs(status_effects) do
		repeat
			local existing_effect = state.status_effects[status_name]

			if existing_effect then
				StatusEffects[status_name].stop_master(unit, existing_effect)

				state.status_effects[status_name] = nil
				state[status_name] = false
				state.dirty = true
			end
		until true
	end
end

StatusReceiverComponent.call_master_hit = function (self, unit, context, hit)
	local state = context.state

	if hit.is_deathblow then
		self:remove_status_effects(unit, state, TempTableFactory:get_map("all", true))

		return
	end

	if hit.ally_hit and hit.settings and hit.settings.hit_react then
		self:remove_status_effects(unit, state, TempTableFactory:get_map("all", true))
	end

	if not hit.settings or not hit.settings.status_effects then
		return
	end

	local blocked = hit.blocked

	if blocked then
		local ignore_block = hit.settings.ignore_block

		if ignore_block and ignore_block[self.name] then
			blocked = false
		end
	end

	if not blocked then
		local hit_settings = hit.settings

		if hit_settings and hit_settings.status_effects then
			self:add_status_effects(unit, state, hit_settings.status_effects, hit)
		end
	end
end

StatusReceiverComponent.call_prediction_hit = function (self, unit, context, hit)
	if hit.is_remote_hit then
		return true
	end

	if not hit.is_authorative then
		return true
	end

	if hit.is_deathblow or hit.ally_hit then
		local p_state = context.prediction_state
		local status_effects = p_state.status_effects

		if status_effects then
			for status_name, status_data in pairs(status_effects) do
				StatusEffects[status_name].stop_prediction(unit, status_data)
			end
		end

		p_state.status_effects = nil

		return true
	end

	if not hit.settings or not hit.settings.status_effects then
		return true
	end

	local blocked = hit.blocked

	if blocked then
		local ignore_block = hit.settings.ignore_block

		if ignore_block and ignore_block[self.name] then
			blocked = false
		end
	end

	if blocked then
		return true
	end

	local hit_settings = hit.settings

	if hit_settings and hit_settings.status_effects then
		local state = context.state
		local p_state = context.prediction_state
		local status_effects = hit_settings.status_effects

		for status_name, status_data in pairs(status_effects) do
			repeat
				if state[status_name] then
					break
				end

				local status_effect = StatusEffects[status_name]

				if not status_effect.start_prediction then
					break
				end

				local turn_on = true

				if p_state.status_effects == nil then
					p_state.status_effects = {}
				end

				local existing_effect = p_state.status_effects[status_name]

				if type(status_data) == "boolean" then
					turn_on = status_data

					if turn_on then
						status_data = table.clone(status_effect.default_data)
					elseif existing_effect then
						StatusEffects[status_name].stop_prediction(unit, existing_effect)

						p_state.status_effects[status_name] = nil
						existing_effect = nil
					end
				elseif type(status_data) == "number" then
					if status_data > math.random() then
						status_data = table.clone(status_effect.default_data)
					else
						turn_on = false
					end
				else
					status_data = table.clone(status_data)
				end

				if turn_on and not existing_effect then
					p_state.status_effects[status_name] = status_data

					if hit then
						status_data.stat_creditor_go_id = hit.stat_creditor_go_id
						status_data.ability_name = hit.ability_name
						status_data.settings_path = hit.settings_path
					end

					status_effect.start_prediction(unit, status_data, hit)
				end
			until true
		end
	end
end

StatusReceiverComponent.call_master_add_status_effect = function (self, unit, context, data)
	local state = context.state

	self:add_status_effects(unit, state, type(data) == "string" and TempTableFactory:get_map(data, true) or data)
end

StatusReceiverComponent.call_master_remove_status_effect = function (self, unit, context, data)
	local state = context.state

	self:remove_status_effects(unit, state, type(data) == "string" and TempTableFactory:get_map(data, true) or data)
end

StatusReceiverComponent.setup_console_plugin = function (self)
	local plugin = {
		status = function (argument_array, command_string)
			if argument_array[2] == "add" then
				local status_name = argument_array[3]

				if status_name then
					local target = argument_array[4]
					local msg = {
						message = sprintf("Status effect %s added to %s", status_name, PluginComponentAux.target_description(target)),
					}

					msg = PluginComponentAux.execute_call(self, "add_status_effect", status_name, target) or msg

					return msg
				else
					return {
						error = true,
						message = "Missing argument <status_name>",
					}
				end
			elseif argument_array[2] == "remove" then
				local status_name = argument_array[3]

				if status_name then
					local target = argument_array[4]
					local msg = {
						message = sprintf("Status effect %s removed from %s", status_name, PluginComponentAux.target_description(target)),
					}

					msg = PluginComponentAux.execute_call(self, "remove_status_effect", status_name, target) or msg

					return msg
				else
					return {
						error = true,
						message = "Missing argument <status_name>",
					}
				end
			end
		end,
	}
	local status = table.clone(StatusEffectsArray)
	local auto_complete = {
		status = {
			add = status,
			remove = status,
		},
	}
	local docs = {
		status = {
			text = "Add and remove status.",
			add = {
				text = "Attempts to add the named status.",
				usage = "add <status_name> [go_id|all]",
			},
			remove = {
				text = "Attempts to remove the named status.",
				usage = "remove <status_name> [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end
