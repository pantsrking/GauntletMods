﻿-- chunkname: @lua/components/owned_component.lua

require("foundation/lua/component/base_component")

OwnedComponent = class("OwnedComponent", "BaseComponent")

OwnedComponent.init = function (self, creation_context)
	BaseComponent.init(self, "owned", creation_context)
end

OwnedComponent.update = function (self, unit, context, setup_info)
	return
end

OwnedComponent.call_master_set_owner = function (self, unit, context, data)
	context.state.owner = data

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).owner = data
end
