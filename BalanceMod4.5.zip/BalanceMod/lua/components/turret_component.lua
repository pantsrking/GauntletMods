﻿-- chunkname: @lua/components/turret_component.lua

require("foundation/lua/component/base_component")
require("lua/ai_states/state_machine_ai")
require("lua/ai_states/state_common_builder_turret")
require("lua/ai_states/state_common_turret")

TurretComponent = class("TurretComponent", "BaseComponent")

TurretComponent.init = function (self, creation_context)
	BaseComponent.init(self, "turret", creation_context)

	self.all_state_machines = {}
	self.spawning_disabled = false
	self.nav_grid = creation_context.nav_grid
end

TurretComponent.on_script_reload = function (self)
	self.all_state_machines = {}

	BaseComponent.on_script_reload(self)
end

TurretComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings
	local settings_path = Unit.get_data(unit, "settings_path")
	local states = self.all_state_machines[settings_path]

	if states == nil then
		states = settings.states(self)
		self.all_state_machines[settings_path] = states
	end

	state.all_states = states
end

TurretComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	self:reload_master(unit, context)

	state.current_state_name = "active"
	state.previous_state_name = state.current_state_name

	StateMachineAI.on_enter(self, unit, context)
end

TurretComponent.setup_slave = function (self, unit, context)
	self:register_unit_events(unit, "unit_on_death")
end

TurretComponent.remove_slave = function (self, unit, context)
	self:unregister_unit_event(unit, "unit_on_death")
end

TurretComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		StateMachineAI.update(self, unit, context, dt)
	end
end

TurretComponent.unit_on_death = function (self, unit)
	local num_actors = Unit.num_actors(unit)

	for i = 1, num_actors do
		Unit.destroy_actor(unit, i - 1)
	end

	if EntityAux.has_component(unit, "ability") then
		self:queue_command(unit, "ability", "set_enabled", false)
	end
end
