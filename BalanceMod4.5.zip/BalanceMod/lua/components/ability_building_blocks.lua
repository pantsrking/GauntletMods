﻿-- chunkname: @lua/components/ability_building_blocks.lua

AbilityBuildingBlocks = AbilityBuildingBlocks or {}

rawset(_G, "ANIMFRAMES_PER_SECOND", 30)

AbilityBuildingBlocks.ALIGN_CARDINAL_DIRECTION = {
	0,
	math.pi * 0.5,
	math.pi,
	math.pi * 1.5,
}
AbilityBuildingBlocks.ALIGN_INTERCARDINAL_DIRECTION = {
	math.pi * 0.25,
	math.pi * 0.75,
	math.pi * 1.25,
	math.pi * 1.75,
}
AbilityBuildingBlocks.ALIGN_CARDINAL_AND_INTERCARDINAL = array.append(table.clone(AbilityBuildingBlocks.ALIGN_CARDINAL_DIRECTION), AbilityBuildingBlocks.ALIGN_INTERCARDINAL_DIRECTION)

AbilityBuildingBlocks.spawn_entity = function (ability_component, spawn_info, position, rotation)
	if spawn_info.random_rotation then
		rotation = Quaternion.random_direction_xy()
	end

	if spawn_info.position_offset then
		local position_offset = Vector3Aux.unbox(spawn_info.position_offset)

		if spawn_info.check_offset_against_wall then
			local direction = Quaternion.rotate(rotation, position_offset)
			local physics_world = ability_component.world_proxy:get_physics_world()
			local any_hit, p, _, _, _ = PhysicsWorld.immediate_raycast(physics_world, position + Vector3.up(), direction, Vector3.length(direction), "closest", "types", "both", "collision_filter", "wall_and_floor")

			if any_hit then
				position = p - direction * 0.3
			else
				position = QueryManager:offset_position(position, Quaternion.rotate(rotation, position_offset))
			end
		else
			position = QueryManager:offset_position(position, Quaternion.rotate(rotation, position_offset))
		end
	end

	if spawn_info.random_position_offset then
		local random_info = spawn_info.random_position_offset
		local max_radius = random_info.max_radius
		local min_radius = random_info.min_radius
		local unit_radius = random_info.unit_radius or 0.5

		position = QueryManager:query_position_in_hollow_disc(position, min_radius, max_radius, unit_radius)

		local height_offset = random_info.height_offset or 0

		position.z = position.z + height_offset
	end

	if spawn_info.rotation_angles then
		local rotation_angles = spawn_info.rotation_angles

		rotation = Quaternion.from_yaw_pitch_roll(math.rad(rotation_angles.z), math.rad(rotation_angles.x), math.rad(rotation_angles.y))
	end

	if spawn_info.align_angles then
		local axis, angle = Quaternion.decompose(rotation)
		local new_angle = math.find_to_nearest_point(angle, spawn_info.align_angles)

		rotation = Quaternion.axis_angle(axis, new_angle)
	end

	if spawn_info.snap_to_grid then
		position = ability_component.nav_grid:move_to_where_we_can_stand(position, 1, 5)
	end

	local spawn_info_key = spawn_info.spawn_info_key

	if spawn_info.spawn_ai_monster then
		AIManager:spawn_monster(spawn_info.unit_path, position, rotation, nil, {
			spawn_info_key = spawn_info_key,
		})
	else
		local stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(spawn_info.owner_unit)
		local entity = ability_component.entity_spawner:spawn_entity(spawn_info.unit_path, position, rotation, nil, {
			spawn_info_key = spawn_info_key,
			stat_creditor_go_id = stat_creditor_go_id,
		})

		if spawn_info.flow_event then
			ability_component:trigger_rpc_event("flow_event", entity, spawn_info.flow_event)
		end

		local settings = LuaSettingsManager:get_settings_by_unit(entity)

		if settings and settings.on_created_by_ability then
			settings.on_created_by_ability(entity, spawn_info)
		end

		if not EntityAux.has_component_any(entity, "motion", "static_pose") then
			NetworkUnitSynchronizer:add(entity)
		end

		return entity
	end
end

AbilityBuildingBlocks.update_spawn_entities = function (ability_info, pose, ability_component, dt)
	Profiler.start("AbilityBuildingBlocks.update_spawn_entities")

	local timer, spawn_entities = ability_info.timer, ability_info.spawn_entities
	local dirty = false

	for i, spawn in ipairs(spawn_entities) do
		local time = spawn.time or 0

		if time <= timer then
			if spawn.time_interval then
				spawn.time = spawn.time + spawn.time_interval

				if spawn.time_interval_variation then
					spawn.time = spawn.time + spawn.time_interval_variation * (math.random() * 2 - 1)
				end
			else
				dirty = true
				spawn.dirty = true
			end

			local position = Matrix4x4.translation(pose)
			local rotation = Quaternion.identity()

			if spawn.position_offset_relative_to_caster then
				local node_index = spawn.node and Unit.node(ability_info.caster_unit, spawn.node) or 0

				rotation = Unit.local_rotation(ability_info.caster_unit, node_index)
			elseif spawn.preserve_rotation then
				rotation = Matrix4x4.rotation(pose)
			end

			spawn.owner_unit = ability_info.owner_unit

			local entity = AbilityBuildingBlocks.spawn_entity(ability_component, spawn, position, rotation)

			if spawn.custom_callback then
				spawn.custom_callback(ability_component, ability_info, entity)
			end
		end
	end

	if dirty then
		array.remove_all_where(spawn_entities, "dirty", true)
	end

	Profiler.stop()
end

AbilityBuildingBlocks.spawn_ability_entity = function (spawn, ability_component, unit, context, ability)
	Profiler.start("AbilityBuildingBlocks.update_spawn_entities")

	local position, rotation

	if spawn.use_target_unit then
		local target_unit = ability.target_unit

		if target_unit then
			local node_index = spawn.node and Unit.node(target_unit, spawn.node) or 0

			position = Unit.world_position(target_unit, node_index)
			rotation = Unit.world_rotation(target_unit, node_index)
		end
	end

	local caster_unit = ability.caster_unit

	if spawn.condition_mover_on_ground then
		local mover = Unit.mover(caster_unit)

		if mover == nil or not Mover.collides_down(mover) then
			return
		end
	end

	if position == nil and spawn.use_target_position then
		position = Vector3Aux.unbox(ability.target_position_box)
		rotation = Unit.world_rotation(caster_unit, 0)
	end

	if position == nil then
		local node_index = spawn.node and Unit.node(caster_unit, spawn.node) or 0

		position = Unit.world_position(caster_unit, node_index)
		rotation = Unit.world_rotation(caster_unit, node_index)
	end

	if spawn.rotate_towards_target then
		local target_position = Vector3Aux.unbox(ability.target_position_box)
		local direction = target_position - position

		rotation = Quaternion.look(direction)
	end

	spawn.owner_unit = ability.owner_unit

	local entity = AbilityBuildingBlocks.spawn_entity(ability_component, spawn, position, rotation)

	if spawn.custom_callback then
		spawn.custom_callback(ability_component, ability, entity)
	end

	Profiler.stop()
end

AbilityBuildingBlocks.spawn_ability_unit = function (spawn, ability_component, unit, context, ability)
	Profiler.start("AbilityBuildingBlocks.update_spawn_unit")

	local position, rotation

	if spawn.use_target_unit then
		local target_unit = ability.target_unit

		if target_unit then
			local node_index = spawn.node and Unit.node(target_unit, spawn.node) or 0

			position = Unit.world_position(target_unit, node_index)
			rotation = Unit.world_rotation(target_unit, node_index)
		end
	end

	local caster_unit = ability.caster_unit

	if position == nil and spawn.use_target_position then
		position = Vector3Aux.unbox(ability.target_position_box)
		rotation = Unit.world_rotation(caster_unit, 0)
	end

	if position == nil and ability.override_pose then
		local pose = Matrix4x4Box.unbox(ability.override_pose)

		position = Matrix4x4.translation(pose)
		rotation = Matrix4x4.rotation(pose)
	end

	if position == nil and caster_unit then
		local node_index = spawn.node and Unit.node(caster_unit, spawn.node) or 0

		position = Unit.world_position(caster_unit, node_index)
		rotation = Unit.world_rotation(caster_unit, node_index)
	end

	if spawn.position_offset then
		local position_offset = Vector3Aux.unbox(spawn.position_offset)

		position = position + Quaternion.rotate(rotation, position_offset)
	end

	local world = ability_component.world_proxy:get_world()
	local spawned_unit = World.spawn_unit(world, spawn.unit_path, position, rotation)

	if spawn.custom_callback then
		spawn.custom_callback(spawn, ability_component, unit, spawned_unit)
	end

	Profiler.stop()
end

AbilityBuildingBlocks.set_cooldown = function (cooldown_duration, ability_component, unit, context, ability)
	local avatar_component = EntityAux.get_component("avatar")

	avatar_component.combo:set_cooldown(unit, cooldown_duration, ability.static_ability.name)
end

AbilityBuildingBlocks.enemy_collision_set = function (should_set, ability_component, unit, context, ability, dt)
	ability.enemy_collision_set = should_set

	EntityAux.queue_command_master(unit, "motion", "constrain_to_simple_mover", should_set)
end

AbilityBuildingBlocks.enemy_collision_exit = function (should_set, ability_component, unit, context, ability, dt)
	if ability.enemy_collision_set ~= should_set then
		ability.enemy_collision_set = should_set

		EntityAux.queue_command_master(unit, "motion", "constrain_to_simple_mover", should_set)
	end
end

AbilityBuildingBlocks.check_collided = function (event_callbacks, ability_component, unit, context, ability, dt)
	local collided = MotionState.has_collided(EntityAux.state_master(unit, "motion").motion_state)

	if collided then
		AbilityBuildingBlocks.run_ability_event_callbacks(event_callbacks, ability_component, unit, context, ability)
	end
end

AbilityBuildingBlocks.blocking_set = function (should_set, ability_component, unit, context, ability, dt)
	ability.blocking_set = should_set

	EntityAux.call_master(unit, "blocker", "set_blocking", should_set)
end

AbilityBuildingBlocks.allow_rotation_update = function (allow_rotation, ability_component, unit, context, ability, dt)
	ability.need_rotation_unlock = not allow_rotation.enable

	EntityAux.queue_command_master(unit, "rotation", allow_rotation.enable and "enable" or "disable", tostring(ability))
end

AbilityBuildingBlocks.allow_rotation_exit = function (ability_component, unit, context, ability, dt)
	if ability.need_rotation_unlock then
		EntityAux.queue_command_master(unit, "rotation", "enable", tostring(ability))
	end
end

AbilityBuildingBlocks.set_max_step_down = function (step_down, ability_component, unit, context, ability, dt)
	EntityAux.queue_command_master(unit, "motion", "set_max_step_down", step_down)
end

AbilityBuildingBlocks.movement_update = function (movement, ability_component, unit, context, ability, dt)
	if movement.velocity_function then
		movement.speed = movement.velocity_function(ability.timer - movement.window[1])
	end

	local collided = MotionState.has_collided(EntityAux.state_master(unit, "motion").motion_state)

	if not collided then
		local forward

		if ability.stored_forward then
			forward = Vector3Aux.unbox(ability.stored_forward)
		else
			forward = Quaternion.forward(Unit.local_rotation(unit, 0))
		end

		local animation_speed = EntityAux.state(unit, "animation").animation_speed
		local velocity = forward * movement.speed * animation_speed

		velocity = velocity + Vector3.up() * (movement.speed_z or 0)

		if EntityAux.has_component_master(unit, "navigation") then
			EntityAux.call_master(unit, "navigation", "wanted_velocity", velocity)
		else
			EntityAux.call_master(unit, "motion", "wanted_velocity", velocity)
		end
	end
end

AbilityBuildingBlocks.custom_movement_setup = function (ability_component, unit, context, ability)
	local info = table.clone(ability.static_ability.custom_movement)
	local start_position = Unit.world_position(unit, 0)
	local target_position = Vector3Aux.unbox(ability.target_position_box)

	info.target_position = Vector3Aux.box({}, target_position)
	info.start_position = Vector3Aux.box({}, start_position)
	info.start = (info.start or 0) / 30
	info.duration = info.duration / 30
	ability.custom_movement = info
end

AbilityBuildingBlocks.custom_movement_enter = function (start_frame, ability_component, unit, context, ability)
	local info = ability.custom_movement

	EntityAux.queue_command_master(unit, "motion", "change_state", "custom_translation")
	EntityAux.queue_command_master(unit, "motion", "constrain_to_navgrid", false)

	info.timer = 0
end

AbilityBuildingBlocks.custom_movement_update = function (ability_component, unit, context, ability, dt)
	local info = ability.custom_movement

	info.timer = info.timer + dt

	local timer = info.timer
	local t = timer / info.duration
	local start_position = Vector3Aux.unbox(info.start_position)
	local target_position = Vector3Aux.unbox(info.target_position)
	local height = math.abs(target_position.z - start_position.z)

	target_position.z = start_position.z

	local current_position = Vector3.slerp(start_position, target_position, math.saturate(t))

	current_position.z = start_position.z + math.slerp(0, height, math.saturate(t * 2))

	EntityAux.queue_command_master(unit, "motion", "force_set_position", Vector3Aux.box_temp(current_position))
end

AbilityBuildingBlocks.custom_movement_exit = function (ability_component, unit, context, ability)
	local info = ability.custom_movement

	if info == nil then
		return
	end

	if info.has_exited then
		return
	end

	info.has_exited = true

	EntityAux.queue_command_master(unit, "motion", "change_state", "default")
	EntityAux.queue_command_master(unit, "motion", "constrain_to_navgrid", true)
end

AbilityBuildingBlocks.mover_filter_set = function (filter, ability_component, unit, context, ability)
	EntityAux.queue_command_master(unit, "motion", "set_collision_filter", filter)
end

AbilityBuildingBlocks.invincibility_set = function (should_set, ability_component, unit, context, ability, dt)
	ability.invincibility_set = should_set

	local t = TempTableFactory:get_map("id", tostring(ability), "state", should_set and "on" or "off")

	EntityAux.queue_command_master_interface(unit, "i_damage_receiver", "set_invincibility", t)
end

AbilityBuildingBlocks.invincibility_exit = function (ability_component, unit, context, ability, dt)
	if ability.invincibility_set then
		ability.invincibility_set = false

		local t = TempTableFactory:get_map("id", tostring(ability), "state", "off")

		EntityAux.queue_command_master_interface(unit, "i_damage_receiver", "set_invincibility", t)
	end
end

AbilityBuildingBlocks.hero_invincibility_set = function (invincibility, ability_component, unit, context, ability, dt)
	EntityAux.call_master(unit, "avatar_damage_receiver", "set_invincibility", invincibility.type, invincibility.value)
end

AbilityBuildingBlocks.hero_invincibility_exit = function (invincibility, ability_component, unit, context, ability, dt)
	EntityAux.call_master(unit, "avatar_damage_receiver", "set_invincibility", invincibility.type, nil)
end

AbilityBuildingBlocks.movement_prediction_enter = function (ability_component, unit, context, ability, dt)
	EntityAux.queue_command_predictor(unit, "motion", "change_state", "kinematic")
end

AbilityBuildingBlocks.movement_prediction_exit = function (ability_component, unit, context, ability, dt)
	EntityAux.queue_command_predictor(unit, "motion", "change_state", nil)
end

AbilityBuildingBlocks.movement_ability_prediction_enter = function (ability_component, unit, context, ability, dt)
	EntityAux.queue_command_predictor(unit, "motion", "change_state", "ability")
end

AbilityBuildingBlocks.movement_ability_prediction_exit = function (ability_component, unit, context, ability, dt)
	EntityAux.queue_command_predictor(unit, "motion", "change_state", "exit_ability")
end

AbilityBuildingBlocks.movement_prediction_update = function (movement, ability_component, unit, context, ability, dt)
	if movement.velocity_function then
		movement.speed = movement.velocity_function(ability.timer - movement.window[1])
	end

	local forward = Quaternion.forward(Unit.local_rotation(unit, 0))
	local animation_speed = EntityAux.state(unit, "animation").animation_speed
	local velocity = forward * movement.speed * animation_speed

	velocity = velocity + Vector3.up() * (movement.speed_z or 0)

	EntityAux.call_prediction(unit, "motion", "wanted_velocity", velocity)
end

AbilityBuildingBlocks.ignore_interrupt_set = function (should_set, ability_component, unit, context, ability)
	ability.ignore_interrupt = should_set
end

AbilityBuildingBlocks.ignore_shock_set = function (should_ignore, ability_component, unit, context, ability, dt)
	ability.ignore_shock_set = should_ignore

	EntityAux.queue_command(unit, "shock_receiver", should_ignore and "disable_shocks" or "enable_shocks")
end

AbilityBuildingBlocks.ignore_shock_exit = function (ability_component, unit, context, ability, dt)
	if ability.ignore_shock_set then
		ability.ignore_shock_set = false

		EntityAux.queue_command(unit, "shock_receiver", "enable_shocks")
	end
end

AbilityBuildingBlocks.trigger_custom_callback = function (custom_callback, ability_component, unit, context, ability)
	Profiler.start("custom_callback")
	custom_callback(ability_component, unit, ability)
	Profiler.stop()
end

AbilityBuildingBlocks.execute_ability = function (ability_info, ability_component, unit, context, ability, dt)
	if type(ability_info) == "table" then
		if EntityAux.owned(unit) then
			local ability_name = ability.static_ability.ability_name
			local state = context.state

			if ability_info.max_steps then
				local is_same_ability = ability_name ~= ability_info.name

				state.current_nr_steps = is_same_ability and 1 or state.current_nr_steps + 1

				if state.current_nr_steps >= ability_info.max_steps then
					return
				end
			end

			local target_position

			if ability.target_unit then
				target_position = Unit.world_position(ability.target_unit, 0)
			elseif ability.target_position_box then
				target_position = Vector3Aux.unbox(ability.target_position_box)
			end

			if target_position and ability_info.target_modifiers then
				target_position = AbilityAux.modify_target_position(ability_component, unit, target_position, ability_info.target_modifiers)
			end

			local command = TempTableFactory:get_map("ability_name", ability_info.name, "settings_path", ability.static_ability.settings_path, "target_position", target_position, "owner_unit", ability.owner_unit, "target_unit", ability.target_unit, "stat_creditor_go_id", ability.stat_creditor_go_id)

			EntityAux.command_master_immediately(unit, "ability", "execute_ability", command)
		end
	else
		local ability_name = ability_info
		local ability_id = AbilityAux.next_ability_id(unit, context.state, ability.ability_id)
		local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", ability.static_ability.settings_path, "owner_unit", ability.owner_unit, "ability_id", ability_id, "target_unit", ability.target_unit, "stat_creditor_go_id", ability.stat_creditor_go_id)

		ability_component:execute_ability(unit, context, command)
	end
end

AbilityBuildingBlocks.timpani_event_play = function (event_name, ability_component, unit, context, ability)
	TimpaniWorld.trigger_event(ability_component.timpani_world, event_name, unit)
end

AbilityBuildingBlocks.flow_event_play = function (event_name, ability_component, unit, context, ability)
	Unit.flow_event(ability.caster_unit or unit, event_name)
end

AbilityBuildingBlocks.level_flow_event_play = function (event_name, ability_component, unit, context, ability)
	ability_component:trigger_level_flow(event_name)
end

AbilityBuildingBlocks.animation_event_play = function (event_name, ability_component, unit, context, ability)
	EntityAux.queue_command(unit, "animation", "trigger_event_local", event_name)
end

AbilityBuildingBlocks.run_ability_event_callbacks = function (event_callbacks, ability_component, unit, context, ability)
	ability_component:handle_event_callback(unit, context, ability, event_callbacks)
end

AbilityBuildingBlocks.on_ability_done = function (ability_component, unit, context, ability)
	ability_component:on_ability_exit(unit, context, ability)
end

AbilityBuildingBlocks.start_ability_query_event = function (event, ability_component, unit, context, ability)
	local static_ability = ability.static_ability
	local temp = TempTableFactory:get_map("settings", event, "index", event.index, "settings_path", static_ability.settings_path, "ability_name", static_ability.ability_name, "owner_unit", ability.owner_unit or unit, "caster_unit", ability.caster_unit or unit, "stat_creditor_go_id", ability.stat_creditor_go_id, "override_pose", ability.override_pose, "target_position_box", ability.target_position_box, "target_unit", ability.target_unit, "ability_event_listeners", ability.ability_event_listeners)

	ability_component.ability_event_handler:execute_event(temp, ability)
end
