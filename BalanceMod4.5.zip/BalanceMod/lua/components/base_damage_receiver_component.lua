﻿-- chunkname: @lua/components/base_damage_receiver_component.lua

require("lua/extensions/health_bar_extension")
require("foundation/lua/component/base_component")
require("foundation/lua/util/value_mixers")
require("foundation/lua/util/material_aux")
require("foundation/lua/player/player_manager")
require("foundation/lua/debug/plugin_component_aux")
require("lua/managers/entity_event_modifier_manager")

BaseDamageReceiverComponent = class("BaseDamageReceiverComponent", "PeriodicBaseComponent")

local FULL_UPDATES_PER_SECOND = 20

BaseDamageReceiverComponent.init = function (self, creation_context, name, update_period)
	PeriodicBaseComponent.init(self, name, creation_context, true, update_period or 1 / FULL_UPDATES_PER_SECOND)

	self.use_dirty_optimization = true
	self.health_bar_extension = self:create_extension(HealthBarExtension)

	self:register_interfaces("i_hit_receiver", "i_damage_receiver")

	self.turn_off_invincibility_command = {
		state = "off",
		id = self.name,
	}
end

BaseDamageReceiverComponent.set_hitpoints = function (self, state, hitpoints)
	if state.hitpoints_protected then
		if state.hitpoints_protected:get() ~= state.hitpoints then
			_G.I_AM_A_FUSKER = true
		end

		state.hitpoints_protected:set(hitpoints)

		state.hitpoints = hitpoints
	else
		state.hitpoints = hitpoints
	end
end

BaseDamageReceiverComponent.reload_master = function (self, unit, context)
	context.num_commands = 0
end

BaseDamageReceiverComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

BaseDamageReceiverComponent.pause = function (self, unit, master_context, slave_context)
	PeriodicBaseComponent.pause(self, unit, master_context, slave_context)

	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable_disabled")
	end
end

BaseDamageReceiverComponent.resume = function (self, unit, master_context, slave_context)
	PeriodicBaseComponent.resume(self, unit, master_context, slave_context)

	slave_context.state.previous_invincible = nil
end

BaseDamageReceiverComponent.remove_slave = function (self, unit, context)
	Unit.destroy_actor(unit, "a_damageable")
end

BaseDamageReceiverComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	PeriodicBaseComponent.migrated_to_me(self, unit, slave_context, master_context, TempTableFactory:get_map("migrated", true))
end

BaseDamageReceiverComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	if setup_info and setup_info.migrated then
		state.invincible_refmix = RefMixer()
		state.invincible = false

		return
	else
		state.invincible_refmix = RefMixer()

		state.invincible_refmix:add(self.name)

		state.invincible = true

		self:queue_command_master(unit, self.name, "set_invincibility", self.turn_off_invincibility_command)
	end
end

BaseDamageReceiverComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.previous_hitpoints = state.hitpoints
	state.previous_hitpoint_ratio = 1
	state.alive = state.hitpoints > 0

	self.health_bar_extension:add_unit(unit)

	state.invincible = true
	state.previous_invincible = true

	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable_disabled")
	end
end

BaseDamageReceiverComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)
	local prediction_entities = self.entity_manager:get_prediction_entities(self.name)

	Profiler.start("command_masters")
	BaseComponent.command_masters(self, master_entities)
	Profiler.stop()
	Profiler.start("write_game_objects")
	self:write_game_objects(master_entities, slave_entities)
	Profiler.stop()
	Profiler.start("update_predictors")
	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
	Profiler.start("command_slaves")
	BaseComponent.command_slaves(self, slave_entities)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

BaseDamageReceiverComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		repeat
			local p_state = context.prediction_state
			local state = context.state

			if p_state.hitpoints == nil then
				break
			end

			p_state.previous_hitpoints = p_state.previous_hitpoints or state.previous_hitpoints
			p_state.real_previous_hitpoints = p_state.real_previous_hitpoints or state.previous_hitpoints

			local dirty = p_state.real_previous_hitpoints ~= state.hitpoints

			if dirty then
				local previous_hitpoints = p_state.real_previous_hitpoints

				if previous_hitpoints < state.hitpoints then
					if p_state.hitpoints <= 0 then
						-- Nothing
					else
						p_state.hitpoints = nil
						p_state.previous_hitpoints = nil
						p_state.real_previous_hitpoints = nil

						break
					end
				elseif previous_hitpoints > state.hitpoints then
					local dif = state.hitpoints - previous_hitpoints

					if state.hitpoints <= p_state.hitpoints then
						p_state.hitpoints = nil
						p_state.previous_hitpoints = nil
						p_state.real_previous_hitpoints = nil

						break
					end
				end

				p_state.real_previous_hitpoints = state.hitpoints
			end

			state.hitpoints = p_state.hitpoints
			state.previous_hitpoints = p_state.previous_hitpoints

			if p_state.hitpoints ~= p_state.previous_hitpoints then
				p_state.previous_hitpoints = p_state.hitpoints
			end
		until true
	end
end

local function _material_set_scalar_over_time(unit)
	local c = MaterialAux.scalar_over_time(unit, 0.2, 0, 0, "self_illumination_multiplier", 0.3, 0)

	JobManager:add("damage_receiver", unit, c)
end

BaseDamageReceiverComponent.material_set_scalar_over_time = _material_set_scalar_over_time

BaseDamageReceiverComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		Profiler.start("decide_full_update")

		context.full_update = self:decide_full_update(self.period, context)

		Profiler.stop()

		if context.full_update then
			local previous_hitpoint_ratio = state.previous_hitpoint_ratio
			local hitpoint_ratio = state.hitpoints / state.max_hitpoints
			local dirty_ratio = not math.equals(previous_hitpoint_ratio, hitpoint_ratio)

			state.alive = state.hitpoints > 0

			if dirty_ratio and hitpoint_ratio < previous_hitpoint_ratio then
				if state.alive then
					Unit.flow_event(unit, "on_damage")
				end

				if not context.settings.disable_self_illumination_animation then
					_material_set_scalar_over_time(unit)
				end

				EntityEventModifierManager:on_event(unit, "damaged", state.hitpoints, state.previous_hitpoints - state.hitpoints)
			end

			state.previous_hitpoints = state.hitpoints
			state.previous_hitpoint_ratio = hitpoint_ratio

			local dirty_alive = state.previous_alive ~= state.alive

			if dirty_alive and not state.alive then
				local actor = Unit.actor(unit, "a_damageable")

				if actor then
					Actor.set_collision_filter(actor, "damageable_disabled")
				end

				self:notify_death(unit, context)
			end

			state.previous_alive = state.alive

			if state.alive then
				local previous_invincible = state.previous_invincible
				local dirty_invincible = previous_invincible ~= state.invincible

				if dirty_invincible then
					local actor = Unit.actor(unit, "a_damageable")

					if not actor then
						-- Nothing
					elseif state.invincible then
						Actor.set_collision_filter(actor, "damageable_disabled")
					else
						Actor.set_collision_filter(actor, "damageable")
					end
				end

				state.previous_invincible = state.invincible
			end
		end

		Profiler.start("HealthBarExtension:update")
		self.health_bar_extension:update(unit, dt, state)
		Profiler.stop()
	end
end

BaseDamageReceiverComponent.do_settings_death_action = function (self, unit, state, settings)
	if not EntityAux.owned(unit) then
		return
	end

	if settings.skip_death_action then
		return
	end

	if state.death_action_performed then
		return
	end

	state.death_action_performed = true

	if Unit.get_data(unit, "entity_destroyed_action") == "skip_world_destroy" then
		self.scheduler:delay_action(2, function ()
			if EntityAux.is_alive_entity(unit) then
				self.entity_spawner:despawn_entity(unit)
			end
		end)
	elseif settings.despawn_delay then
		self.scheduler:delay_action(settings.despawn_delay, function ()
			if EntityAux.is_alive_entity(unit) then
				self.entity_spawner:despawn_entity(unit)
			end
		end)
	end
end

BaseDamageReceiverComponent.call_master_hit = function (self, unit, context, hit)
	self:apply_authorative_hit(unit, context.state, context, hit)
end

BaseDamageReceiverComponent.call_prediction_hit = function (self, unit, context, hit)
	if hit.is_remote_hit then
		return
	end

	local state, p_state = context.state, context.prediction_state

	p_state.hitpoints = p_state.hitpoints or state.hitpoints
	p_state.max_hitpoints = state.max_hitpoints

	self:apply_authorative_hit(unit, p_state, context, hit)
end

BaseDamageReceiverComponent.command_master = function (self, unit, context, command_name, data)
	local state, settings = context.state, context.settings

	if command_name == "damage" then
		self:apply_damage(unit, state, context, data.amount, data)

		state.dirty = true
	elseif command_name == "heal" then
		local amount = data

		if state.hitpoints > 0 and state.hitpoints < state.max_hitpoints then
			self:set_hitpoints(state, math.round(math.min(state.hitpoints + amount, state.max_hitpoints)))

			state.dirty = true
		end

		self:trigger_rpc_event("flow_event", unit, "on_healed")
	elseif command_name == "set_hitpoints" then
		self:set_hitpoints(state, math.round(math.clamp(data, 0, state.max_hitpoints)))

		state.dirty = true
	elseif command_name == "set_invincibility" then
		local id = data.id
		local add = data.state == "on"

		if add then
			state.invincible_refmix:add(id)
		else
			state.invincible_refmix:remove(id)
		end

		state.invincible = state.invincible_refmix:get()
		state.dirty = true
	end
end

BaseDamageReceiverComponent.call_master_deathplane = function (self, unit, context)
	local state = context.state

	if state.hitpoints > 0 then
		self:apply_damage(unit, state, context, 99999, {})
	end
end

BaseDamageReceiverComponent.apply_authorative_hit = function (self, unit, state, context, hit)
	return
end

BaseDamageReceiverComponent.apply_damage = function (self, unit, state, context, damage, hit)
	return
end

BaseDamageReceiverComponent.notify_death = function (self, unit, context, hit)
	return
end

BaseDamageReceiverComponent.setup_console_plugin = function (self)
	local plugin = {
		health = function (argument_array, command_string)
			if argument_array[2] == "draw" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Health is toggled for %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "draw_health", true, target) or msg

				return msg
			elseif argument_array[2] == "invincibility" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Invincibility is toggled for %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "invincibility", true, target) or msg

				return msg
			elseif argument_array[2] == "set_hitpoints" then
				local target = argument_array[4]
				local amount = tonumber(argument_array[3])
				local msg = {
					message = sprintf("Hitpoints set to %d for %s.", amount, PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "set_hitpoints", amount, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		health = {
			"draw",
			"invincibility",
			"set_hitpoints",
		},
	}
	local docs = {
		health = {
			text = "Draws health, sets invincibility or hitpoints on damage receivers.",
			draw = {
				text = "Shows the hitpoints on all entities.",
				usage = "draw [go_id|all]",
			},
			invincibility = {
				text = "Toggles invincibility.",
				usage = "invincibility [go_id|all]",
			},
			set_hitpoints = {
				text = "Sets the given amount as hitpoints for the target.",
				usage = "set_hitpoints <amount> [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end
