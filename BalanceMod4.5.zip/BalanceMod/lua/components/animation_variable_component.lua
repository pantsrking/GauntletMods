﻿-- chunkname: @lua/components/animation_variable_component.lua

require("foundation/lua/component/base_component")

AnimationVariableComponent = class("AnimationVariableComponent", "BaseComponent")

AnimationVariableComponent.init = function (self, creation_context)
	BaseComponent.init(self, "animation_variable", creation_context, true)
end

AnimationVariableComponent.setup_slave = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.animation_variables = {}

	for i, variable_name in ipairs(settings.animation_variables) do
		state.animation_variables[variable_name] = Unit.animation_find_variable(unit, variable_name)
	end
end

AnimationVariableComponent.call_master_set_variable = function (self, unit, context, data)
	context.state[data.name] = data.value

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name)[data.name] = data.value
end

AnimationVariableComponent.update = function (self, dt)
	Profiler.start(self.name)

	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(slave_entities) do
		local state = context.state

		for variable_name, variable_id in pairs(state.animation_variables) do
			Unit.animation_set_variable(unit, variable_id, state[variable_name])
		end
	end

	Profiler.stop()
end
