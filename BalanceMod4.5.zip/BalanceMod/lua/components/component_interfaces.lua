﻿-- chunkname: @lua/components/component_interfaces.lua

ComponentInterfaces = {
	i_hit_receiver = {
		hit = function (data)
			return true
		end,
	},
	i_trap = {
		activate = function (data)
			return true
		end,
		deactivate = function (data)
			return true
		end,
	},
	i_speed_listener = {
		add_speed_multiplier = function (data)
			return true
		end,
		remove_speed_multiplier = function (data)
			return true
		end,
	},
	i_damage_receiver = {
		hit = function (data)
			return true
		end,
		damage = function (data)
			return true
		end,
		heal = function (data)
			return true
		end,
		set_hitpoints = function (data)
			return true
		end,
		set_invincibility = function (data)
			return true
		end,
		draw_health = function (data)
			return true
		end,
		invincibility = function (data)
			return true
		end,
	},
	i_scale = {},
}
