﻿-- chunkname: @lua/components/custom_state_machine_component.lua

CustomStateMachineComponent = class("CustomStateMachineComponent", "BaseComponent")

CustomStateMachineComponent.init = function (self, creation_context)
	BaseComponent.init(self, "custom_state_machine", creation_context)

	self.all_state_machines = {}
	self.nav_grid = creation_context.nav_grid
end

CustomStateMachineComponent.on_script_reload = function (self)
	self.all_state_machines = {}

	BaseComponent.on_script_reload(self)
end

CustomStateMachineComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings
	local settings_path = Unit.get_data(unit, "settings_path")
	local states = self.all_state_machines[settings_path]

	if states == nil then
		states = settings.states(self)
		self.all_state_machines[settings_path] = states
	end

	state.all_states = states
end

CustomStateMachineComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	self:reload_master(unit, context)

	state.current_state_name = context.settings.start_state
	state.previous_state_name = state.current_state_name

	StateMachineAI.on_enter(self, unit, context)
end

CustomStateMachineComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entities = self.entity_manager:get_master_entities(self.name)

	for unit, context in pairs(entities) do
		StateMachineAI.update(self, unit, context, dt)
	end

	Profiler.stop()
end
