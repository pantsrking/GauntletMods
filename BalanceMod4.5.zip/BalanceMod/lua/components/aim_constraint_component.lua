﻿-- chunkname: @lua/components/aim_constraint_component.lua

require("foundation/lua/component/base_component")

AimConstraintComponent = class("AimConstraintComponent", "BaseComponent")

local DEFAULT_ANGLE_CATCH_UP = 45
local DEFAULT_CATCH_UP_SPEED = 20

AimConstraintComponent.init = function (self, creation_context)
	BaseComponent.init(self, "aim_constraint", creation_context, true)
	self.event_delegate:register(self, "on_entity_unregistering")

	self.use_dirty_optimization = true
end

AimConstraintComponent.setup_slave = function (self, unit, context, setup_info)
	self:setup_constraint_info(unit, context)
end

AimConstraintComponent.reload_slave = function (self, unit, context)
	self:setup_constraint_info(unit, context)
end

AimConstraintComponent.setup_constraint_info = function (self, unit, context)
	local state, settings = context.state, context.settings
	local infos = settings.aim_constraint_info

	state.constraint_infos = {}

	for key, info in pairs(infos) do
		state.constraint_infos[key] = {
			constraint_target = Unit.animation_find_constraint_target(unit, info.constraint_target),
			offset = info.offset and table.clone(info.offset) or {
				x = 0,
				y = 0,
				z = 0,
			},
			max_angle = info.max_angle or 90,
			turn_speed = info.turn_speed or 10,
			catch_up_speed = info.catch_up_turn_speed or DEFAULT_CATCH_UP_SPEED,
		}
	end
end

AimConstraintComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local look_target_info = state.constraint_infos.look_target

		if state.look_target then
			self:update_aim_constraint(unit, context, state.look_target, look_target_info, dt)
		else
			local constraint_target = look_target_info.constraint_target
			local target_position = Unit.world_position(unit, 0) + Vector3.up() * 2 + UnitAux.unit_forward(unit) * 5

			Unit.animation_set_constraint_target(unit, constraint_target, target_position)
		end
	end
end

local function _rotate_around_z(vec, angle)
	local theta = math.rad(angle)
	local c, s = math.cos(theta), math.sin(theta)
	local x2 = c * vec.x - s * vec.y
	local y2 = s * vec.x + c * vec.y
	local z2 = vec.z

	return Vector3(x2, y2, z2)
end

AimConstraintComponent.update_aim_constraint = function (self, unit, context, target_unit, constraint_info, dt)
	local state = context.state
	local target_position = Unit.world_position(target_unit, 0) + Vector3Aux.unbox(constraint_info.offset)
	local my_position = Unit.world_position(unit, 0)

	target_position.z = my_position.z

	local to_target = target_position - my_position
	local to_target_normalized = Vector3.normalize(to_target)
	local forward = UnitAux.unit_forward(unit)
	local angle = math.deg(Vector3.angle_z(forward, to_target_normalized))

	if math.abs(angle) > constraint_info.max_angle then
		angle = math.sign(angle) * constraint_info.max_angle
	end

	local turn_speed = math.abs(state.current_angle or angle) > DEFAULT_ANGLE_CATCH_UP and constraint_info.catch_up_speed or constraint_info.turn_speed

	turn_speed = turn_speed * EntityAux.state(unit, "animation").animation_speed
	angle = math.slerp(state.current_angle or angle, angle, dt * turn_speed)

	local to_target = target_position - my_position
	local clamped_angle = math.min(constraint_info.max_angle, math.abs(angle))
	local direction = _rotate_around_z(UnitAux.unit_forward(unit), math.sign(angle) * clamped_angle)
	local new_to_target = direction * math.max(Vector3.length(to_target), 3)

	target_position = my_position + new_to_target + Vector3Aux.unbox(constraint_info.offset)

	local constraint_target = constraint_info.constraint_target

	Unit.animation_set_constraint_target(unit, constraint_target, target_position)

	state.current_angle = angle
end

AimConstraintComponent.remove_target_reference = function (self, state, entity_to_be_removed)
	if state.look_target == entity_to_be_removed then
		state.look_target = nil
	end
end

AimConstraintComponent.on_entity_unregistering = function (self, entity)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		self:remove_target_reference(context.state, entity)
	end

	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		self:remove_target_reference(context.state, entity)
	end
end

AimConstraintComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set_look_target" and data ~= state.look_target then
		state.look_target = data
		state.dirty = true
	end
end
