﻿-- chunkname: @lua/components/animation_component.lua

require("foundation/lua/component/base_component")

AnimationComponent = class("AnimationComponent", "BaseComponent")

AnimationComponent.init = function (self, creation_context)
	BaseComponent.init(self, "animation", creation_context, true)
	self:register_rpc_events("rpc_animation_event", "rpc_animation_event_death", "rpc_animation_state", "rpc_animation_state_large", "game_object_sync_done")
	self:register_interfaces("i_speed_listener")
end

AnimationComponent.migrated_away = function (self, unit, slave_context, master_context)
	local num_commands = master_context.num_commands

	for i = 1, num_commands do
		local command = master_context.command_queue[i]

		EntityAux.queue_command_slave(unit, self.name, command.key, command.data)
	end
end

local function _get_animation_speed(state)
	return math.clamp(state.animation_speed_mixer:get(), 0, 3)
end

AnimationComponent._update_animation_speed = function (self, unit, context)
	local state = context.state

	if not state.animation_speed_paused then
		state.animation_speed = math.max(_get_animation_speed(state), 0.2)

		self.replicator:write_fields(context)

		EntityAux._state_raw(unit, self.name).animation_speed = state.animation_speed
	end
end

AnimationComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.animation_speed_mixer = AddMixer()

	if EntityAux.has_component(unit, "enemy") then
		local animation_speed = context.settings.override_difficulty_speed or DifficultyManager:difficulty_speed()

		state.animation_speed_mixer:add("default", animation_speed)
	else
		state.animation_speed_mixer:add("default", 1)
	end
end

AnimationComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.ignore_rpc_anim_mixer = RefMixer()
	state.animation_speed_variable = Unit.animation_find_variable(unit, "animation_speed")
	state.previous_animation_speed = 1

	if context.settings.animation_merge_options then
		local merge_options = context.settings.animation_merge_options

		Unit.set_animation_merge_options(unit, "max_start_time", merge_options.max_start_time or 0, "max_drift", merge_options.max_drift or 0, "clock_fidelity", merge_options.clock_fidelity or 1)
	end

	if EntityAux.owned(unit) then
		self:_update_animation_speed(unit, EntityAux._context_master_raw(unit, self.name))
	end
end

AnimationComponent.pause = function (self, unit, master_context, slave_context)
	BaseComponent.pause(self, unit, master_context, slave_context)

	if Unit.has_animation_event(unit, "pause") then
		Unit.animation_event(unit, "pause")
	end
end

AnimationComponent.resume = function (self, unit, master_context, slave_context)
	BaseComponent.resume(self, unit, master_context, slave_context)

	if Unit.has_animation_event(unit, "move") then
		Unit.animation_event(unit, "move")
	end
end

AnimationComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)
	local prediction_entities = entity_manager:get_prediction_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("filter_slave_commands")
	self:filter_slave_commands(prediction_entities)
	Profiler.stop()
	Profiler.start("update_predictors")
	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
	Profiler.start("command_slaves")
	self:command_slaves(slave_entities)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

AnimationComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		if context.prediction_state.animation_speed then
			context.state.animation_speed = context.prediction_state.animation_speed
		end
	end
end

AnimationComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.previous_animation_speed ~= state.animation_speed then
			local variable = state.animation_speed_variable

			Unit.animation_set_variable(unit, variable, state.animation_speed)

			state.previous_animation_speed = state.animation_speed
		end
	end
end

AnimationComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "trigger_event" or command_name == "trigger_event_death" or command_name == "trigger_event_local" then
		if data then
			if not Unit.has_animation_event(unit, data) then
				return
			end

			if command_name == "trigger_event_death" then
				state.paused = false
			end

			if not state.disabled and not state.paused then
				self:queue_command_slave(unit, self.name, command_name, data)

				if command_name == "trigger_event_death" then
					state.disabled = true

					state.animation_speed_mixer:clear()
					state.animation_speed_mixer:add("default", 1)
					self:_update_animation_speed(unit, context)
					self:trigger_rpc_event_to_others("rpc_animation_event_death", unit, data)
				elseif command_name == "trigger_event" then
					self:trigger_rpc_event_to_others("rpc_animation_event", unit, data)
				end
			end
		elseif data ~= "none" then
			-- Nothing
		end
	elseif command_name == "set_pause" then
		state.paused = data

		self:queue_command_slave(unit, self.name, command_name, data)
	elseif command_name == "set_animation_speed_paused" then
		state.animation_speed_paused = data
		state.animation_speed = data and 0 or _get_animation_speed(state)

		self.replicator:write_fields(context)

		EntityAux._state_raw(unit, self.name).animation_speed = state.animation_speed
	elseif command_name == "add_speed_multiplier" then
		if not state.disabled then
			local id = data.id

			state.animation_speed_mixer:add(id, data.value)
			self:_update_animation_speed(unit, context)
		end
	elseif command_name == "remove_speed_multiplier" and not state.disabled then
		state.animation_speed_mixer:remove(data)
		self:_update_animation_speed(unit, context)
	end
end

AnimationComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set_ignore_rpc_animations" then
		local id = data.id
		local add = data.state == "on"

		if add then
			state.ignore_rpc_anim_mixer:add(id)
		elseif state.ignore_rpc_anim_mixer.values[id] then
			state.ignore_rpc_anim_mixer:remove(id)
		end

		state.ignore_rpc_animations = state.ignore_rpc_anim_mixer:get()

		return true
	elseif command_name == "override_animation_speed" then
		context.prediction_state.animation_speed = data

		return true
	end
end

AnimationComponent.command_slave = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "trigger_event" or command_name == "trigger_event_death" or command_name == "trigger_event_local" or command_name == "trigger_event_remote" then
		if not Unit.has_animation_event(unit, data) then
			return
		end

		if command_name == "trigger_event_remote" and state.ignore_rpc_animations then
			return
		end

		if state.disabled then
			return
		end

		if command_name == "trigger_event_death" then
			state.disabled = true

			Unit.animation_event(unit, data)
		elseif not state.pause then
			Unit.animation_event(unit, data)
		end
	elseif command_name == "set_pause" then
		state.paused = data
	end
end

AnimationComponent.rpc_animation_event = function (self, sender, unit, animation_event)
	if unit == nil then
		return
	end

	self:queue_command_slave(unit, self.name, "trigger_event_remote", animation_event)
end

AnimationComponent.rpc_animation_event_death = function (self, sender, unit, animation_event)
	if unit == nil then
		return
	end

	self:queue_command_slave(unit, self.name, "trigger_event_death", animation_event)
end

AnimationComponent.rpc_animation_state = function (self, sender, unit, animation_state)
	if unit == nil then
		return
	end

	Unit.animation_set_state(unit, unpack(animation_state))
end

AnimationComponent.rpc_animation_state_large = function (self, sender, unit, animation_state)
	if unit == nil then
		return
	end

	Unit.animation_set_state(unit, unpack(animation_state))
end

AnimationComponent.game_object_sync_done = function (self, peer_id)
	for unit, context in pairs(self.entity_manager:get_master_entities(self.name)) do
		local animation_state = {
			Unit.animation_get_state(unit),
		}

		if #animation_state > 3 then
			self:trigger_rpc_event_to(peer_id, "rpc_animation_state_large", unit, animation_state)
		else
			self:trigger_rpc_event_to(peer_id, "rpc_animation_state", unit, animation_state)
		end
	end

	for unit, paused_info in pairs(self.entity_manager.paused_contexts[self.name]) do
		local context = paused_info.master_context

		if context and not context.state.disabled then
			self:trigger_rpc_event_to(peer_id, "rpc_animation_event", unit, "move")
		end
	end
end
