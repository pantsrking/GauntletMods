﻿-- chunkname: @lua/components/ability_component.lua

require("lua/components/ability_aux")
require("lua/components/ability_event_handler")
require("foundation/lua/component/base_component")

AbilityComponent = class("AbilityComponent", "BaseComponent")

AbilityComponent.init = function (self, creation_context)
	BaseComponent.init(self, "ability", creation_context, true)
	self:register_events("on_world_disabled", "on_entity_unregistering", "on_remove_my_entities")
	self:register_dependencies("i_hit_receiver")
	self:register_rpc_events("rpc_execute_ability", "rpc_execute_ability_at_target", "rpc_execute_ability_at_target_unit", "rpc_ability_request", "rpc_ability_request_at_target", "rpc_ability_request_at_target_unit", "rpc_execute_requested_ability", "rpc_execute_requested_ability_at_target", "rpc_execute_requested_ability_at_target_unit", "rpc_hotjoin_start_ability", "rpc_hotjoin_start_ability_at_target", "rpc_hotjoin_start_ability_at_target_unit", "rpc_append_ability", "rpc_interrupt_ability", "rpc_force_interrupt_ability", "rpc_ability_request_granted", "game_object_sync_done", "rpc_span_lightning", "rpc_span_lightning_position", "rpc_start_charge_marker")

	self.ability_event_handler = AbilityEventHandler(self, creation_context)
	self.nav_grid = creation_context.nav_grid
	self.timpani_world = self.world_proxy:get_timpani_world()
	self.randomizer = Randomizer(creation_context.seed)
	self.ability_cache = {}
end

AbilityComponent.destroy = function (self)
	self.ability_event_handler:destroy()
	BaseComponent.destroy(self)
end

AbilityComponent.game_object_sync_done = function (self, peer_id)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if state.current_ability then
			local ability = state.current_ability
			local static_ability = ability.static_ability
			local ability_name, settings_path = static_ability.ability_name, static_ability.settings_path
			local current_frame = ability.timer and math.floor(ability.timer * 30) or 0

			if ability.target_position_box then
				local target_position = Vector3Aux.unbox(ability.target_position_box)

				self:trigger_rpc_event_to(peer_id, "rpc_hotjoin_start_ability_at_target", unit, target_position, ability_name, settings_path, ability.ability_id, current_frame)
			elseif ability.target_unit then
				self:trigger_rpc_event_to(peer_id, "rpc_hotjoin_start_ability_at_target_unit", unit, ability.target_unit, ability_name, settings_path, ability.ability_id, current_frame)
			else
				self:trigger_rpc_event_to(peer_id, "rpc_hotjoin_start_ability", unit, ability_name, settings_path, ability.ability_id, current_frame)
			end
		end
	end
end

AbilityComponent.rpc_hotjoin_start_ability = function (self, sender, unit, ability_name, settings_path, ability_id, current_frame)
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "ability_id", ability_id, "current_frame", current_frame)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_hotjoin_start_ability_at_target_unit = function (self, sender, unit, target_unit, ability_name, settings_path, ability_id, current_frame)
	local command = TempTableFactory:get_map("target_unit", target_unit, "ability_name", ability_name, "settings_path", settings_path, "ability_id", ability_id, "current_frame", current_frame)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_hotjoin_start_ability_at_target = function (self, sender, unit, target_position, ability_name, settings_path, ability_id, current_frame)
	local command = TempTableFactory:get_map("target_position", target_position, "ability_name", ability_name, "settings_path", settings_path, "ability_id", ability_id, "current_frame", current_frame)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.hotjoin_catch_up_ability = function (self, unit, context, ability, current_frame)
	local static_ability = ability.static_ability
	local start_frame = -1
	local end_frame = current_frame

	ability.timer = current_frame / 30

	if start_frame < end_frame then
		for i = start_frame + 1, end_frame do
			local callbacks = static_ability.ability_callbacks[i]

			if callbacks then
				for _, ac in ipairs(callbacks) do
					if ac.duration then
						if ability.running_updates == nil then
							ability.running_updates = {}
						end

						ability.running_updates[#ability.running_updates + 1] = {
							action = ac,
							time_left = ac.duration,
						}
					end

					ac.func(self, unit, context, ability, 0)
				end
			end
		end
	end
end

AbilityComponent.migration_catch_up_ability = function (self, unit, context, ability)
	local static_ability = ability.static_ability
	local start_frame = -1
	local end_frame = math.floor(ability.timer * 30)

	if start_frame < end_frame then
		for i = start_frame + 1, end_frame do
			local callbacks = static_ability.migration_callbacks[i]

			if callbacks then
				for _, ac in ipairs(callbacks) do
					if ac.duration then
						if ability.running_updates == nil then
							ability.running_updates = {}
						end

						ability.running_updates[#ability.running_updates + 1] = {
							action = ac,
							time_left = ac.duration,
						}
					end

					ac.func(self, unit, context, ability, 0)
				end
			end
		end
	end
end

AbilityComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context)

	local master_state = master_context.state
	local slave_state = slave_context.state

	master_state.ability_id_counter = slave_state.ability_id_counter
	master_state.active_abilities = slave_state.active_abilities
	master_state.busy_time = slave_state.busy_time
	master_state.current_ability = slave_state.current_ability
	slave_state.current_ability = nil
	master_state.is_busy = slave_state.is_busy
	master_state.active_abilities = slave_state.active_abilities

	local active_abilities = slave_state.active_abilities

	for i, ability in ipairs(active_abilities) do
		if ability.static_ability.migration_callbacks then
			local slave_static_ability = ability.static_ability
			local settings_path = slave_static_ability.settings_path
			local ability_name = slave_static_ability.ability_name
			local static_ability = self:create_ability(unit, settings_path, ability_name, true)

			ability.static_ability = static_ability

			self:migration_catch_up_ability(unit, master_context, ability)
		end
	end
end

AbilityComponent.migrated_away = function (self, unit, slave_context, master_context)
	local master_state = master_context.state
	local slave_state = slave_context.state

	slave_state.ability_id_counter = master_state.ability_id_counter
	slave_state.active_abilities = master_state.active_abilities
	slave_state.busy_time = master_state.busy_time
	slave_state.current_ability = master_state.current_ability
	slave_state.is_busy = master_state.is_busy
	slave_state.active_abilities = master_state.active_abilities

	local active_abilities = master_state.active_abilities

	for i, ability in ipairs(active_abilities) do
		local master_static_ability = ability.static_ability
		local settings_path = master_static_ability.settings_path
		local ability_name = master_static_ability.ability_name
		local static_ability = self:create_ability(unit, settings_path, ability_name, false)

		ability.static_ability = static_ability
		ability.running_updates = {}
	end
end

AbilityComponent.setup_master = function (self, unit, context)
	local state = context.state

	if state.active_abilities == nil then
		state.ability_id_counter = 0
		state.active_abilities = {}
		state.enabled = true
	end
end

AbilityComponent.setup_slave = function (self, unit, context)
	local state = context.state

	state.ability_id_counter = 0
	state.active_abilities = {}
	state.enabled = true
end

AbilityComponent.pause = function (self, unit, master_context, slave_context)
	EntityAux.command_immediately(unit, self.name, "force_interrupt")
	BaseComponent.pause(self, unit, master_context, slave_context)
end

AbilityComponent.on_script_reload = function (self)
	self.ability_cache = {}

	BaseComponent.on_script_reload(self)
end

AbilityComponent.reload_master = function (self, unit, context)
	context.num_commands = 0
end

AbilityComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

AbilityComponent.update = function (self, dt)
	BaseComponent.update(self, dt)
	self.ability_event_handler:update(dt)
end

AbilityComponent.post_update = function (self, dt)
	BaseComponent.post_update(self, dt)
	self.ability_event_handler:post_update(dt)
end

AbilityComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		for _, ability in ipairs(state.active_abilities) do
			if ability.waiting_for_target_unit then
				local done, target_unit = ability.waiting_for_target_unit()

				if done then
					ability.target_unit = target_unit

					local static_ability = ability.static_ability

					self:trigger_rpc_event_to_others("rpc_execute_ability_at_target_unit", unit, target_unit, static_ability.ability_name, static_ability.settings_path, ability.ability_id)

					ability.waiting_for_target_unit = nil
				end
			end
		end

		self:update_abilities(unit, context, dt)
	end
end

AbilityComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		self:update_abilities(unit, context, dt)
	end
end

AbilityComponent.execute_ability = function (self, unit, context, ability_data)
	local ability_name = ability_data.ability_name
	local settings_path = ability_data.settings_path
	local owner_unit = ability_data.owner_unit
	local caster_unit = ability_data.caster_unit
	local target_unit = ability_data.target_unit
	local target_position = ability_data.target_position
	local stat_creditor_go_id = ability_data.stat_creditor_go_id
	local ability_id = ability_data.ability_id

	Profiler.start("execute_ability: %s", ability_name)

	local state = context.state
	local static_ability = self:create_ability(unit, settings_path, ability_name)
	local ability = {}

	if static_ability.clear_target_unit then
		target_unit = nil
	end

	ability.static_ability = static_ability
	ability.ability_id = ability_id
	ability.target_unit = target_unit
	ability.owner_unit = Unit.alive(owner_unit) and owner_unit or unit
	ability.caster_unit = Unit.alive(caster_unit) and caster_unit or unit

	if Unit.alive(target_unit) and static_ability.extract_target_position then
		local node = static_ability.extract_target_position.node

		target_position = Unit.world_position(target_unit, Unit.node(target_unit, node))
	end

	if static_ability.constrain_target_position_to_navgrid then
		target_position = self.nav_grid:sweep_circle(Unit.world_position(ability.caster_unit, 0), target_position, 0.5)
	end

	if target_position then
		ability.target_position_box = type(target_position) == "table" and Vector3Aux.box_copy({}, target_position) or Vector3Aux.box({}, target_position)
	elseif target_unit then
		ability.target_unit = target_unit
		target_position = Unit.world_position(target_unit, 0)
	end

	if static_ability.movements_forward == "towards_target" then
		local my_position = Unit.world_position(unit, 0)
		local vector = target_position - my_position

		vector.z = 0

		local forward = Vector3.normalize(vector)

		ability.stored_forward = Vector3Aux.box({}, forward)
	elseif static_ability.movements_forward == "away_from_target" then
		local my_position = Unit.world_position(unit, 0)
		local vector = target_position - my_position

		vector.z = 0

		local forward = Vector3.normalize(vector)

		ability.stored_forward = Vector3Aux.box({}, -forward)
	elseif static_ability.movements_forward == "initial_forward" then
		ability.stored_forward = Vector3Aux.box({}, Quaternion.forward(Unit.local_rotation(unit, 0)))
	end

	if ability.caster_unit == unit and static_ability.set_as_busy ~= false then
		local busy_time = static_ability.duration >= 0 and static_ability.duration or 0

		if state.busy_time == nil or busy_time > state.busy_time or static_ability.duration == -1 then
			if static_ability.duration == -1 then
				state.busy_time = nil
				state.is_busy = true
			else
				state.busy_time = busy_time
				state.is_busy = state.busy_time > 0
			end

			state.current_ability = ability
		end
	end

	self:append_ability(unit, context, ability, stat_creditor_go_id)
	Profiler.stop()

	return ability
end

AbilityComponent.append_ability = function (self, unit, context, ability, stat_creditor_go_id)
	local state = context.state
	local static_ability = ability.static_ability

	if static_ability.on_enter then
		self:handle_event_callback(unit, context, ability, static_ability.on_enter)
	end

	if stat_creditor_go_id == nil then
		stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(ability.owner_unit or unit)
	end

	ability.stat_creditor_go_id = stat_creditor_go_id

	local active_abilities = state.active_abilities

	active_abilities[#active_abilities + 1] = ability
	ability.timer = nil

	if state.plugin_draw then
		local drawer = Debug.drawer("damage" .. tostring(EntityAux.go_id(unit)))

		drawer:reset()
	end
end

AbilityComponent.create_ability = function (self, unit, settings_path, ability_name, master_version)
	master_version = master_version == nil and EntityAux.owned(unit) or master_version

	local key = sprintf("%s%s%t", settings_path, ability_name, master_version)
	local ability = self.ability_cache[key]

	if ability == nil then
		Profiler.start("create")

		settings_path = settings_path or Unit.get_data(unit, "settings_path")
		ability = AbilityAux.create_ability_by_path(ability_name, settings_path, master_version, unit)
		ability = protect(ability)
		self.ability_cache[key] = ability

		Profiler.stop()
	end

	return ability
end

AbilityComponent.update_abilities = function (self, unit, context, dt)
	local state = context.state
	local active_abilities = state.active_abilities

	dt = AbilityAux.scale_delta_time(unit, dt)

	if state.busy_time then
		state.busy_time = state.busy_time - dt

		if state.busy_time <= 0 then
			state.is_busy = false
			state.busy_time = nil
		end
	end

	if #active_abilities == 0 then
		return
	end

	Profiler.start("update_abilities")
	self:update_active_abilities(unit, context, dt, active_abilities)
	array.remove_all_where(active_abilities, "dirty", true)
	Profiler.stop()
end

AbilityComponent.update_active_abilities = function (self, unit, context, dt, active_abilities)
	local ability_dt = dt

	for i, ability in ipairs(active_abilities) do
		local static_ability = ability.static_ability

		if ability.caster_unit ~= unit then
			dt = AbilityAux.scale_delta_time(ability.caster_unit, _G.GAME_DT)
		else
			dt = ability_dt
		end

		Profiler.start("settings_path: %s", static_ability.settings_path)

		if ability.running_updates then
			for key, running_update in pairs(ability.running_updates) do
				running_update.action.func(self, unit, context, ability, dt)

				running_update.time_left = running_update.time_left - dt

				if running_update.time_left <= 0 then
					ability.running_updates[key] = nil
				end
			end
		end

		local timer = ability.timer
		local start_frame = timer == nil and -1 or math.floor(timer * 30)

		timer = (timer or 0) + dt

		local end_frame = math.floor(timer * 30)

		ability.timer = timer

		if start_frame < end_frame then
			for i = start_frame + 1, end_frame do
				local callbacks = static_ability.ability_callbacks[i]

				if callbacks then
					for _, ac in ipairs(callbacks) do
						if ac.duration then
							if ability.running_updates == nil then
								ability.running_updates = {}
							end

							ability.running_updates[#ability.running_updates + 1] = {
								action = ac,
								time_left = ac.duration,
							}
						end

						ac.func(self, unit, context, ability, dt)
					end
				end
			end
		end

		Profiler.stop()
	end
end

AbilityComponent.handle_event_callback = function (self, unit, context, ability, info)
	Profiler.start("handle_event_callback")

	for i, event_callback in ipairs(info.event_callbacks) do
		event_callback(self, unit, context, ability)
	end

	Profiler.stop()
end

AbilityComponent.on_ability_exit = function (self, unit, context, ability)
	for _, cb in ipairs(ability.static_ability.exit_callbacks) do
		cb(self, unit, context, ability)
	end

	ability.dirty = true

	local state = context.state

	if state.current_ability == ability then
		state.current_ability = nil
	end
end

AbilityComponent._handle_append_ability_command = function (self, unit, context, command_data)
	local ability_name = command_data.ability_name
	local settings_path = command_data.settings_path
	local static_ability = self:create_ability(unit, settings_path, ability_name)
	local ability = {}

	ability.override_pose = command_data.override_pose
	ability.inherited_hitlist = command_data.inherited_hitlist
	ability.target_unit = command_data.target_unit
	ability.caster_unit = command_data.caster_unit
	ability.ability_id = command_data.ability_id
	ability.static_ability = static_ability

	self:append_ability(unit, context, ability, command_data.stat_creditor_go_id)
end

AbilityComponent._handle_interrupt_command = function (self, unit, context, force_interrupt)
	local state = context.state

	state.busy_time = nil
	state.is_busy = nil

	if state.current_ability then
		local static_ability = state.current_ability.static_ability
		local interrupt = (force_interrupt or not static_ability.ignore_interrupt) and not static_ability.run_until_death

		if interrupt then
			state.current_ability.interrupted = true

			for i, ability in ipairs(state.active_abilities) do
				if ability == state.current_ability then
					table.remove(state.active_abilities, i)

					break
				end
			end

			self:on_ability_exit(unit, context, state.current_ability)
		end
	end
end

AbilityComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "ability_request_granted" then
		state.waiting_for_ability_request = nil
		state.is_busy = false
	elseif command_name == "execute_ability_request" then
		if not state.enabled then
			return
		end

		local request_target = data.request_target

		state.is_busy = true
		state.waiting_for_ability_request = request_target

		if data.target_position then
			self:trigger_rpc_event_to(EntityAux.owner(request_target), "rpc_ability_request_at_target", unit, Vector3Aux.unbox(data.target_position), data.ability_name, data.settings_path)
		elseif data.target_unit then
			self:trigger_rpc_event_to(EntityAux.owner(request_target), "rpc_ability_request_at_target_unit", unit, data.target_unit, data.ability_name, data.settings_path)
		else
			self:trigger_rpc_event_to(EntityAux.owner(request_target), "rpc_ability_request", unit, data.ability_name, data.settings_path)
		end
	elseif command_name == "execute_ability" then
		if data.force_execution ~= true and not state.enabled then
			return
		end

		if data.is_requested_ability then
			data.execute_local_only = true
		end

		if data.target_unit and not Unit.alive(data.target_unit) then
			return
		end

		data.settings_path = data.settings_path or Unit.get_data(unit, "settings_path")
		data.ability_id = AbilityAux.generate_ability_id(unit, state)

		local ability = self:execute_ability(unit, context, data)

		ability.ability_event_listeners = data.ability_event_listeners
		ability.waiting_for_target_unit = data.wait_for_target_unit

		if not data.execute_local_only and not ability.waiting_for_target_unit then
			if ability.target_position_box then
				local target_position = Vector3Aux.unbox(ability.target_position_box)

				self:trigger_rpc_event_to_others("rpc_execute_ability_at_target", unit, target_position, data.ability_name, data.settings_path, data.ability_id)
			elseif ability.target_unit then
				self:trigger_rpc_event_to_others("rpc_execute_ability_at_target_unit", unit, ability.target_unit, data.ability_name, data.settings_path, data.ability_id)
			else
				self:trigger_rpc_event_to_others("rpc_execute_ability", unit, data.ability_name, data.settings_path, data.ability_id)
			end
		end
	elseif command_name == "append_ability" then
		if data.target_unit and not Unit.alive(data.target_unit) then
			return
		end

		local override_pose = data.override_pose
		local pose = Matrix4x4Box.unbox(override_pose)
		local position, rotation = Matrix4x4.translation(pose), Matrix4x4.rotation(pose)

		data.ability_id = AbilityAux.generate_ability_id(unit, state)

		self:trigger_rpc_event_to_others("rpc_append_ability", unit, data.ability_name, data.settings_path, position, rotation, data.ability_id)
		self:_handle_append_ability_command(unit, context, data)
	elseif command_name == "interrupt" or command_name == "force_interrupt" then
		state.waiting_for_ability_request = nil

		self:_handle_interrupt_command(unit, context, command_name == "force_interrupt")

		local force_interrupt = command_name == "force_interrupt"

		if force_interrupt then
			self:trigger_rpc_event_to_others("rpc_force_interrupt_ability", unit)
		else
			self:trigger_rpc_event_to_others("rpc_interrupt_ability", unit)
		end
	elseif command_name == "set_enabled" then
		if not data then
			for i, ability in ipairs(state.active_abilities) do
				local static_ability = ability.static_ability

				if not static_ability.never_interrupt and ability.caster_unit == unit and not static_ability.run_until_death then
					ability.interrupted = true

					self:on_ability_exit(unit, context, ability)
				end
			end

			array.remove_all_where(state.active_abilities, "dirty", true)
		end

		state.enabled = data
	end
end

AbilityComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "execute_ability" then
		if data.force_execution ~= true and not state.enabled then
			return
		end

		if data.target_unit and not Unit.alive(data.target_unit) then
			return
		end

		data.settings_path = data.settings_path or Unit.get_data(unit, "settings_path")

		local ability = self:execute_ability(unit, context, data)

		if data.current_frame then
			self:hotjoin_catch_up_ability(unit, context, ability, data.current_frame)
		end
	elseif command_name == "execute_requested_ability" then
		if not state.enabled then
			return
		end

		if data.target_unit and not Unit.alive(data.target_unit) then
			return
		end

		data.settings_path = data.settings_path or Unit.get_data(unit, "settings_path")
		data.ability_id = AbilityAux.generate_ability_id(unit, state)

		local ability = self:execute_ability(unit, context, data)

		if ability.target_position_box then
			local target_position = Vector3Aux.unbox(ability.target_position_box)

			self:trigger_rpc_event_to_others("rpc_execute_requested_ability_at_target", unit, target_position, data.ability_name, data.settings_path, data.ability_id)
		elseif ability.target_unit then
			self:trigger_rpc_event_to_others("rpc_execute_requested_ability_at_target_unit", unit, ability.target_unit, data.ability_name, data.settings_path, data.ability_id)
		else
			self:trigger_rpc_event_to_others("rpc_execute_requested_ability", unit, data.ability_name, data.settings_path, data.ability_id)
		end
	elseif command_name == "append_ability" then
		if data.target_unit and not Unit.alive(data.target_unit) then
			return
		end

		self:_handle_append_ability_command(unit, context, data)
	elseif command_name == "set_enabled" then
		if not data then
			for i, ability in ipairs(state.active_abilities) do
				local static_ability = ability.static_ability

				if not static_ability.never_interrupt and ability.caster_unit == unit and not static_ability.run_until_death then
					ability.interrupted = true

					self:on_ability_exit(unit, context, ability)
				end
			end

			array.remove_all_where(state.active_abilities, "dirty", true)
		end

		state.enabled = data
	elseif command_name == "interrupt" or command_name == "force_interrupt" then
		self:_handle_interrupt_command(unit, context, command_name == "force_interrupt")
	end

	return true
end

AbilityComponent.rpc_ability_request_granted = function (self, sender, unit)
	if not unit then
		return
	end

	if not EntityAux.owned(unit) then
		return
	end

	self:queue_command_master(unit, "ability", "ability_request_granted")
end

AbilityComponent.rpc_ability_request = function (self, sender, unit, ability_name, settings_path)
	if not unit then
		return
	end

	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path)

	self:_handle_ability_request(sender, unit, command)
end

AbilityComponent.rpc_ability_request_at_target = function (self, sender, unit, target_position, ability_name, settings_path)
	if not unit then
		return
	end

	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "target_position", target_position)

	self:_handle_ability_request(sender, unit, command)
end

AbilityComponent.rpc_ability_request_at_target_unit = function (self, sender, unit, target_unit, ability_name, settings_path)
	if not unit then
		return
	end

	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "target_unit", target_unit)

	self:_handle_ability_request(sender, unit, command)
end

AbilityComponent._handle_ability_request = function (self, sender, unit, command)
	if EntityAux.owned(unit) then
		return
	end

	if not EntityAux.state(unit, "animation").ignore_rpc_animations then
		self:queue_command_predictor(unit, "ability", "execute_requested_ability", command)
	end

	self:trigger_rpc_event_to(sender, "rpc_ability_request_granted", unit)
end

AbilityComponent.rpc_execute_requested_ability = function (self, sender, unit, ability_name, settings_path, ability_id)
	if unit == nil then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "is_requested_ability", true, "ability_id", ability_id)

	self:queue_command(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_execute_requested_ability_at_target = function (self, sender, unit, target_position, ability_name, settings_path, ability_id)
	if unit == nil then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "is_requested_ability", true, "target_position", target_position, "ability_id", ability_id)

	self:queue_command(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_execute_requested_ability_at_target_unit = function (self, sender, unit, target_unit, ability_name, settings_path, ability_id)
	if unit == nil then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "is_requested_ability", true, "target_unit", target_unit, "ability_id", ability_id)

	self:queue_command(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_execute_ability = function (self, sender, unit, ability_name, settings_path, ability_id)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "ability_id", ability_id)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_execute_ability_at_target = function (self, sender, unit, target_position, ability_name, settings_path, ability_id)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "target_position", target_position, "ability_id", ability_id)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_execute_ability_at_target_unit = function (self, sender, unit, target_unit, ability_name, settings_path, ability_id)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "target_unit", target_unit, "ability_id", ability_id)

	self:queue_command_predictor(unit, "ability", "execute_ability", command)
end

AbilityComponent.rpc_append_ability = function (self, sender, unit, ability_name, settings_path, position, rotation, ability_id)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	local settings_path = settings_path or Unit.get_data(unit, "settings_path")
	local pose = Matrix4x4.from_quaternion_position(rotation, position)
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "override_pose", Matrix4x4Box(pose), "ability_id", ability_id)

	self:queue_command_predictor(unit, "ability", "append_ability", command)
end

AbilityComponent.rpc_interrupt_ability = function (self, sender, unit)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	self:queue_command_predictor(unit, "ability", "interrupt")
end

AbilityComponent.rpc_force_interrupt_ability = function (self, sender, unit)
	if not unit then
		return
	end

	if EntityAux.owned(unit) then
		return
	end

	self:queue_command_predictor(unit, "ability", "force_interrupt")
end

AbilityComponent.rpc_span_lightning_position = function (self, sender, caster, unit_a, position)
	if caster and unit_a then
		local node = 0

		if caster == unit_a then
			node = Unit.node(caster, "j_l_hand_attach")
		end

		Unit.set_flow_variable(caster, "event_position", Unit.world_position(unit_a, node))
		Unit.set_flow_variable(caster, "chain_hit_position", position)
		Unit.flow_event(caster, "chain_hit_nothing")
	end
end

AbilityComponent.rpc_span_lightning = function (self, sender, caster, unit_a, unit_b)
	if unit_a and unit_b and caster then
		local origin
		local offset = Vector3.up()

		if caster == unit_a then
			origin = Unit.world_position(caster, Unit.node(caster, "j_l_hand_attach"))
		else
			origin = Unit.world_position(unit_a, 0) + offset
		end

		Unit.set_flow_variable(caster, "hit_unit", unit_b)
		Unit.set_flow_variable(caster, "event_position", origin)
		Unit.set_flow_variable(caster, "chain_hit_position", Unit.world_position(unit_b, 0) + offset)
		Unit.flow_event(caster, "chain_hit")
	end
end

AbilityComponent.rpc_start_charge_marker = function (self, sender, unit, charge_target)
	if unit and charge_target then
		Unit.set_flow_variable(unit, "charge_target", charge_target)
		Unit.flow_event(unit, "ability_charge_start")
	end
end

local function _handle_entity_removal(unit, state, entity)
	if unit ~= entity then
		for i, ability in ipairs(state.active_abilities) do
			if ability.owner_unit == entity then
				ability.owner_unit = unit
			end

			if ability.caster_unit == entity then
				ability.caster_unit = unit
			end

			if ability.target_unit == entity then
				ability.target_unit = nil
			end
		end
	end
end

AbilityComponent.on_entity_unregistering = function (self, entity)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if state.waiting_for_ability_request == entity then
			state.waiting_for_ability_request = nil
			state.is_busy = false
		end

		_handle_entity_removal(unit, state, entity)

		if unit == entity then
			self:_handle_interrupt_command(unit, context, true)
		end
	end

	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		_handle_entity_removal(unit, context.state, entity)

		if unit == entity then
			self:_handle_interrupt_command(unit, context, true)
		end
	end
end

AbilityComponent.on_world_disabled = function (self)
	self.ability_cache = {}
end

AbilityComponent.on_remove_my_entities = function (self)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		table.clear(state.active_abilities)

		if state.current_ability then
			state.current_ability = nil
		end
	end

	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state

		table.clear(state.active_abilities)

		if state.current_ability then
			state.current_ability = nil
		end
	end
end

AbilityComponent.has_active_ability = function (unit)
	if not Unit.alive(unit) or not EntityAux.has_component(unit, "ability") then
		return false
	end

	local state = EntityAux.has_component_master(unit, "ability") and EntityAux.state_master(unit, "ability") or EntityAux.state(unit, "ability")

	return state and #state.active_abilities > 0
end
