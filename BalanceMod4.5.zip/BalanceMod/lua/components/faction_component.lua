﻿-- chunkname: @lua/components/faction_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/managers/broadphase_manager")

FactionComponent = class("FactionComponent", "PeriodicBaseComponent")

local bit = require("bit")
local lshift = bit.lshift
local bor = bit.bor
local band = bit.band
local bnot = bit.bnot
local FACTIONS = table.make_bimap({
	"evil",
	"neutral",
	"good",
	"spawner",
})
local FULL_UPDATES_PER_SECOND = 5

FactionComponent.BROADPHASE_ID = "factions"
FactionComponent.BROADPHASE_MAX_RADIUS = 50

FactionComponent.init = function (self, creation_context)
	PeriodicBaseComponent.init(self, "faction", creation_context, false, 1 / FULL_UPDATES_PER_SECOND)
	BroadphaseManager:create(FactionComponent.BROADPHASE_ID, FactionComponent.BROADPHASE_MAX_RADIUS, 200)
end

FactionComponent.destroy = function (self)
	BroadphaseManager:destroy(FactionComponent.BROADPHASE_ID)
	PeriodicBaseComponent.destroy(self)
end

FactionComponent.mask_complement = function (mask)
	return bnot(mask)
end

FactionComponent.are_allies_mask = function (mask_a, mask_b)
	return band(mask_a, mask_b) ~= 0
end

FactionComponent.is_evil = function (mask)
	return band(FACTIONS.evil, mask) ~= 0
end

FactionComponent.faction_mask = function (faction_name)
	local index = FACTIONS[faction_name]
	local mask = lshift(1, index - 1)

	return mask
end

FactionComponent.are_allies_unit = function (unit_a, unit_b)
	if EntityAux.has_component(unit_a, "faction") and EntityAux.has_component(unit_b, "faction") then
		local faction_a = EntityAux.state(unit_a, "faction").faction
		local faction_b = EntityAux.state(unit_b, "faction").faction

		return FactionComponent.are_allies_mask(faction_a, faction_b)
	end

	return false
end

FactionComponent.faction_array_to_mask = function (faction_array)
	local faction = 0

	for i, name in ipairs(faction_array) do
		faction = bor(faction, FactionComponent.faction_mask(name))
	end

	return faction
end

FactionComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.faction = FactionComponent.faction_array_to_mask(context.settings.faction)

	if context.settings.faction_queryable ~= nil then
		state.queryable = context.settings.faction_queryable
	else
		state.queryable = EntityAux.has_interface(unit, "i_hit_receiver")
	end
end

FactionComponent.setup_slave = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.faction = FactionComponent.faction_array_to_mask(settings.faction)
	state.original_faction = state.faction

	if settings.faction_queryable ~= nil then
		state.queryable = settings.faction_queryable
	else
		state.queryable = EntityAux.has_interface(unit, "i_hit_receiver")
	end

	if state.queryable then
		local position = Unit.local_position(unit, 0)
		local radius = UnitAux.max_shape_radius(unit) * 1.25

		state.previous_position = Vector3Aux.box({}, position)

		BroadphaseManager:add(FactionComponent.BROADPHASE_ID, unit, position, radius, state.faction)
	end

	self:register_unit_events(unit, "unit_on_death")

	if EntityAux.has_component_master(unit, self.name) then
		self.replicator:write_fields(context)
	end
end

FactionComponent.remove_slave = function (self, unit, context)
	if context.state.queryable then
		BroadphaseManager:remove(FactionComponent.BROADPHASE_ID, unit)
	end

	self:unregister_unit_event(unit, "unit_on_death")
end

FactionComponent.unit_on_death = function (self, unit)
	local queryable = EntityAux._state_raw(unit, self.name).queryable

	if queryable then
		EntityAux._state_raw(unit, self.name).queryable = false

		BroadphaseManager:remove(FactionComponent.BROADPHASE_ID, unit)
	end
end

FactionComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local slave_entities = entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(slave_entities) do
		context.full_update = self:decide_full_update(self.period, context)

		if context.full_update then
			local state = context.state

			if state.queryable then
				local position = Unit.world_position(unit, 0)

				if not Vector3.equal_2d(position, state.previous_position) then
					state.previous_position = Vector3Aux.box(state.previous_position, position)

					BroadphaseManager:move(FactionComponent.BROADPHASE_ID, unit, position)
				end
			end
		end
	end

	Profiler.stop()
end

FactionComponent.call_master_set_faction = function (self, unit, context, data)
	local state = context.state

	state.faction = data

	if state.queryable then
		BroadphaseManager:set_mask(FactionComponent.BROADPHASE_ID, unit, state.faction)
	end

	self:trigger_event("on_faction_changed", unit, state.faction)
	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).faction = state.faction
end

FactionComponent.call_master_reset_faction = function (self, unit, context)
	local state = context.state
	local settings = context.settings

	state.faction = FactionComponent.faction_array_to_mask(settings.faction)

	if state.queryable then
		BroadphaseManager:set_mask(FactionComponent.BROADPHASE_ID, unit, state.faction)
	end

	self:trigger_event("on_faction_changed", unit, state.faction)
	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).faction = state.faction
end
