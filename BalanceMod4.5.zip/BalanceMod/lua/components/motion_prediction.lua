﻿-- chunkname: @lua/components/motion_prediction.lua

MotionPrediction = {}

local GRAVITY_MAGNITUDE = 30

local function _update_position(state, position)
	state.positionx = position.x
	state.positiony = position.y
	state.positionz = position.z
end

MotionPrediction.update = function (component, unit, context, dt)
	local state, p_state = context.state, context.prediction_state

	if state.constrained_by_simple_mover ~= state.previous_constrained_by_simple_mover then
		state.previous_constrained_by_simple_mover = state.constrained_by_simple_mover

		local constrained = state.constrained_by_simple_mover

		if constrained then
			SimpleMoverWorld.add_unit(component.simple_mover_world, unit, context.settings.simple_mover_radius or 0.5)
		else
			SimpleMoverWorld.remove_unit(component.simple_mover_world, unit)
		end
	end

	if dt <= math.EPSILON then
		return
	end

	if p_state.disabled then
		if state.disabled then
			p_state.disabled = nil
		else
			state.disabled = true
		end
	end

	if state.disabled then
		return
	end

	state.position = Vector3(state.positionx, state.positiony, state.positionz)

	if p_state.position then
		state.position = Vector3Aux.unbox(p_state.position)

		local mover = Unit.mover(unit)

		if mover then
			Mover.set_position(mover, state.position)
		end

		state.positionx = state.position.x
		state.positiony = state.position.y
		state.positionz = state.position.z
	end

	if p_state.pending_state_change then
		if p_state.original_position then
			local last_known_position = Vector3Aux.unbox(p_state.original_position)
			local new_position = Vector3.lerp(Unit.local_position(unit, 0), last_known_position, 1 * dt)

			_update_position(state, new_position)
			Unit.set_local_position(unit, 0, new_position)
		end

		if _G.GAME_TIME >= p_state.state_change_time then
			p_state.motion_state = p_state.pending_state_change
			p_state.pending_state_change = nil
			p_state.original_position = nil
		end
	end

	if p_state.motion_state == "dynamic" then
		MotionPrediction.dynamic_prediction(component, unit, context, dt)
	elseif p_state.motion_state == "kinematic" then
		MotionPrediction.update_wanted_movement_prediction(component, unit, context, dt)
	elseif p_state.motion_state == "ability" then
		MotionPrediction.animation_driven_ability_movement_prediction(component, unit, context, dt)
	elseif context.settings.animation_driven_movement then
		MotionPrediction.animation_driven_movement_prediction(component, unit, context, dt)
	else
		MotionPrediction.update_normal_movement_prediction(component, unit, context, dt)
	end

	local position = Vector3(state.positionx, state.positiony, state.positionz)

	if p_state.position then
		Vector3Aux.box(p_state.position, position)
	end

	Unit.set_local_position(unit, 0, position)

	if state.constrained_by_simple_mover then
		SimpleMoverWorld.set_position(component.simple_mover_world, unit, position)
	end
end

MotionPrediction.update_wanted_movement_prediction = function (component, unit, context, dt)
	Profiler.start("Motion.update_prediction")

	local state = context.state
	local last_known_position = state.position
	local previous_position = Vector3Aux.unbox(state.previous_position)

	Vector3Aux.box(state.previous_position, last_known_position)

	local diff = Vector3.distance(last_known_position, previous_position)

	if diff > 1.5 then
		Vector3Aux.box(state.extrapolated_position, last_known_position)
	end

	local extrapolated_position = Vector3Aux.unbox(state.extrapolated_position)
	local velocity = Vector3Aux.unbox(context.prediction_state.wanted_velocity)
	local extrapolated_translation = velocity * dt
	local use_mover_in_kinematic_prediction = context.settings.use_mover_in_kinematic_prediction

	if use_mover_in_kinematic_prediction then
		extrapolated_translation = MovementConstraints.mover_move(component, unit, extrapolated_position, extrapolated_translation, dt)
	end

	extrapolated_position = extrapolated_position + extrapolated_translation

	local new_position = Vector3.lerp(extrapolated_position, last_known_position, math.saturate(10 * dt))

	Vector3Aux.box(state.extrapolated_position, new_position)
	_update_position(state, new_position)

	if use_mover_in_kinematic_prediction then
		Mover.set_position(Unit.mover(unit), new_position)
	end

	Profiler.stop()
end

MotionPrediction.update_normal_movement_prediction = function (component, unit, context, dt)
	Profiler.start("Motion.update_prediction")

	local state = context.state
	local last_known_position = state.position
	local previous_position = Vector3Aux.unbox(state.previous_position)

	Vector3Aux.box(state.previous_position, last_known_position)

	local diff = Vector3.distance(last_known_position, previous_position)

	if diff > 1.5 then
		Vector3Aux.box(state.extrapolated_position, last_known_position)
	end

	local extrapolated_position = Vector3Aux.unbox(state.extrapolated_position)
	local velocity = Vector3Aux.unbox(state.velocity)

	extrapolated_position = extrapolated_position + velocity * dt

	local new_position = Vector3.lerp(extrapolated_position, last_known_position, 10 * dt)

	Vector3Aux.box(state.extrapolated_position, new_position)
	_update_position(state, new_position)
	Profiler.stop()
end

MotionPrediction.animation_driven_movement_prediction = function (component, unit, context, dt)
	local state = context.state
	local last_known_position = state.position
	local previous_position = Vector3Aux.unbox(state.previous_position)

	Vector3Aux.box(state.previous_position, last_known_position)

	local predicted_position
	local diff = Vector3.distance(last_known_position, previous_position)

	if diff > 1.5 then
		predicted_position = last_known_position
	else
		predicted_position = Matrix4x4.translation(Unit.animation_wanted_root_pose(unit))
	end

	if not Vector3.is_valid(predicted_position) then
		predicted_position = last_known_position
	end

	local current_position = state.position
	local translation = predicted_position - current_position

	translation = MovementConstraints.navgrid_constrain(component, unit, current_position, translation)
	predicted_position = current_position + translation

	local new_position = Vector3.lerp(predicted_position, last_known_position, math.max(diff * 4, 4) * dt)

	new_position.z = math.lerp(new_position.z, state.position.z, 20 * dt)

	_update_position(state, new_position)
end

MotionPrediction.animation_driven_ability_movement_prediction = function (component, unit, context, dt)
	local state = context.state
	local last_known_position = state.position
	local previous_position = Vector3Aux.unbox(state.previous_position)

	Vector3Aux.box(state.previous_position, last_known_position)

	local wanted_translation = Unit.animation_wanted_root_translation(unit)
	local diff = Vector3.distance(last_known_position, previous_position)
	local current_position = state.position
	local translation = MovementConstraints.navgrid_constrain(component, unit, current_position, wanted_translation)
	local predicted_position = current_position + translation
	local new_position = Vector3.lerp(predicted_position, last_known_position, math.max(diff * 4, 4) * dt)

	new_position.z = math.lerp(new_position.z, state.position.z, 20 * dt)

	_update_position(state, new_position)
end

MotionPrediction.dynamic_prediction = function (component, unit, context, dt)
	local state = context.state
	local p_state = context.prediction_state

	Vector3Aux.box_copy(state.velocity, p_state.velocity)

	state.on_ground = true
	state.constrained_by_ground = true
	state.constrained_by_navgrid = true

	local translation = MotionPrediction.predict_dynamic_update(unit, context, dt)

	component:predict_move_to(unit, context, translation, dt)
	Vector3Aux.box_copy(p_state.velocity, state.velocity)

	p_state.position = {}
end

MotionPrediction.predict_dynamic_update = function (unit, context, dt)
	local state = context.state
	local velocity = state.collided and Vector3.zero() or Vector3Aux.unbox(state.velocity)
	local motion_info = state.motion_info
	local mass = motion_info.mass or 70

	velocity = velocity + Vector3(0, 0, -GRAVITY_MAGNITUDE * dt)

	if not motion_info.ignore_friction and state.on_ground then
		local is_still = velocity.x * velocity.x + velocity.y * velocity.y <= math.EPSILON

		if not is_still then
			local dynamic_friction = motion_info.dynamic_friction or 0.5
			local coefficient_of_friction = dynamic_friction
			local normal_force = mass * GRAVITY_MAGNITUDE
			local friction_magnitude = coefficient_of_friction * normal_force
			local tangential_velocity

			if state.last_normal then
				local normal = Vector3Aux.unbox(state.last_normal)
				local dot = Vector3.dot(velocity, normal)

				tangential_velocity = velocity - normal * dot
			else
				tangential_velocity = velocity
			end

			local acceleration_magnitude = friction_magnitude / mass
			local delta_speed = acceleration_magnitude * dt

			if delta_speed * delta_speed < Vector3.length_squared(tangential_velocity) then
				local direction = -Vector3.normalize(tangential_velocity)

				velocity = velocity + direction * delta_speed
			else
				velocity.x, velocity.y = 0, 0
			end
		end
	end

	return velocity * dt
end
