﻿-- chunkname: @lua/components/avatar_damage_receiver_component.lua

require("foundation/lua/util/value_mixers")
require("foundation/lua/debug/plugin_component_aux")
require("lua/managers/entity_event_modifier_manager")
require("lua/components/base_damage_receiver_component")

AvatarDamageReceiverComponent = class("AvatarDamageReceiverComponent", "BaseDamageReceiverComponent")

local EXPLOSION_DAMAGE_MULTIPLIER = 1
local INVINCIBILITY_COOLDOWNS = {
	poke = 0.5,
	push = 0.5,
	spiketrap = 0.16666666666666666,
}

AvatarDamageReceiverComponent.init = function (self, creation_context)
	BaseDamageReceiverComponent.init(self, creation_context, "avatar_damage_receiver")
	DifficultyManager:register(self)

	self.damage_multiplier = DifficultyManager:avatar_damage_multiplier()
end

AvatarDamageReceiverComponent.destroy = function (self)
	BaseDamageReceiverComponent.destroy(self)
	DifficultyManager:unregister(self)
end

AvatarDamageReceiverComponent.difficulty_changed = function (self, difficulty)
	self.damage_multiplier = DifficultyManager:avatar_damage_multiplier()
end

AvatarDamageReceiverComponent.setup_master = function (self, unit, context, setup_info)
	BaseDamageReceiverComponent.setup_master(self, unit, context, setup_info)

	local state, settings = context.state, context.settings
	local hitpoints = settings.hitpoints

	if setup_info.hitpoint_ratio then
		hitpoints = setup_info.hitpoint_ratio * settings.hitpoints
	elseif setup_info and setup_info.hitpoints then
		hitpoints = setup_info.hitpoints
	end

	state.hitpoints_protected = CheatProtected(hitpoints)
	state.hitpoints = hitpoints
	state.max_hitpoints = settings.hitpoints
	state.invincibility_list = {}
end

AvatarDamageReceiverComponent.setup_slave = function (self, unit, context, setup_info)
	BaseDamageReceiverComponent.setup_slave(self, unit, context, setup_info)

	local state = context.state

	state.max_hitpoints = context.settings.hitpoints
	state.previous_hitpoint_ratio = state.hitpoints / state.max_hitpoints
end

AvatarDamageReceiverComponent.is_invincible_against = function (unit, hit_react, is_projectile)
	local state = EntityAux._state_master_raw(unit, "avatar_damage_receiver")

	if is_projectile and state.invincibility_list.projectile then
		return true
	end

	if INVINCIBILITY_COOLDOWNS[hit_react] == nil then
		return false
	end

	local last_hit_time = state.invincibility_list[hit_react] or 0

	if _G.GAME_TIME - last_hit_time < INVINCIBILITY_COOLDOWNS[hit_react] then
		return true
	end

	state.invincibility_list[hit_react] = _G.GAME_TIME

	return false
end

AvatarDamageReceiverComponent.apply_authorative_hit = function (self, unit, state, context, hit)
	local hit_settings = hit.settings

	if state.hitpoints <= 0 or hit.blocked and not hit_settings.damage_despite_blocking then
		return
	end

	local damage_amount = hit.damage_amount

	if hit_settings.heal_amount then
		damage_amount = -hit_settings.heal_amount

		if EntityAux.owned(unit) then
			self:trigger_rpc_event("flow_event", unit, "on_healed")
		end
	else
		damage_amount = self:calculate_damage(unit, state, context, damage_amount, hit_settings)
	end

	self:apply_damage(unit, state, context, damage_amount, hit)

	hit.is_deathblow = state.hitpoints <= 0
	hit.modifiers.is_deathblow = hit.is_deathblow
end

AvatarDamageReceiverComponent.calculate_damage = function (self, unit, state, context, damage, hit_settings)
	local state = context.state

	damage = damage * self.damage_multiplier

	local hit_react = hit_settings.hit_react

	if hit_react == "explosion" then
		damage = damage * EXPLOSION_DAMAGE_MULTIPLIER
	end

	damage = math.round(damage)

	return damage
end

AvatarDamageReceiverComponent.apply_damage = function (self, unit, state, context, damage, hit)
	if state.hitpoints == 0 then
		return 0
	end

	if state.debug_invincibility then
		return
	end

	local previous_hitpoints = state.hitpoints

	self:set_hitpoints(state, math.round(math.clamp(state.hitpoints - damage, 0, state.max_hitpoints)))

	state.dirty = true

	local effective_damage = previous_hitpoints - state.hitpoints

	if state.hitpoints <= 0 then
		state.alive = state.hitpoints > 0

		local settings = context.settings

		if settings.on_death_authorative then
			settings.on_death_authorative(unit, not hit.is_remote_hit, hit, self)
		end

		self:trigger_event("on_avatar_killed", unit, hit)
		self:handle_death_stats(unit, state, hit)
	end

	self:trigger_event("on_avatar_hurt", unit, effective_damage, hit)
end

AvatarDamageReceiverComponent.handle_death_stats = function (self, unit, state, hit)
	local player_info = PlayerManager:get_player_info_by_avatar(unit)
	local perp_type = hit.stat_creditor_go_id and "player" or "monster"

	self:trigger_event("on_avatar_killed_by_something", player_info.player_unit, perp_type, hit.settings_path, hit.ability_name)
end

AvatarDamageReceiverComponent.notify_death = function (self, unit, context, hit)
	local state = context.state
	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable_disabled")
	end

	state.death_time = _G.GAME_TIME

	self:trigger_event("on_death", unit)
	self:trigger_event("on_avatar_death", unit)
	Unit.flow_event(unit, "on_death")
	self:trigger_unit_event(unit, "unit_on_death")
end

AvatarDamageReceiverComponent.call_master_set_invincibility = function (self, unit, context, type, value)
	context.state.invincibility_list[type] = value
end
