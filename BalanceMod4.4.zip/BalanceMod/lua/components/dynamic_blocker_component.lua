﻿-- chunkname: @lua/components/dynamic_blocker_component.lua

require("foundation/lua/component/base_component")

DynamicBlockerComponent = class("DynamicBlockerComponent", "BaseComponent")

DynamicBlockerComponent.init = function (self, creation_context)
	self.nav_grid = creation_context.nav_grid

	BaseComponent.init(self, "dynamic_blocker", creation_context)
end

DynamicBlockerComponent.remove_slave = function (self, unit, context)
	self:set_blocked(unit, context, false)
end

DynamicBlockerComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.blocked = false

	if EntityAux.has_interface(unit, "i_damage_receiver") then
		self:set_blocked(unit, context, true)
	end

	return state
end

DynamicBlockerComponent.set_blocked = function (self, unit, context, blocked)
	local state = context.state

	if blocked then
		if not state.blocked then
			self.nav_grid:dynamic_block(unit)

			state.blocked = true
		end
	elseif state.blocked then
		self.nav_grid:dynamic_unblock(unit)

		state.blocked = false
	end
end

DynamicBlockerComponent.update = function (self, dt)
	return
end

DynamicBlockerComponent.call_slave_block = function (self, unit, context, data)
	self:set_blocked(unit, context, true)
end

DynamicBlockerComponent.call_slave_unblock = function (self, unit, context, data)
	self:set_blocked(unit, context, false)
end

DynamicBlockerComponent.call_slave_update_position = function (self, unit, context, data)
	self.nav_grid:dynamic_blocker_update(unit)

	context.state.blocked = true
end
