﻿-- chunkname: @lua/components/gold_gatherer_component.lua

require("foundation/lua/component/base_component")

GoldGathererComponent = class("GoldGathererComponent", "BaseComponent")

local FONT = "fonts/default"
local MATERIAL = FONT:match("[^/]*$")
local GRAVITY = 30

GoldGathererComponent.init = function (self, creation_context)
	BaseComponent.init(self, "gold_gatherer", creation_context)

	self.use_dirty_optimization = true
end

GoldGathererComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.gold = setup_info and setup_info.gold or 0
	state.gold_protected = CheatProtected(state.gold)
	state.dirty = true
	state.gold_pickup_hud_info = {}

	self:register_unit_events(unit, "unit_on_death")
end

GoldGathererComponent.set_gold = function (self, state, gold)
	if state.gold_protected:get() ~= state.gold then
		_G.I_AM_A_FUSKER = true
	end

	state.gold_protected:set(gold)

	state.gold = gold
end

GoldGathererComponent.remove_master = function (self, unit, context)
	self:unregister_unit_event(unit, "unit_on_death")
end

local GOLD_COUNTER_WAIT_TIME = 0.25
local GOLD_COUNTER_FADE_TIME = 0.5

GoldGathererComponent.update_masters = function (self, entities, dt)
	local gui_im = GUI:get_gui_im()
	local world_proxy = WorldManager:get_world_proxy("game_world")
	local viewport = world_proxy:viewport("game_viewport")
	local now = _G.GAME_TIME

	for unit, context in pairs(entities) do
		local state = context.state

		if #state.gold_pickup_hud_info == 0 then
			return
		end

		for _, hud_info in ipairs(state.gold_pickup_hud_info) do
			if now >= hud_info.begin_fade_time then
				hud_info.text_alpha = 1 - math.saturate((now - hud_info.begin_fade_time) / GOLD_COUNTER_FADE_TIME)
			end

			hud_info.done = hud_info.text_alpha <= 0

			if not hud_info.done then
				hud_info.vel.z = hud_info.vel.z - dt * GRAVITY
				hud_info.pos.x = hud_info.pos.x + dt * hud_info.vel.x
				hud_info.pos.y = hud_info.pos.y + dt * hud_info.vel.y
				hud_info.pos.z = hud_info.pos.z + dt * hud_info.vel.z

				local pos_world = Vector3Aux.unbox(hud_info.pos)
				local pos_pixels = viewport:world_to_screen(pos_world)

				if pos_pixels.z > 0 then
					pos_pixels.x = pos_pixels.x - 0.5 * hud_info.width
					pos_pixels.z = 1

					local color = Color(hud_info.text_alpha * 200, 255, 200, 0)

					Gui.text(gui_im, tostring(hud_info.amount), FONT, hud_info.font_size, MATERIAL, pos_pixels, color)
				end
			end
		end
	end
end

GoldGathererComponent.init_hud_info = function (self, hud_info, gold_to_add, unit)
	local multiplier = DifficultyManager:gold_picked_up_multiplier()

	hud_info.done = false
	hud_info.amount = gold_to_add
	hud_info.font_size = math.remap_range_clamped(gold_to_add / multiplier, 5, 100, 16, 28)
	hud_info.begin_fade_time = _G.GAME_TIME + GOLD_COUNTER_WAIT_TIME
	hud_info.picked_up_time = _G.GAME_TIME
	hud_info.text_alpha = 1
	hud_info.pos = Vector3Aux.box(hud_info.pos or {}, UnitAux.unit_center(unit))
	hud_info.vel = hud_info.vel or {
		x = 0,
		y = 0,
		z = 0,
	}
	hud_info.vel.x = 3 * math.random_uniform(-1, 1)
	hud_info.vel.y = 3 * math.random_uniform(-1, 1)
	hud_info.vel.z = 10 * math.random_uniform(1, 1.1)

	local text = tostring(hud_info.amount)
	local _, max, _, _ = Gui.text_extents(GUI:get_gui_im(), text, FONT, hud_info.font_size)

	hud_info.width = max.x
end

GoldGathererComponent.add_gold = function (self, unit, state, gold_to_add)
	state.last_pickup_time = _G.GAME_TIME

	self:set_gold(state, math.max(0, state.gold + gold_to_add))

	state.dirty = true

	local found = false

	for _, hud_info in ipairs(state.gold_pickup_hud_info) do
		if hud_info.done then
			self:init_hud_info(hud_info, gold_to_add, unit)

			found = true

			break
		end
	end

	if not found then
		local hud_info = {}

		self:init_hud_info(hud_info, gold_to_add, unit)

		state.gold_pickup_hud_info[#state.gold_pickup_hud_info + 1] = hud_info
	end
end

GoldGathererComponent.update = function (self, dt)
	Profiler.start(self.name)

	local master_entities = self.entity_manager:get_master_entities(self.name)
	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("write_game_objects")
	self:write_game_objects(master_entities, slave_entities)
	Profiler.stop()
	Profiler.stop()
end

GoldGathererComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "add" then
		local gold_to_add = data
		local multiplier = DifficultyManager:gold_picked_up_multiplier()

		gold_to_add = math.round(gold_to_add * multiplier)

		self:add_gold(unit, state, gold_to_add)
		self:trigger_rpc_event_to_host("rpc_gold_add", gold_to_add)
	elseif command_name == "set_amount" then
		self:set_gold(state, data)

		local diff = data - state.gold

		if diff > 0 then
			self:trigger_rpc_event_to_host("rpc_gold_add", diff)
		else
			self:trigger_rpc_event_to_host("rpc_gold_remove", diff)
		end

		state.dirty = true
	elseif command_name == "remove" then
		self:trigger_rpc_event_to_host("rpc_gold_remove", data)
		self:set_gold(state, math.max(0, state.gold - data))

		state.dirty = true
	end
end

GoldGathererComponent.unit_on_death = function (self, unit)
	local player_info = PlayerManager:get_player_info_by_avatar(unit)
	local player_go_id = player_info.go_id
	local parent_go_id = EntityAux.go_id(unit)
	local percent_to_remove = 0.2
	local total_gold_amount = EntityAux.state_master(unit, self.name).gold
	local amount_removed = math.floor(total_gold_amount * percent_to_remove)

	if amount_removed > 0 then
		self:queue_command(unit, self.name, "remove", amount_removed)

		local motion_state = EntityAux.state_master(unit, "motion")
		local last_ground_position = MotionState.get_last_ground_position(motion_state.motion_state)
		local rotation = Unit.world_rotation(unit, 0)
		local entity = self.entity_spawner:spawn_entity("blood_money", last_ground_position, rotation, parent_go_id, {
			gold = amount_removed,
			player_go_id = player_go_id,
		})

		NetworkUnitSynchronizer:add(entity)
	end
end

GoldGathererComponent.setup_console_plugin = function (self)
	local plugin = {
		gold = function (argument_array, command_string)
			if argument_array[2] == "add" then
				local amount, target = tonumber(argument_array[3]), argument_array[4]

				if not amount then
					return {
						error = true,
						message = sprintf("Invalid amount given! (amount: %s)", tostring(argument_array[3])),
					}
				end

				local msg = {
					message = sprintf("Added %d of gold for %s.", amount, PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "add", amount, target) or msg

				return msg
			elseif argument_array[2] == "remove" then
				local amount, target = tonumber(argument_array[3]), argument_array[4]

				if not amount then
					return {
						error = true,
						message = sprintf("Invalid amount given! (amount: %s)", tostring(argument_array[3])),
					}
				end

				local msg = {
					message = sprintf("Removed %d of gold for %s.", amount, PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "remove", amount, target) or msg

				return msg
			elseif argument_array[2] == "set_amount" then
				local amount, target = tonumber(argument_array[3]), argument_array[4]

				if not amount then
					return {
						error = true,
						message = sprintf("Invalid amount given! (amount: %s)", tostring(argument_array[3])),
					}
				end

				local msg = {
					message = sprintf("Set amount of gold to %d for %s.", amount, PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "set_amount", amount, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		gold = {
			"add",
			"remove",
			"set_amount",
		},
	}
	local docs = {
		gold = {
			text = "Gold gatherer component. Sets the amount of gold for the users.",
			add = {
				text = "Adds gold.",
				usage = "add <amount> [go_id|all]",
			},
			remove = {
				text = "Removes gold.",
				usage = "remove <amount> [go_id|all]",
			},
			set_amount = {
				text = "Sets the amount of gold.",
				usage = "set_amount <amount> [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end
