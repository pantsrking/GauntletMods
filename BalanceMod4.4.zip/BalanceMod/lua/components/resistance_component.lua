﻿-- chunkname: @lua/components/resistance_component.lua

require("foundation/lua/component/base_component")

ResistanceComponent = class("ResistanceComponent", "BaseComponent")
ResistanceLevels = {
	absorb = -1,
	immune = 0,
	resist = 0.5,
	weak = 1.5,
}

local bit = require("bit")
local lshift = bit.lshift
local rshift = bit.rshift
local bor = bit.bor
local band = bit.band
local RESISTANCE_MASK = table.make_bimap({
	"slowed",
	"chilled",
	"lightning",
	"fire",
	"burning",
	"frozen",
	"poisoned",
	"pierce",
	"weak_shot",
	"barrel_explosion",
	"damage",
	"all",
})
local RESISTANCE_BITMASKS = {}

for i, name in ipairs(RESISTANCE_MASK) do
	RESISTANCE_BITMASKS[name] = lshift(1, i - 1)
end

local LEVELS = table.make_bimap({
	"absorb",
	"immune",
	"resist",
	"weak",
})

ResistanceComponent.init = function (self, creation_context)
	BaseComponent.init(self, "resistance", creation_context, true)

	self.use_dirty_optimization = true

	self:register_interfaces("i_hit_receiver")
end

ResistanceComponent.is_set = function (resistance_mask, resistance_id)
	local bit_mask = RESISTANCE_BITMASKS[resistance_id]

	if bit_mask == nil then
		return false
	end

	return band(resistance_mask, bit_mask) == bit_mask
end

ResistanceComponent.get_resistance_level = function (self, state, resistance_id)
	if ResistanceComponent.is_set(state.resistance_mask, resistance_id) then
		local i = RESISTANCE_MASK[resistance_id]
		local index = (i - 1) * 2
		local level_mask_shifted = rshift(state.resistance_level_mask, index)
		local level_index = band(level_mask_shifted, 3) + 1

		return LEVELS[level_index]
	end

	return nil
end

ResistanceComponent.is_immune = function (unit)
	local self = EntityAux.get_component("resistance")

	if not EntityAux.has_component(unit, self.name) then
		return
	end

	local state = EntityAux.state(unit, self.name)
	local settings = LuaSettingsManager:get_settings_by_unit(unit)
	local resistance = self:get_resistance(state, "all", settings)

	if resistance then
		local resistance_levels = settings.resistance_levels or ResistanceLevels
		local level = resistance_levels[resistance]

		return level <= LEVELS.immune
	end

	return false
end

ResistanceComponent.get_resistance = function (self, state, name, settings)
	if settings.resistance_exceptions and settings.resistance_exceptions[name] then
		return nil
	end

	return self:get_resistance_level(state, name)
end

ResistanceComponent.check_hit = function (self, unit, hit_info)
	local hit_settings = hit_info.settings

	if hit_info.ignore_resistances then
		return
	end

	local state = EntityAux.state(unit, "resistance")
	local settings = LuaSettingsManager:get_settings_by_unit(unit)
	local damage_resistance = self:get_resistance(state, "damage", settings)

	if damage_resistance then
		local resistance_levels = settings.resistance_levels or ResistanceLevels
		local damage_amount = hit_info.damage_amount or hit_info.settings.damage_amount

		hit_info.damage_amount = damage_amount * resistance_levels[damage_resistance]
		hit_info.allow_instakill = resistance_levels[damage_resistance] > 0

		return
	end

	local resistance = self:get_resistance(state, "all", settings)

	if resistance then
		hit_info[resistance] = true
	end

	local damage_type = hit_settings.damage_type

	if damage_type then
		if settings.resistance_exceptions and settings.resistance_exceptions[damage_type] then
			if resistance then
				hit_info[resistance] = false
			end
		else
			local resistance = self:get_resistance(state, damage_type, settings)

			if resistance then
				hit_info[resistance] = true
			end
		end
	end

	local status_effects = hit_settings.status_effects

	if status_effects then
		for name, value in pairs(status_effects) do
			local resistance = self:get_resistance(state, "all", settings) or self:get_resistance(state, name, settings)

			if resistance then
				local resistance_levels = settings.resistance_levels or ResistanceLevels
				local level = resistance_levels[resistance]

				if level <= 0 then
					hit_info[name] = false
				end
			end
		end
	end
end

ResistanceComponent.set_resistance_mask = function (self, unit, context)
	local state = context.state

	self:verify_resistance_masks(state.resistances)

	state.resistance_mask = 0
	state.resistance_level_mask = 0
	state.dirty = true

	for i, id in ipairs(RESISTANCE_MASK) do
		local resistance = state.resistances[id]

		if state.resistances[id] then
			local bit_mask = RESISTANCE_BITMASKS[id]

			state.resistance_mask = bor(state.resistance_mask, bit_mask)

			local index = (i - 1) * 2

			bit_mask = lshift(LEVELS[resistance] - 1, index)
			state.resistance_level_mask = bor(state.resistance_level_mask, bit_mask)
		end
	end
end

ResistanceComponent.verify_resistance_masks = function (self, resistances)
	for id, level in pairs(resistances) do
		-- Nothing
	end
end

ResistanceComponent.setup_master = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.resistances = settings.resistances and table.clone(settings.resistances) or {}

	self:set_resistance_mask(unit, context)
end

ResistanceComponent.update = function (self, dt)
	return
end

ResistanceComponent.call_master_hit = function (self, unit, context, hit)
	if not hit.is_remote_hit then
		self:check_hit(unit, hit)
	end

	local damage_amount = hit.damage_amount or hit.settings.damage_amount

	if damage_amount then
		local resistance_levels = context.settings.resistance_levels or ResistanceLevels

		for resistance_key, value in pairs(resistance_levels) do
			if hit[resistance_key] then
				hit.damage_amount = damage_amount * value

				break
			end
		end
	end
end

ResistanceComponent.call_prediction_hit = function (self, unit, context, hit)
	self:call_master_hit(unit, context, hit)
end

ResistanceComponent.call_master_set_resistance = function (self, unit, context, data)
	local state = context.state

	state.resistances[data.resistance_id] = data.type

	self:set_resistance_mask(unit, context)
	self.replicator:write_fields(context)

	local slave_state = EntityAux._state_raw(unit, self.name)

	slave_state.resistance_mask = state.resistance_mask
	slave_state.resistance_level_mask = state.resistance_level_mask
end
