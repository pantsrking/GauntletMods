﻿-- chunkname: @lua/components/blocker_component.lua

require("foundation/lua/component/base_component")

BlockerComponent = class("BlockerComponent", "BaseComponent")

BlockerComponent.init = function (self, creation_context)
	BaseComponent.init(self, "blocker", creation_context)
end

BlockerComponent.is_blocking = function (self, unit, hit_info)
	if hit_info.settings.can_be_blocked == false then
		return
	end

	local state = EntityAux.state(unit, "blocker")

	if state.blocking and not hit_info.is_status_effect_hit then
		local forward = Quaternion.forward(Unit.local_rotation(unit, 0))
		local to_attacker = -Vector3Aux.unbox(hit_info.direction)

		to_attacker.z = 0

		local flat_direction = Vector3.normalize(to_attacker)
		local blocking = Vector3.dot(flat_direction, forward) > state.min_dot

		hit_info.modifiers.blocked = blocking

		if hit_info.settings.can_be_reflected ~= false and blocking and state.reflective_block then
			local settings = LuaSettingsManager:get_settings_by_unit(unit)

			if settings.avatar_type == "valkyrie" then
				local is_projectile = AbilityEventAux.is_projectile_by_type(hit_info.settings.type)

				if is_projectile then
					PerkManager:increment(unit, "eye_for_an_eye")
				end
			end

			hit_info.modifiers.reflected = true
		end

		if blocking and not hit_info.settings.ignore_block then
			hit_info.stopping_power = -1
		end

		return blocking
	end

	return false
end

BlockerComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.blocking = context.settings.blocker_start_value == true
	state.reflective_block = context.settings.reflective_block
	state.block_health = context.settings.block_health or 3
end

BlockerComponent.setup_slave = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.reflective_block = settings.reflective_block

	local cb = callback(self, "is_blocking")

	EntityEventModifierManager:register_modifier(unit, "hit", self.name, cb)
	self:reload_slave(unit, context)
end

BlockerComponent.reload_slave = function (self, unit, context)
	local state, settings = context.state, context.settings

	state.blocking_angle = settings.blocking_angle or 90
	state.min_dot = math.cos(math.rad(state.blocking_angle))
end

BlockerComponent.remove_slave = function (self, unit, context)
	EntityEventModifierManager:unregister_modifier(unit, "hit", self.name)
end

BlockerComponent.update = function (self, dt)
	return
end

BlockerComponent.call_master_block_damage = function (self, unit, context, block_damage)
	local state = context.state

	state.block_health = math.clamp(state.block_health - block_damage, 0, 255)

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).block_health = state.block_health
end

BlockerComponent.call_master_set_blocking = function (self, unit, context, blocking)
	local state = context.state

	if blocking ~= state.blocking then
		state.blocking = blocking

		self.replicator:write_fields(context)

		EntityAux._state_raw(unit, self.name).blocking = state.blocking
	end
end
