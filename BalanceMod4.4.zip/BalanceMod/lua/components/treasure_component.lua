﻿-- chunkname: @lua/components/treasure_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/player/player_manager")
require("lua/managers/entity_event_modifier_manager")

TreasureComponent = class("TreasureComponent", "BaseComponent")
TreasureComponent.TREASURES = {
	"crown",
}

local DROP_ENABLE_INTERACTABLE_WAIT = 1
local DESPAWN_TIME = 10
local DROP_FLY_SPEED = 10

TreasureComponent.init = function (self, creation_context)
	BaseComponent.init(self, "treasure", creation_context)
	self:register_dependencies("interactable", "interactor")
	self:register_events("on_entity_unregistering", "on_avatar_exiting_floor")

	self.counts = {
		crown = 0,
	}
end

TreasureComponent.destroy = function (self)
	BaseComponent.destroy(self)
end

TreasureComponent.pickup_master = function (self, treasure_unit, treasure_state, carrier)
	EntityAux.queue_command_master(treasure_unit, "physics", "disable", "treasure_carried")

	treasure_state.carrier = carrier

	local cb = callback(self, "carrier_knockbacked", treasure_unit)

	EntityEventModifierManager:register_modifier(carrier, "knockbacked", "treasure", cb)
	self.event_delegate:register_unit(carrier, treasure_state, "unit_on_death")

	local player_info = PlayerManager:get_player_info_by_avatar(carrier)

	if player_info then
		local owner = player_info.peer_id

		if owner == Network.peer_id() then
			self.network_router:trigger_to_me("rpc_treasure_picked_up", player_info.player_unit, treasure_unit)
		else
			self:trigger_rpc_event_to(owner, "rpc_treasure_picked_up", player_info.player_unit, treasure_unit)
		end
	end

	treasure_state.countdown_started = false
end

local function random_neg1_to_1()
	return math.random() * 2 - 1
end

TreasureComponent.drop_master = function (self, treasure_unit, treasure_state)
	local carrier = treasure_state.carrier

	if not carrier then
		return
	end

	EntityAux.queue_command_master(treasure_unit, "physics", "enable", "treasure_carried")
	EntityEventModifierManager:unregister_modifier(carrier, "knockbacked", "treasure")
	self.event_delegate:unregister_unit(carrier, treasure_state, "unit_on_death")
	Game:delay_action(DROP_ENABLE_INTERACTABLE_WAIT, function ()
		if Unit.alive(treasure_unit) then
			self:queue_command_master(treasure_unit, "interactable", "set_enabled", true)
		end
	end)

	local player_info = PlayerManager:get_player_info_by_avatar(carrier)

	if player_info then
		local owner = player_info.peer_id

		if owner == Network.peer_id() then
			self.network_router:trigger_to_me("rpc_treasure_dropped", player_info.player_unit, treasure_unit)
		else
			self:trigger_rpc_event_to(owner, "rpc_treasure_dropped", player_info.player_unit, treasure_unit)
		end
	end

	treasure_state.carrier = nil
	treasure_state.dropped_time = _G.GAME_TIME
end

TreasureComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.dropped_time = _G.GAME_TIME

	state.unit_on_death = function (carrier)
		self:queue_command_master(unit, self.name, "set", nil)
	end

	if setup_info and setup_info.carrier then
		self:queue_command_master(unit, "interactable", "set_enabled", false)
		self:pickup_master(unit, state, setup_info.carrier)
	else
		EntityAux.queue_command_master(unit, "physics", "enable", "treasure_carried")
	end
end

TreasureComponent.setup_slave = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings
	local treasure_id = settings.treasure.id

	self.counts[treasure_id] = self.counts[treasure_id] + 1
end

TreasureComponent.remove_slave = function (self, unit, context)
	local state, settings = context.state, context.settings
	local treasure_id = settings.treasure.id

	self.counts[treasure_id] = self.counts[treasure_id] - 1
end

TreasureComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.carrier == nil then
			if _G.GAME_TIME - state.dropped_time > DESPAWN_TIME then
				Unit.flow_event(unit, "on_despawned")
				self:trigger_rpc_event_to_others("flow_event", unit, "on_despawned")
				self.entity_spawner:despawn_entity(unit)
			elseif not state.countdown_started and _G.GAME_TIME - state.dropped_time > DESPAWN_TIME - 3 then
				state.countdown_started = true

				Unit.flow_event(unit, "on_countdown")
				self:trigger_rpc_event_to_others("flow_event", unit, "on_countdown")
			end
		end
	end
end

TreasureComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.carrier ~= state.previous_carrier then
			if state.previous_carrier then
				self:unlink_with_force(unit, state.previous_carrier)
			end

			if state.carrier then
				self:link_to_carrier(unit, context, state.carrier)
				self:trigger_event("treasure_picked_up", state.carrier, unit)
			end

			state.previous_carrier = state.carrier
		end
	end
end

TreasureComponent.link_to_carrier = function (self, treasure_unit, context, carrier_unit)
	local state, settings = context.state, context.settings
	local world = self.world_proxy:get_world()

	Unit.destroy_actor(treasure_unit, "dynamic")

	local carrier_settings = LuaSettingsManager:get_settings_by_unit(carrier_unit)
	local joint_name = carrier_settings.treasure_joints and carrier_settings.treasure_joints[settings.treasure.id]
	local node_index = Unit.node(carrier_unit, joint_name)

	World.link_unit(world, treasure_unit, 0, carrier_unit, node_index)
	Unit.set_local_position(treasure_unit, 0, Vector3(0, 0.1, 0))

	local joint_rotation_offset = carrier_settings.treasure_rotation_offset and carrier_settings.treasure_rotation_offset[settings.treasure.id] or {
		x = 0,
		y = 0,
		z = 0,
	}
	local x = math.rad(joint_rotation_offset.x)
	local y = math.rad(joint_rotation_offset.y) - math.tau / 4
	local z = math.rad(joint_rotation_offset.z)

	Unit.set_local_rotation(treasure_unit, 0, Quaternion.from_yaw_pitch_roll(x, y, z))

	if Unit.has_visibility_group(carrier_unit, "grp_crown") then
		Unit.set_visibility(carrier_unit, "grp_crown", true)
		Unit.set_visibility(treasure_unit, "grp_root", false)
	end
end

TreasureComponent.unlink_with_force = function (self, treasure_unit, carrier)
	local world = self.world_proxy:get_world()

	World.unlink_unit(world, treasure_unit)

	if Unit.has_visibility_group(carrier, "grp_crown") then
		Unit.set_visibility(carrier, "grp_crown", false)
		Unit.set_visibility(treasure_unit, "grp_root", true)
	end

	local inherit_velocity = 0

	Unit.create_actor(treasure_unit, "dynamic", inherit_velocity)

	local actor = Unit.actor(treasure_unit, 0)
	local vel_dir = -UnitAux.unit_forward(carrier)

	vel_dir.z = 1

	Actor.add_velocity(actor, vel_dir * DROP_FLY_SPEED)
	Actor.add_angular_velocity(actor, Vector3(random_neg1_to_1(), random_neg1_to_1(), random_neg1_to_1()) * 10)
	Unit.flow_event(treasure_unit, "on_dropped")
end

TreasureComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set" then
		if data then
			local player_info = PlayerManager:get_player_info_by_avatar(data)

			self:pickup_master(unit, state, data)
		else
			self:drop_master(unit, state)
		end
	end
end

TreasureComponent.on_avatar_exiting_floor = function (self, avatar_unit, player_go_id)
	for treasure_unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if state.carrier == avatar_unit then
			EntityEventModifierManager:unregister_modifier(state.carrier, "knockbacked", "treasure")
			self.event_delegate:unregister_unit(state.carrier, state, "unit_on_death")

			state.carrier = nil

			self.entity_spawner:despawn_entity(treasure_unit)

			break
		end
	end

	for treasure_unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state

		if state.carrier == avatar_unit then
			state.carrier = nil
			state.previous_carrier = nil

			break
		end
	end
end

TreasureComponent.carrier_knockbacked = function (self, treasure_unit, carrier, hit)
	if not hit.ally_hit then
		self:queue_command_master(treasure_unit, self.name, "set", nil)
	end
end

TreasureComponent.on_entity_unregistering = function (self, unit)
	self:drop_treasure_for_carrier(unit)
end

TreasureComponent.drop_treasure_for_carrier = function (self, carrier_unit)
	for treasure_unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if state.carrier == carrier_unit then
			self:drop_master(treasure_unit, state)

			break
		end
	end

	for treasure_unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state

		if state.carrier == carrier_unit then
			self:unlink_with_force(treasure_unit, carrier_unit)

			state.carrier = nil
			state.previous_carrier = nil

			break
		end
	end
end

TreasureComponent.has_any_of = function (self, treasure_id)
	return self.counts[treasure_id] > 0
end

TreasureComponent.setup_console_library = function (self)
	return {
		parts = {
			set = {
				usage = "set <treasure_go_id> <owner_go_id>",
				fun = function (treasure_go_id, owner_go_id)
					local num_treasure_go_id = tonumber(treasure_go_id)
					local num_owner_go_id = tonumber(owner_go_id)

					if not num_treasure_go_id then
						return sprintf("Invalid treasure_go_id %t", treasure_go_id)
					end

					local treasure_unit = self.entity_storage:unit(num_treasure_go_id)
					local owner_unit = num_owner_go_id and self.entity_storage:unit(num_owner_go_id)

					if not treasure_unit then
						return sprintf("Unknown treasure entity with go id %d", num_treasure_go_id)
					end

					if not EntityAux.has_component(treasure_unit, self.name) then
						return sprintf("%t doesn't have a %s component", treasure_unit, self.name)
					end

					self:queue_command_master(treasure_unit, self.name, "set", owner_unit)

					return sprintf("%t is now the owner of %t", owner_unit, treasure_unit)
				end,
			},
			drop = {
				fun = function ()
					for treasure_unit, context in self.entity_manager:all_masters_iterator(self.name) do
						local state = context.state

						if state.carrier then
							self:drop_master(treasure_unit, state)
						end
					end
				end,
			},
		},
	}
end
