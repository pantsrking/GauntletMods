﻿-- chunkname: @lua/components/trap_trigger_component.lua

require("foundation/lua/component/base_component")

TrapTriggerComponent = class("TrapTriggerComponent", "BaseComponent")

TrapTriggerComponent.init = function (self, creation_context)
	BaseComponent.init(self, "trap_trigger", creation_context, true)
	self:register_dependencies("i_trap")
	self:register_events("on_entity_unregistering")
	self.flow_router:register(self, "link_traps", "trap_trigger_enter", "trap_trigger_exit")

	self.unit_to_trap_triggers = {}
end

TrapTriggerComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.touching_units = {}
	state.active = false
end

TrapTriggerComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.groups = {}
	state.touching_units = {}
	state.previous_active = state.active
end

TrapTriggerComponent.remove_slave = function (self, unit, context)
	for touching_unit, trap_triggers in pairs(self.unit_to_trap_triggers) do
		if trap_triggers[unit] then
			EntityAux.call(unit, self.name, "trigger_exit", touching_unit)
		end
	end
end

TrapTriggerComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local slave_entities = entity_manager:get_slave_entities(self.name)
	local prediction_entities = self.entity_manager:get_prediction_entities(self.name)

	Profiler.start("update_predictors")
	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

TrapTriggerComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local p_state = context.prediction_state

		if p_state.active ~= nil then
			if _G.GAME_TIME >= p_state.release_override_active_time then
				p_state.active = nil
			else
				state.active = p_state.active
			end
		end
	end
end

TrapTriggerComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings
		local result
		local dirty = state.previous_active ~= state.active

		state.previous_active = state.active

		if dirty then
			if state.active then
				result = {
					settings.trigger_activate(unit, context, self),
				}
			else
				result = {
					settings.trigger_deactivate(unit, context, self),
				}
			end
		end

		if result then
			for i = 1, #result, 2 do
				local group_name = result[i]
				local order = result[i + 1]
				local group = state.groups[group_name]

				if group then
					for j, trap_unit in ipairs(group) do
						if EntityAux.owned(trap_unit) then
							self:queue_command_master_interface(trap_unit, "i_trap", order, unit)
						else
							self:queue_command_predictor_interface(trap_unit, "i_trap", order, unit)
						end
					end
				end
			end
		end
	end
end

TrapTriggerComponent.set_field = function (self, unit, context, field_name, value)
	context.state[field_name] = value

	if EntityAux.has_component_master(unit, self.name) then
		self.replicator:write_fields(context)

		EntityAux._state_raw(unit, self.name)[field_name] = value
	end
end

TrapTriggerComponent.handle_trigger_enter = function (self, unit, context, touching_unit)
	if not Unit.alive(touching_unit) then
		return
	end

	local state = context.state
	local touching_units = state.touching_units

	touching_units[touching_unit] = true

	local trap_triggers = self.unit_to_trap_triggers[touching_unit]

	if trap_triggers == nil then
		trap_triggers = {}
		self.unit_to_trap_triggers[touching_unit] = trap_triggers

		self:register_unit_events(touching_unit, "unit_on_death")
	end

	trap_triggers[unit] = true

	local nr_touching_units = table.map_size(touching_units)

	if nr_touching_units == 1 then
		context.settings.trigger_step_on(unit, context, self)
		self:set_field(unit, context, "active", true)
	end
end

TrapTriggerComponent.handle_trigger_exit = function (self, unit, context, touching_unit)
	if not Unit.alive(touching_unit) then
		return
	end

	local state = context.state
	local touching_units = state.touching_units

	touching_units[touching_unit] = nil

	local trap_triggers = self.unit_to_trap_triggers[touching_unit]

	trap_triggers[unit] = nil

	if table.map_size(trap_triggers) == 0 then
		self.unit_to_trap_triggers[touching_unit] = nil

		self:unregister_unit_event(touching_unit, "unit_on_death")
	end

	local nr_touching_units = table.map_size(touching_units)

	if nr_touching_units == 0 then
		context.settings.trigger_step_off(unit, context, self)
		self:set_field(unit, context, "active", false)
	end
end

TrapTriggerComponent.call_master_trigger_enter = function (self, unit, context, data)
	self:handle_trigger_enter(unit, context, data)
end

TrapTriggerComponent.call_master_trigger_exit = function (self, unit, context, data)
	self:handle_trigger_exit(unit, context, data)
end

TrapTriggerComponent.call_master_activate = function (self, unit, context, data)
	local settings = context.settings

	settings.trigger_step_on(unit, context, self)
	self:set_field(unit, context, "active", true)
end

TrapTriggerComponent.call_master_deactivate = function (self, unit, context, data)
	local settings = context.settings

	settings.trigger_step_off(unit, context, self)
	self:set_field(unit, context, "active", false)
end

TrapTriggerComponent.call_prediction_trigger_enter = function (self, unit, context, data)
	local state = context.state
	local p_state = context.prediction_state
	local was_active = state.active

	self:handle_trigger_enter(unit, context, data)

	if was_active ~= state.active then
		p_state.release_override_active_time = _G.GAME_TIME + Network.ping(EntityAux.owner(unit)) * 2 + 0.2
		p_state.active = state.active
	end
end

TrapTriggerComponent.call_prediction_trigger_exit = function (self, unit, context, data)
	local state = context.state
	local p_state = context.prediction_state
	local was_active = state.active

	self:handle_trigger_exit(unit, context, data)

	if was_active ~= state.active then
		p_state.release_override_active_time = _G.GAME_TIME + Network.ping(EntityAux.owner(unit)) * 2 + 0.2
		p_state.active = state.active
	end
end

TrapTriggerComponent.call_slave_link_traps = function (self, unit, context, data)
	local state = context.state
	local flow_params = data
	local group_name = flow_params.group_name
	local group = state.groups[group_name] or {}

	for i = 1, 8 do
		local child = flow_params["unit" .. tostring(i)]

		if not child then
			break
		end

		group[#group + 1] = child
	end

	state.groups[group_name] = group
end

TrapTriggerComponent.unit_on_death = function (self, unit)
	local trap_triggers = self.unit_to_trap_triggers[unit]

	for trap_trigger, _ in pairs(trap_triggers) do
		EntityAux.call(trap_trigger, self.name, "trigger_exit", unit)
	end

	self.unit_to_trap_triggers[unit] = nil
end

TrapTriggerComponent.on_entity_unregistering = function (self, unit)
	if self.unit_to_trap_triggers[unit] then
		self:unit_on_death(unit)

		self.unit_to_trap_triggers[unit] = nil
	end
end

TrapTriggerComponent.link_traps = function (self, params)
	local trap_trigger = params.trap_trigger

	if Unit.alive(trap_trigger) then
		EntityAux.call_slave(trap_trigger, self.name, "link_traps", params)
	end
end

TrapTriggerComponent.trap_trigger_enter = function (self, params)
	local unit = params.unit

	if not EntityAux.is_entity_initialized(unit) then
		return
	end

	EntityAux.call(unit, self.name, "trigger_enter", params.touching_unit)
end

TrapTriggerComponent.trap_trigger_exit = function (self, params)
	local unit = params.unit

	if not EntityAux.is_entity_initialized(unit) then
		return
	end

	EntityAux.call(unit, self.name, "trigger_exit", params.touching_unit)
end
