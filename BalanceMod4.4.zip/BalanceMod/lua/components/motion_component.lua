﻿-- chunkname: @lua/components/motion_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/debug/plugin_component_aux")
require("foundation/lua/network/network_unit_synchronizer")
require("foundation/lua/util/value_mixers")
require("lua/components/movement_constraints")
require("lua/components/motion_prediction")
require("lua/settings/environment_settings")

local Profiler_start = Profiler.start
local Profiler_stop = Profiler.stop
local math_is_zero = math.is_zero
local Vector3Aux_box = Vector3Aux.box
local SIMPLE_MOVER_RADIUS = 0.5
local SIMPLE_MOVER_MAX_RADIUS = 2.5
local STATES = {
	advanced_force_based = 5,
	advanced_kinematic = 1,
	custom_translation = 6,
	dynamic = 2,
	force_based = 4,
	kinematic = 0,
	kinematic_nogravity = 3,
}
local CONSTRAINTS = {
	constrained_by_camera = 2,
	constrained_by_ground = 0,
	constrained_by_mover = 4,
	constrained_by_navgrid = 1,
	constrained_by_simple_mover = 3,
}

MotionComponent = class("MotionComponent", "BaseComponent")

MotionComponent.init = function (self, creation_context)
	BaseComponent.init(self, "motion", creation_context, true)
	self:register_rpc_events("rpc_teleport", "rpc_teleport_slaves")
	self:register_events("on_entity_unregistering")

	self.nav_grid = creation_context.nav_grid
	self.physics_world = World.physics_world(self.world_proxy:get_world())
	self.simple_mover_world = SimpleMoverWorld(SIMPLE_MOVER_MAX_RADIUS)
	self.motion_component_aux = MotionComponentAux()
end

MotionComponent.on_script_reload = function (self)
	BaseComponent.on_script_reload(self)
end

MotionComponent.migrated_away = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_away(self, unit, slave_context, master_context)

	if master_context.state.constrained_by_mover then
		Unit.set_mover(unit, nil)

		master_context.state.constrained_by_mover = false
	end

	local constrained_by_simple_mover = master_context.state.constrained_by_simple_mover

	slave_context.state.previous_constrained_by_simple_mover = constrained_by_simple_mover
	slave_context.state.constrained_by_simple_mover = constrained_by_simple_mover

	MotionComponentAux.remove_unit(self.motion_component_aux, unit)
end

local function _add_to_motion_aux(motion_aux, unit, state)
	state.motion_state = MotionComponentAux.add_unit(motion_aux, unit, state.check_last_ground_position == true)
end

MotionComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context)

	local slave_state = slave_context.state
	local dirty = slave_state.constrained_by_simple_mover ~= slave_state.previous_constrained_by_simple_mover

	if dirty then
		local constrained = slave_state.constrained_by_simple_mover

		if constrained then
			local radius = slave_context.settings.simple_mover_radius or SIMPLE_MOVER_RADIUS

			if radius > SIMPLE_MOVER_MAX_RADIUS then
				radius = SIMPLE_MOVER_MAX_RADIUS
			end

			SimpleMoverWorld.add_unit(self.simple_mover_world, unit, radius)
		else
			SimpleMoverWorld.remove_unit(self.simple_mover_world, unit)
		end

		slave_state.previous_constrained_by_simple_mover = constrained
		slave_state.constrained_by_simple_mover = constrained
	end

	MotionState.set_game_object_id(master_context.state.motion_state, EntityAux.go_id(unit))
end

local function _get_position(state)
	return Vector3(state.positionx, state.positiony, state.positionz)
end

MotionComponent.raycast = function (self, position, direction, length)
	return PhysicsWorld.immediate_raycast(self.physics_world, position, direction, length, "closest", "types", "statics", "collision_filter", "floor")
end

MotionComponent.MAX_STEP_UP = 1.5
MotionComponent.MAX_STEP_DOWN = 1.5

MotionComponent.raycast_ground = function (self, unit, position, context)
	local state = context.state
	local max_step_up = state.max_step_up or MotionComponent.MAX_STEP_UP
	local max_step_down = state.max_step_down or MotionComponent.MAX_STEP_DOWN
	local ray_position = position + Vector3.up() * max_step_up
	local ray_direction = Vector3.down()
	local ray_length = max_step_up + max_step_down

	return self:raycast(ray_position, ray_direction, ray_length)
end

MotionComponent.raycast_last_ground_position = function (self, unit, new_position, context)
	local state = context.state
	local any_hit, position, _, normal, _ = self:raycast_ground(unit, new_position, context)

	if any_hit then
		Vector3Aux.box(state.last_normal, normal)
		Vector3Aux.box(state.last_ground_position, position)

		state.down_ray_hit = true
	else
		Vector3Aux.box(state.last_normal, Vector3.up())

		state.down_ray_hit = false
	end
end

MotionComponent.reload_master = function (self, unit, context)
	context.num_commands = 0

	self:read_settings(unit, context)
end

MotionComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

MotionComponent.read_settings = function (self, unit, context)
	local settings = context.settings
	local motion_info = context.settings.motion_info

	if motion_info then
		local state = context.state

		state.motion_info.dynamic_friction = motion_info.dynamic_friction
		state.mass = motion_info.mass or 1
		state.max_speed = motion_info.movespeed or 1
		state.check_last_ground_position = motion_info.check_last_ground_position
	end
end

MotionComponent.reload_slave = function (self, unit, context)
	context.num_commands = 0
end

MotionComponent.setup_master = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.velocity = Vector3Aux.box({}, Vector3.zero())
	state.last_ground_position = Vector3Aux.box({}, Unit.local_position(unit, 0))
	state.disabled_refmix = RefMixer()
	state.disabled = false
	state.constrained_by_simple_mover_count = 0
	state.motion_info = settings.motion_info or {}
	state.max_speed = state.motion_info.movespeed or 1
	state.mass = state.motion_info.mass or 1
	state.default_motion_state = state.motion_info.default_motion_state or "kinematic"

	self:read_settings(unit, context)

	state.check_last_ground_position = state.motion_info.check_last_ground_position

	if state.check_last_ground_position then
		state.last_normal = Vector3Aux.box({}, Vector3.up())
		state.max_step_up = settings.max_step_up or MotionComponent.MAX_STEP_UP
		state.max_step_down = settings.max_step_down or MotionComponent.MAX_STEP_DOWN

		self:raycast_last_ground_position(unit, Unit.local_position(unit, 0), context)
	end

	Unit.set_mover(unit, nil)
	_add_to_motion_aux(self.motion_component_aux, unit, state)
	MotionState.set_max_speed(state.motion_state, state.max_speed)

	if state.motion_info.constrained_by_ground ~= false then
		self:command_master(unit, context, "constrain_to_ground", true)
	end

	self:command_master(unit, context, "change_state", state.default_motion_state)
end

MotionComponent.setup_slave = function (self, unit, context)
	local state, settings = context.state, context.settings

	state.destroyed = false
	state.velocity = Vector3Aux.box_copy({}, Vector3.zero())

	local position = _get_position(state)

	if not settings.animation_driven_movement then
		state.extrapolated_position = Vector3Aux.box_copy({}, position)
	end

	state.previous_position = Vector3Aux.box_copy({}, position)
	state.motion_info = settings.motion_info or {}
	state.previous_constrained_by_simple_mover = false

	Unit.set_mover(unit, nil)
	Unit.teleport_local_position(unit, 0, position)

	if EntityAux.has_component_master(unit, self.name) then
		MotionState.set_game_object_id(EntityAux._state_master_raw(unit, self.name).motion_state, EntityAux.go_id(unit))
	end
end

MotionComponent.pause = function (self, unit, master_context, slave_context)
	BaseComponent.pause(self, unit, master_context, slave_context)

	if master_context then
		local state = master_context.state

		MotionState.set_paused(state.motion_state, true)
	end
end

MotionComponent.resume = function (self, unit, master_context, slave_context)
	BaseComponent.resume(self, unit, master_context, slave_context)

	if master_context then
		local state = master_context.state

		MotionState.set_paused(state.motion_state, false)
	end
end

MotionComponent.on_entity_unregistering = function (self, unit)
	if EntityAux.has_component(unit, self.name) then
		local remove_simple_mover = false

		if EntityAux.owned(unit) then
			local state = EntityAux.state_master(unit, self.name)

			remove_simple_mover = state.constrained_by_simple_mover

			MotionComponentAux.remove_unit(self.motion_component_aux, unit)
		else
			local state = EntityAux.state(unit, self.name)

			remove_simple_mover = state.constrained_by_simple_mover == state.previous_constrained_by_simple_mover and state.constrained_by_simple_mover == true
		end

		if remove_simple_mover then
			SimpleMoverWorld.remove_unit(self.simple_mover_world, unit)
		end
	end
end

MotionComponent.update = function (self, dt)
	Profiler_start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)
	local prediction_entities = self.entity_manager:get_prediction_entities(self.name)

	Profiler_start("command_masters")
	self:command_masters(master_entities)
	Profiler_stop()
	Profiler_start("update_masters")

	local focus = CameraManager:get_focus_position()
	local focus_offset = focus + Vector3.right()
	local viewport = CameraManager:get_viewport()
	local focus_ss = viewport:world_to_screen(focus)
	local focus_offset_ss = viewport:world_to_screen(focus_offset)
	local meters_to_pixels = Vector3.length(focus_offset_ss - focus_ss)
	local pixels_to_meters = 1 / (meters_to_pixels > 0 and meters_to_pixels or 1)

	Profiler.start("Motion lua")

	local w, h = Application.back_buffer_size()
	local network_session = self.network_session_handler:get_network_session()

	MotionComponentAux.update(network_session, self.motion_component_aux, self.world_proxy:get_physics_world(), self.nav_grid._nav_grid_cpp, self.simple_mover_world, CameraManager:get_camera(), CameraManager:get_camera_unit(), w, h, pixels_to_meters, dt)
	Profiler.stop()
	Profiler_stop()
	Profiler_start("filter_slave_commands")
	self:filter_slave_commands(prediction_entities)
	Profiler_stop()
	Profiler_start("update_predictors")
	self:update_predictors(prediction_entities, dt)
	Profiler_stop()

	for unit, context in pairs(slave_entities) do
		context.num_commands = 0
	end

	Profiler_stop()
end

MotionComponent.predict_move_to = function (self, unit, context, translation, dt)
	local state = context.state
	local constrained_by_mover = state.constrained_by_mover and Unit.mover(unit) ~= nil
	local position

	if constrained_by_mover then
		position = Mover.position(Unit.mover(unit))
	else
		position = Vector3(state.positionx, state.positiony, state.positionz)
	end

	local pre_constrain_x, pre_constrain_y = translation.x, translation.y
	local trans_xy_length_sq = pre_constrain_x * pre_constrain_x + pre_constrain_y * pre_constrain_y

	Profiler_start("motion constraint: total")

	if state.constrained_by_ground and not constrained_by_mover then
		Profiler_start("motion constraint: ground")

		translation = MovementConstraints.ground_constrain(self, unit, position, translation, context)

		Profiler_stop()
	end

	if trans_xy_length_sq > math.EPSILON then
		if state.constrained_by_simple_mover then
			Profiler_start("motion constraint: simple mover")

			translation = MovementConstraints.simple_mover_move(self, unit, position, translation, context)

			Profiler_stop()
		end

		if state.constrained_by_navgrid then
			Profiler_start("motion constraint: navgrid_constrain")

			translation = MovementConstraints.navgrid_constrain(self, unit, position, translation)

			Profiler_stop()
		end
	elseif not state.down_ray_hit and state.constrained_by_navgrid and state.constrained_by_ground and not constrained_by_mover then
		Profiler_start("motion constraint: navgrid_ground_constrain")

		local height = self.nav_grid:height_at_cell_xy(math.floor(position.x), math.floor(position.y))

		if height and height < NavGrid.MAX_HEIGHT then
			position.z = height
			state.down_ray_hit = true
		end

		Profiler_stop()
	end

	if constrained_by_mover then
		Profiler_start("motion constraint: mover")

		translation = MovementConstraints.mover_move(self, unit, position, translation, dt)

		Profiler_stop()
	end

	Profiler_stop()

	local CONSTRAIN_EPS = 0.0001

	state.collided = not math_is_zero(translation.x - pre_constrain_x, CONSTRAIN_EPS) or not math_is_zero(translation.y - pre_constrain_y, CONSTRAIN_EPS)

	local new_position = position + translation
	local new_velocity = translation / dt

	Vector3Aux_box(state.velocity, new_velocity)
	Vector3.clamp_inplace(state.velocity, -50, 50)

	if state.check_last_ground_position then
		Profiler_start("last ground raycast")
		self:raycast_last_ground_position(unit, new_position, context)
		Profiler_stop()
	end

	state.positionx = new_position.x
	state.positiony = new_position.y
	state.positionz = math.clamp(new_position.z, -49, 49)
end

MotionComponent._set_constrained_by_simple_mover = function (self, unit, state, constrained)
	state.constrained_by_simple_mover_count = state.constrained_by_simple_mover_count + (constrained and 1 or -1)
	constrained = state.constrained_by_simple_mover_count > 0

	if state.constrained_by_simple_mover ~= constrained then
		if constrained then
			local radius = LuaSettingsManager:get_settings_by_unit(unit).simple_mover_radius or SIMPLE_MOVER_RADIUS

			if radius > SIMPLE_MOVER_MAX_RADIUS then
				radius = SIMPLE_MOVER_MAX_RADIUS
			end

			SimpleMoverWorld.add_unit(self.simple_mover_world, unit, radius)
		else
			SimpleMoverWorld.remove_unit(self.simple_mover_world, unit)
		end

		MotionState.set_constraint(state.motion_state, CONSTRAINTS.constrained_by_simple_mover, constrained)
	end

	state.constrained_by_simple_mover = constrained
end

MotionComponent.call_master_wanted_velocity = function (self, unit, context, data)
	MotionState.set_wanted_velocity(context.state.motion_state, data)
end

MotionComponent.call_prediction_wanted_velocity = function (self, unit, context, data)
	local p_state = context.prediction_state

	p_state.wanted_velocity = Vector3Aux.box_copy({}, data)
end

MotionComponent.call_master_set_velocity = function (self, unit, context, data)
	MotionState.set_velocity(context.state.motion_state, data)
end

MotionComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "add_force" then
		MotionState.set_wanted_force(state.motion_state, Vector3Aux.unbox(data))
	elseif command_name == "clear_velocity" then
		MotionState.clear_velocity(state.motion_state)
	elseif command_name == "clear_wanted_velocity" then
		MotionState.clear_wanted_velocity(state.motion_state)
	elseif command_name == "set_velocity" then
		MotionState.set_velocity(state.motion_state, Vector3Aux.unbox(data))
	elseif command_name == "set_max_speed" then
		MotionState.set_max_speed(state.motion_state, data)
	elseif command_name == "change_state" then
		if data == "default" then
			data = state.default_motion_state
		end

		MotionState.change_state(state.motion_state, STATES[data])
	elseif command_name == "enable" then
		if state.disabled_refmix:get() then
			state.disabled_refmix:remove(data)
		end

		state.disabled = state.disabled_refmix:get()

		MotionState.set_enabled(state.motion_state, not state.disabled)
	elseif command_name == "disable" then
		state.disabled_refmix:add(data, true)

		state.disabled = state.disabled_refmix:get()

		MotionState.set_enabled(state.motion_state, not state.disabled)
	elseif command_name == "set_collision_filter" then
		local mover = Unit.mover(unit)

		if mover then
			data = data or context.settings.default_mover_collision_filter

			Mover.set_collision_filter(mover, data)
		end
	elseif command_name == "set_position" then
		MotionComponentAux.set_position(self.motion_component_aux, self.world_proxy:get_physics_world(), self.nav_grid._nav_grid_cpp, self.simple_mover_world, state.motion_state, Vector3Aux.unbox(data))
	elseif command_name == "set_max_step_down" then
		-- Nothing
	elseif command_name == "move_to" then
		MotionState.custom_move_to(state.motion_state, Vector3Aux.unbox(data))
	elseif command_name == "force_set_position" then
		MotionState.force_set_position(state.motion_state, self.simple_mover_world, Vector3Aux.unbox(data))
	elseif command_name == "force_move_to_position" then
		MotionState.force_move_to_position(state.motion_state, self.simple_mover_world, Vector3Aux.unbox(data))
	elseif command_name == "destroy" then
		state.disabled_refmix:add("destroy", "destroyed")

		state.disabled = state.disabled_refmix:get()

		self:_set_constrained_by_simple_mover(unit, state, false)
		MotionState.destroy(state.motion_state)
	elseif command_name == "constrain_to_camera" then
		state.constrained_by_camera = data

		MotionState.set_constraint(state.motion_state, CONSTRAINTS.constrained_by_camera, data == true)
	elseif command_name == "constrain_to_navgrid" then
		state.constrained_by_navgrid = data

		MotionState.set_constraint(state.motion_state, CONSTRAINTS.constrained_by_navgrid, data == true)
	elseif command_name == "constrain_to_ground" then
		state.constrained_by_ground = data

		MotionState.set_constraint(state.motion_state, CONSTRAINTS.constrained_by_ground, data == true)
	elseif command_name == "constrain_to_mover" then
		MotionState.set_constraint(state.motion_state, CONSTRAINTS.constrained_by_mover, data == true)
	elseif command_name == "constrain_to_simple_mover" then
		self:_set_constrained_by_simple_mover(unit, state, data)
	end
end

MotionComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state
	local p_state = context.prediction_state

	if command_name == "set_override_movement" then
		if data then
			if p_state.position == nil then
				p_state.position = Vector3Aux.box({}, _get_position(state))
			end

			state.last_ground_position = Vector3Aux.box_copy({}, p_state.position)
		else
			p_state.position = nil
		end
	elseif command_name == "force_set_position" then
		if p_state.position then
			Vector3Aux.box_copy(p_state.position, data)
		end
	elseif command_name == "wanted_velocity" then
		p_state.wanted_velocity = Vector3Aux.box_copy({}, data)
	elseif command_name == "clear_velocity" then
		p_state.velocity = Vector3Aux.box(p_state.velocity or {}, Vector3.zero())
	elseif command_name == "set_velocity" then
		p_state.velocity = Vector3Aux.box_copy(p_state.velocity or {}, data)
	elseif command_name == "disable" then
		p_state.disabled = true
	elseif command_name == "enable" then
		if p_state.disabled then
			p_state.disabled = nil
		end
	elseif command_name == "change_state" then
		if data == "exit_ability" then
			if p_state.motion_state == "ability" then
				p_state.state_change_time = _G.GAME_TIME + Network.ping(EntityAux.owner(unit)) * 2 + 0.1
				p_state.pending_state_change = "default"
			else
				return true
			end
		else
			p_state.pending_state_change = nil
			p_state.motion_state = data
		end

		if data == "dynamic" then
			-- Nothing
		elseif data == "kinematic" then
			local position = _get_position(state)

			state.previous_position = Vector3Aux.box({}, position)
			state.extrapolated_position = table.clone(state.previous_position)

			if context.settings.use_mover_in_kinematic_prediction then
				Unit.set_mover(unit, "default")
				Mover.set_position(Unit.mover(unit), position)
			end
		elseif data == "ability" then
			local position = Vector3(state.positionx, state.positiony, state.positionz)

			p_state.original_position = Vector3Aux.box(p_state.original_position or {}, position)
		else
			if context.settings.use_mover_in_kinematic_prediction then
				Unit.set_mover(unit, nil)
			end

			state.previous_position = Vector3Aux.box({}, _get_position(state))
			state.extrapolated_position = table.clone(state.previous_position)
		end
	elseif command_name == "constrain_to_simple_mover" then
		-- Nothing
	end

	return true
end

MotionComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		MotionPrediction.update(self, unit, context, dt)
	end
end

MotionComponent.rpc_teleport_slaves = function (self, sender, unit, position)
	if not unit then
		return
	end

	Unit.teleport_local_position(unit, 0, position)
end

MotionComponent.rpc_teleport = function (self, sender, unit, position, rotation)
	if unit == nil then
		return
	end

	if EntityAux.has_component(unit, self.name) then
		if EntityAux.has_component_master(unit, self.name) then
			local position_box = Vector3Aux.box(TempTableFactory:get(), position)

			self:queue_command_master(unit, self.name, "set_position", position_box)
		end
	elseif EntityAux.owned(unit) then
		NetworkUnitSynchronizer:move(unit, position, rotation)
	end
end
