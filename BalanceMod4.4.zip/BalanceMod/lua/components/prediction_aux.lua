﻿-- chunkname: @lua/components/prediction_aux.lua

PredictionAux = PredictionAux or {}

PredictionAux.is_event_authorative = function (performer_unit, recipient_unit, peer)
	local is_performer_local = EntityAux.owned(performer_unit)
	local is_recipient_local = EntityAux.owned(recipient_unit)
	local is_performer_a_player = performer_unit ~= nil and Unit.get_data(performer_unit, "is_player")
	local is_recipient_a_player = recipient_unit ~= nil and Unit.get_data(recipient_unit, "is_player")

	if is_performer_a_player then
		if is_recipient_a_player then
			return is_performer_local
		else
			return is_performer_local
		end
	elseif is_recipient_a_player then
		return is_recipient_local
	else
		return is_performer_local
	end

	return false
end
