﻿-- chunkname: @lua/components/motion_variable_component.lua

MotionVariableComponent = class("MotionVariableComponent", "BaseComponent")
NavigationStates = NavigationStates or {}

MotionVariableComponent.init = function (self, creation_context)
	BaseComponent.init(self, "motion_variable", creation_context, true)
	self:register_dependencies("enemy", "motion")
end

MotionVariableComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager

	if not entity_manager:has_entities(self.name) then
		Profiler.stop()

		return
	end

	local master_entities = entity_manager:get_master_entities(self.name)
	local prediction_entities = entity_manager:get_prediction_entities(self.name)

	self:update_masters(master_entities, dt)

	local replicator = self.replicator
	local write_fields = replicator.write_fields

	for unit, context in pairs(master_entities) do
		write_fields(replicator, context)
	end

	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
end

MotionVariableComponent.setup_master = function (self, unit, context)
	local state = context.state

	state.torso_legs_angle_variable = Unit.animation_find_variable(unit, "legs_angle")
	state.speed_variable = Unit.animation_find_variable(unit, "move_speed")
end

MotionVariableComponent.setup_slave = function (self, unit, context)
	local state = context.state

	state.torso_legs_angle_variable = Unit.animation_find_variable(unit, "legs_angle")
	state.speed_variable = Unit.animation_find_variable(unit, "move_speed")
end

MotionVariableComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if context.settings.motion_variables_from_enemy then
			local enemy_state = EntityAux.state_master(unit, "enemy")
			local target_movespeed = enemy_state.movespeed or 0

			state.movespeed = math.max(target_movespeed, 0)
			state.torso_legs_angle = enemy_state.torso_legs_angle or 0
		else
			local velocity = MotionState.get_velocity(EntityAux.state_master(unit, "motion").motion_state)

			state.movespeed = math.clamp(Vector3.length(velocity), 0, 20)

			local angle = Vector3.angle_z(UnitAux.unit_forward(unit), Vector3.normalize(velocity))

			angle = NavigationAux.rotate_angle_towards(math.rad(state.torso_legs_angle), angle, math.tau, dt)
			state.torso_legs_angle = math.clamp(math.deg(angle), -180, 180)
		end

		Unit.animation_set_variable(unit, state.speed_variable, state.movespeed)
		Unit.animation_set_variable(unit, state.torso_legs_angle_variable, state.torso_legs_angle)
	end
end

MotionVariableComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings
		local speed = state.movespeed

		if settings.slave_movespeed_lerp_speed then
			local previous = state.previous_movespeed or speed

			speed = math.lerp(previous, speed, dt * settings.slave_movespeed_lerp_speed)
			state.movespeed = speed
			state.previous_movespeed = speed
		end

		local angle = NavigationAux.rotate_angle_towards(math.rad(state.previous_torso_angle or state.torso_legs_angle), math.rad(state.torso_legs_angle), math.tau * 0.2, dt)

		state.previous_torso_angle = math.deg(angle)
		state.torso_legs_angle = math.deg(angle)

		Unit.animation_set_variable(unit, state.speed_variable, state.movespeed)
		Unit.animation_set_variable(unit, state.torso_legs_angle_variable, state.torso_legs_angle)
	end
end
