﻿-- chunkname: @lua/components/stats_component.lua

require("foundation/lua/component/base_component")

StatsComponent = class("StatsComponent", "BaseComponent")
StatsComponent.KILLING_SPREE_START = 1
StatsComponent.KILLING_SPREE_MIN_COUNT = 5
StatsComponent.KILLING_SPREE_REFRESH = 2

StatsComponent.init = function (self, creation_context)
	BaseComponent.init(self, "stats", creation_context)

	self.event_delegate = creation_context.event_delegate
	self.network_router = creation_context.network_router

	self:register_rpc_events("rpc_avatar_killed_something", "rpc_treasure_picked_up", "rpc_treasure_dropped", "rpc_killing_spree_result", "rpc_killing_spree_update")

	local uint16_info = Network.type_info("uint16")

	self.MAX_SECONDS = uint16_info.max

	self:register_events("on_food_consumed", "on_avatar_killed_by_something")

	self.kill_score_info = Network.type_info("kill_score")
	self.kill_score_increment_info = Network.type_info("kill_score_increment")
	self.killing_spree_count_info = Network.type_info("killing_spree_count")
end

StatsComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	self:clear_floor_stats(unit, context)

	state.is_fusker = _G.I_AM_A_FUSKER
	state.unit_path_kills = {}
end

StatsComponent.clear_floor_stats = function (self, unit, context)
	local state = context.state

	state.kill_score = 0
	state.deaths = 0
	state.smashables_smashed = 0
	state.has_crown = false
	state.killing_spree = {
		count = 0,
		in_progress = false,
		kill_score = 0,
		kills = 0,
		time_first_kill = 0,
		time_updated = 0,
	}
	state.food_items_consumed = 0
	state.food_health_boost = 0
	state.food_items_killed = 0
	state.spree_score = 0
end

StatsComponent.reset_killing_spree = function (self, state)
	local killing_spree = state.killing_spree

	killing_spree.in_progress = false
	killing_spree.kill_score = 0
	killing_spree.kills = 0
	killing_spree.time_first_kill = nil
	killing_spree.time_updated = nil
	state.spree_score = 0
end

StatsComponent.add_kill_score = function (self, state, kill_score)
	state.kill_score = math.clamp(state.kill_score + kill_score, self.kill_score_info.min, self.kill_score_info.max)

	self:trigger_rpc_event_to_host("rpc_kill_score_add", kill_score)
end

StatsComponent.send_killing_spree_info = function (self, unit, killing_spree, update_or_result)
	local player_info = PlayerManager:get_player_info_by_player_unit(unit)
	local rpc = update_or_result and "rpc_killing_spree_update" or "rpc_killing_spree_result"
	local kill_score = math.clamp(killing_spree.kill_score, self.kill_score_increment_info.min, self.kill_score_increment_info.max)
	local count = math.clamp(killing_spree.count, self.killing_spree_count_info.min, self.killing_spree_count_info.max)

	self:trigger_rpc_event_to_others(rpc, player_info.avatar_type, kill_score, count)
end

local function _end_kill_streak(self, unit, state, killing_spree)
	local multiplier = 1
	local result = killing_spree.kill_score * multiplier

	self:add_kill_score(state, result)

	local result_data = TempTableFactory:get_map("result", result, "multiplier", multiplier)

	self.event_delegate:trigger("on_stat_event", "killing_spree_result", unit, result_data, StatEventHud.ALWAYS_SHOW)
	self:send_killing_spree_info(unit, killing_spree, false)
	self:reset_killing_spree(state)
end

StatsComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("update_masters")

	for unit, context in pairs(master_entities) do
		local state = context.state

		state.is_fusker = state.is_fusker or _G.I_AM_A_FUSKER

		local killing_spree = state.killing_spree

		if killing_spree.in_progress then
			_end_kill_streak(self, unit, state, killing_spree)
		elseif killing_spree.time_first_kill ~= nil then
			self:add_kill_score(state, killing_spree.kill_score)
			self:reset_killing_spree(state)
		end
	end

	Profiler.stop()
	Profiler.start("write_game_objects")
	self:write_game_objects(master_entities, slave_entities)
	Profiler.stop()
	Profiler.stop()
end

StatsComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "avatar_killed_something" then
		local victim_type = data.victim_type

		if victim_type == "player" then
			-- Nothing
		elseif victim_type == "monster" then
			state.enemy_kills = state.enemy_kills + 1

			local victim_settings = LuaSettingsManager:get_settings_by_settings_path(data.victim_settings_path)
			local kill_score = victim_settings.kill_score or 1
			local killing_spree = state.killing_spree

			if killing_spree.time_first_kill == nil then
				killing_spree.time_first_kill = _G.GAME_TIME
			end

			killing_spree.kills = killing_spree.kills + 1
			killing_spree.kill_score = (killing_spree.kill_score or 0) + kill_score

			if killing_spree.kills >= StatsComponent.KILLING_SPREE_MIN_COUNT then
				if not killing_spree.in_progress then
					killing_spree.in_progress = true
					killing_spree.count = 0
				end

				killing_spree.time_updated = _G.GAME_TIME
				killing_spree.count = killing_spree.count + 1

				local multiplier = 1 + killing_spree.count * 0.05

				state.spree_score = killing_spree.kill_score * multiplier
				state.spree_score = math.clamp(state.spree_score, self.kill_score_increment_info.min, self.kill_score_increment_info.max)

				local kill_spree_data = TempTableFactory:get_map("kill_score", killing_spree.kill_score, "multiplier", multiplier)

				self.event_delegate:trigger("on_stat_event", "killing_spree", unit, kill_spree_data, StatEventHud.ALWAYS_SHOW)
				self:send_killing_spree_info(unit, killing_spree, true)
			end
		elseif victim_type == "smashable" then
			state.smashables_smashed = state.smashables_smashed + 1
		elseif victim_type == "food" then
			state.food_items_killed = state.food_items_killed + 1
		end
	elseif command_name == "force_end_killing_spree" then
		local killing_spree = state.killing_spree

		if killing_spree.in_progress then
			_end_kill_streak(self, unit, state, killing_spree)
		end
	elseif command_name == "avatar_killed_by_something" then
		state.deaths = state.deaths + 1

		PerkManager:increase_count_to(unit, "deader_than_dead", state.deaths)

		local death_type

		if data.perp_unit_path then
			local perp_settings = LuaSettingsManager:get_settings_by_settings_path(data.perp_unit_path)

			death_type = perp_settings.enemy_type
		else
			death_type = "environment"
		end
	elseif command_name == "best_mini_boss_killer" then
		-- Nothing
	elseif command_name == "food_consumed" then
		state.food_items_consumed = state.food_items_consumed + 1
		state.food_health_boost = state.food_health_boost + data
	elseif command_name == "treasure_picked_up" then
		local treasure_unit = data
		local treasure_settings = LuaSettingsManager:get_settings_by_unit(treasure_unit).treasure
		local treasure_id = treasure_settings.id
		local has_var = "has_" .. treasure_id

		state[has_var] = true
	elseif command_name == "treasure_dropped" then
		local treasure_unit = data
		local treasure_settings = LuaSettingsManager:get_settings_by_unit(treasure_unit).treasure
		local treasure_id = treasure_settings.id
		local has_var = "has_" .. treasure_id

		state[has_var] = false
	elseif command_name == "clear_stats" then
		StatsComponent:clear_floor_stats(unit, context)
		self:queue_command_slave(unit, self.name, command_name, data)
	end
end

StatsComponent.on_food_consumed = function (self, avatar_unit, health_boost)
	local player_info = PlayerManager:get_player_info_by_avatar(avatar_unit)
	local player_unit = player_info.player_unit

	if EntityAux.owned(player_unit) then
		EntityAux.command_master_immediately(player_unit, self.name, "food_consumed", health_boost)
	end
end

StatsComponent.on_avatar_killed_by_something = function (self, player_unit, perp_type, perp_unit_path, ability)
	if EntityAux.owned(player_unit) then
		EntityAux.command_master_immediately(player_unit, self.name, "avatar_killed_by_something", TempTableFactory:get_map("perp_type", perp_type, "perp_unit_path", perp_unit_path, "ability", ability))
	end
end

StatsComponent.rpc_avatar_killed_something = function (self, sender, player_unit, victim_type, victim_settings_path, ability, position)
	if player_unit == nil then
		return
	end

	EntityAux.command_master_immediately(player_unit, self.name, "avatar_killed_something", TempTableFactory:get_map("victim_type", victim_type, "victim_settings_path", victim_settings_path, "ability", ability))
end

StatsComponent.rpc_treasure_picked_up = function (self, sender, player_unit, treasure_unit)
	if not player_unit then
		return
	end

	local state = EntityAux.state_master(player_unit, self.name)

	EntityAux.command_master_immediately(player_unit, self.name, "treasure_picked_up", treasure_unit)
end

StatsComponent.rpc_treasure_dropped = function (self, sender, player_unit, treasure_unit)
	if not player_unit then
		return
	end

	local state = EntityAux.state_master(player_unit, self.name)

	EntityAux.command_master_immediately(player_unit, self.name, "treasure_dropped", treasure_unit)
end

StatsComponent.rpc_killing_spree_result = function (self, sender, avatar_type, kill_score, kill_count)
	for go_id, player_info in PlayerManager:remote_players_iterator() do
		if player_info.avatar_type == avatar_type then
			local multiplier = 1 + kill_count * 0.05
			local kill_spree_data = TempTableFactory:get_map("result", kill_score * multiplier, "multiplier", multiplier)

			self.event_delegate:trigger("on_stat_event", "killing_spree_result", player_info.player_unit, kill_spree_data, StatEventHud.ALWAYS_SHOW)
		end
	end
end

StatsComponent.rpc_killing_spree_update = function (self, sender, avatar_type, kill_score, kill_count)
	for go_id, player_info in PlayerManager:remote_players_iterator() do
		if player_info.avatar_type == avatar_type then
			local multiplier = 1 + kill_count * 0.05
			local kill_spree_data = TempTableFactory:get_map("kill_score", kill_score, "multiplier", multiplier)

			self.event_delegate:trigger("on_stat_event", "killing_spree", player_info.player_unit, kill_spree_data, StatEventHud.ALWAYS_SHOW)
		end
	end
end

StatsComponent.unit_to_stats_damage_type = function (unit)
	if unit == nil then
		return "other"
	elseif EntityAux.state(unit, "avatar") then
		return "player"
	elseif EntityAux.state(unit, "enemy") or EntityAux.state(unit, "monster_spawner") then
		return "monster"
	else
		local settings = LuaSettingsManager:get_settings_by_unit(unit)

		if settings.stat_type ~= nil then
			return settings.stat_type
		else
			return "other"
		end
	end
end

StatsComponent.make_stats_damage_types = function ()
	return table.make_bimap({
		"player",
		"monster",
		"smashable",
		"food",
		"other",
	})
end
