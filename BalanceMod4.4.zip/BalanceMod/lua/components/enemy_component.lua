﻿-- chunkname: @lua/components/enemy_component.lua

require("foundation/lua/component/base_component")
require("lua/ai_states/ai_manager")
require("lua/ai_states/state_machine_ai")
require("lua/extensions/footstep_extension")

local SILHOUETTE_FADE_IN_TIME = 1
local SILHOUETTE_FADE_OUT_TIME = 0.2
local DAMAGE_AGGRO_TIME = 4
local FULL_UPDATES_PER_SECOND = 5
local SILHOUETTE_COLOR = {
	0.6,
	0.2,
	0.25,
	0.3,
}

local function get_silhouette_color(alpha)
	return Vector4(SILHOUETTE_COLOR[1], SILHOUETTE_COLOR[2], SILHOUETTE_COLOR[3], SILHOUETTE_COLOR[4] * (alpha or 1))
end

EnemyComponent = class("EnemyComponent", "PeriodicBaseComponent")

EnemyComponent.init = function (self, creation_context, comp_name)
	PeriodicBaseComponent.init(self, comp_name or "enemy", creation_context, true, 1 / FULL_UPDATES_PER_SECOND)
	self:setup_component(creation_context)
end

EnemyComponent.setup_component = function (self, creation_context)
	self:register_dependencies("motion", "navigation", "ability", "shock_receiver", "animation", "rotation", "i_damage_receiver")
	self:register_events("on_faction_changed")
	self:register_rpc_events("rpc_start_decay", "rpc_enemy_awaken", "rpc_set_target_unit", "rpc_destroy_ghost")
	self:register_interfaces("i_hit_receiver")

	self.all_state_machines = {}
	self.footstep_extension = self:create_extension(FootstepExtension)
	self.unit_paths = creation_context.unit_paths
	self.nav_grid = creation_context.nav_grid
	self.randomizer = Randomizer(creation_context.seed)
	self.despawner = creation_context.despawner
end

EnemyComponent.on_script_reload = function (self)
	self.all_state_machines = {}

	PeriodicBaseComponent.on_script_reload(self)
end

EnemyComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	local slave_state = slave_context.state
	local state = master_context.state

	self:reload_master(unit, master_context)

	state.target_unit = slave_state.target_unit
	state.current_state_name = slave_context.settings.migrated_state

	local ability_state = EntityAux.state(unit, "ability")

	if ability_state and ability_state.is_busy and state.all_states.attack then
		state.current_state_name = "attack"
		state.previous_state_name = "attack"
	end

	PeriodicBaseComponent.migrated_to_me(self, unit, slave_context, master_context)
end

EnemyComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings
	local settings_path = Unit.get_data(unit, "settings_path")
	local state_info = self.all_state_machines[settings_path]

	if state_info == nil then
		local all_states, cache_component_states = settings.states(self)

		state_info = {
			all_states = all_states,
			cache_component_states = cache_component_states,
		}
		self.all_state_machines[settings_path] = state_info
	end

	state.all_states = state_info.all_states
	state.component_states = state_info.cache_component_states(unit, context)
end

EnemyComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state
	local settings = context.settings
	local spawn_info_key = "default"

	if setup_info then
		if setup_info.spawn_info_key then
			spawn_info_key = setup_info.spawn_info_key
		end

		state.is_blind = setup_info.is_blind
		state.is_near_sighted = setup_info.is_near_sighted

		if setup_info.stat_creditor_go_id then
			Unit.set_data(unit, "stat_creditor_go_id", setup_info.stat_creditor_go_id)
		end
	end

	state.spawn_info_key = spawn_info_key

	self:reload_master(unit, context)

	state.current_state_name = state.current_state_name or "setup"

	if state.previous_state_name ~= state.current_state_name then
		StateMachineAI.on_enter(self, unit, context)

		state.previous_state_name = state.current_state_name
	end

	local ref_handler = self.entity_spawner:get_entity_reference_handler()

	ref_handler:add_handle_by_name(state, "target_unit")

	if not settings.can_move_though_walls then
		if settings.use_simple_mover ~= false then
			EntityAux.queue_command_master(unit, "motion", "constrain_to_simple_mover", true)
		end

		EntityAux.queue_command_master(unit, "motion", "constrain_to_navgrid", true)
	end
end

local function _hide_unit(unit)
	Unit.set_unit_visibility(unit, false)
end

local function _show_unit(unit)
	if Unit.alive(unit) then
		Unit.set_unit_visibility(unit, true)
	end
end

EnemyComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state
	local settings = context.settings

	MaterialAux.set_vector4(unit, nil, nil, "silhouette_color", get_silhouette_color(0), true)

	if settings.use_footstep_extension then
		self.footstep_extension:add_unit(unit)
	end

	if settings.hide_unit_on_spawn ~= false then
		_hide_unit(unit)
		self.scheduler:delay_action(0.1, closure(_show_unit, unit))
	end

	state.silhouette_alpha = 0
	state.target_alpha = 0

	self:register_unit_events(unit, "unit_on_death")

	if EntityAux.owned(unit) then
		StateMachineAI.update(self, unit, EntityAux._context_master_raw(unit, self.name), 0)
	end
end

EnemyComponent.remove_master = function (self, unit, context)
	StateMachineAI.on_exit(self, unit, context)

	local ref_handler = self.entity_spawner:get_entity_reference_handler()

	ref_handler:remove_handle_by_name(context.state, "target_unit")
end

EnemyComponent.remove_slave = function (self, unit, context)
	self:unregister_unit_event(unit, "unit_on_death")
end

EnemyComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)

	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

EnemyComponent.update_masters = function (self, entities, dt)
	local period = self.period

	for unit, context in pairs(entities) do
		local state = context.state
		local full_update = self:decide_full_update(period, context)

		if not full_update and not context.settings.always_full_update_ai then
			state.accumulated_dt = (state.accumulated_dt or 0) + dt
		else
			local dt = state.accumulated_dt or dt

			state.accumulated_dt = nil

			Profiler.start("enemy: states")
			StateMachineAI.update(self, unit, context, dt)
			Profiler.stop()
		end
	end
end

EnemyComponent.update_slaves = function (self, entities, dt)
	local period = self.period

	for unit, context in pairs(entities) do
		local state = context.state
		local full_update = self:decide_full_update(period, context)

		if full_update then
			Profiler.start("enemy: calculate silhouette alpha")

			local silhouette_alpha = 1

			if state.death_time then
				local fade_out_alpha = math.fade_out(GAME_TIME - state.death_time, SILHOUETTE_FADE_OUT_TIME)

				silhouette_alpha = math.min(silhouette_alpha, fade_out_alpha)
			elseif state.awaken_time then
				silhouette_alpha = math.fade_in(GAME_TIME - state.awaken_time, SILHOUETTE_FADE_IN_TIME)

				if silhouette_alpha == 1 then
					state.awaken_time = nil
				end
			end

			local unit_pos = Unit.world_position(unit, 0)
			local dist_to_hero = QueryManager:closest_alive_player(unit_pos)
			local MIN_RAD_DARK, MAX_RAD_DARK = 3, 5
			local MIN_RAD_BRIGHT, MAX_RAD_BRIGHT = 10, 20
			local brightness = DarknessManager:brightness()
			local MIN_HEAR_RADIUS = math.lerp(MIN_RAD_DARK, MIN_RAD_BRIGHT, brightness)
			local MAX_HEAR_RADIUS = math.lerp(MAX_RAD_DARK, MAX_RAD_BRIGHT, brightness)

			silhouette_alpha = silhouette_alpha * math.fade_between(dist_to_hero, MAX_HEAR_RADIUS, MIN_HEAR_RADIUS)
			state.target_alpha = silhouette_alpha

			Profiler.stop()
		end

		if state.target_alpha ~= state.silhouette_alpha then
			Profiler.start("enemy: apply silhouette alpha")

			if math.abs(state.target_alpha - state.silhouette_alpha) > 0.001 then
				local speed = 1
				local silhouette_alpha = math.move_towards(state.silhouette_alpha, state.target_alpha, speed, dt)

				MaterialAux.set_vector4(unit, nil, nil, "silhouette_color", get_silhouette_color(silhouette_alpha), true)

				state.silhouette_alpha = silhouette_alpha
			else
				MaterialAux.set_vector4(unit, nil, nil, "silhouette_color", get_silhouette_color(state.target_alpha), true)

				state.silhouette_alpha = state.target_alpha
			end

			Profiler.stop()
		end
	end
end

EnemyComponent.unit_on_death = function (self, unit)
	EntityAux.call_slave(unit, self.name, "die")
end

EnemyComponent.call_slave_die = function (self, unit, context)
	local settings = context.settings

	if EntityAux.owned(unit) then
		if EntityAux.has_component_master(unit, "navigation") then
			EntityAux.queue_command_master(unit, "navigation", "disable")
		end

		EntityAux.queue_command_master(unit, "rotation", "disable", "death")
	else
		EntityAux.queue_command(unit, "motion", "set_override_movement", true)
		EntityAux.queue_command(unit, "rotation", "set_override_rotation", true)
		EntityAux.queue_command(unit, "animation", "set_ignore_rpc_animations", {
			id = "enemy",
			state = "on",
		})
	end

	self:queue_command(unit, "motion", "constrain_to_simple_mover", false)
	self:queue_command(unit, "rotation", "rotate_towards_unit", nil)
	self:queue_command(unit, "ability", "set_enabled", false)

	local t = TempTableFactory:get_map("custom_handle_death", settings.custom_handle_death)

	EntityEventModifierManager:on_event(unit, "handle_death", t)

	if t.custom_handle_death then
		t.custom_handle_death(unit, context, self)
	end

	self.despawner:fadeout_static_lighting(unit, settings)

	context.state.death_time = _G.GAME_TIME
end

EnemyComponent.call_master_hit = function (self, unit, context, hit)
	if (hit.damage_amount or 0) > 0 and EntityAux.is_alive_entity(hit.caster_unit) and not FactionComponent.are_allies_unit(hit.caster_unit, unit) and EntityAux.has_interface(hit.caster_unit, "i_damage_receiver") then
		local state = context.state

		state.target_unit = hit.caster_unit
		state.next_target_select_time = _G.GAME_TIME + DAMAGE_AGGRO_TIME
	end
end

EnemyComponent.call_prediction_hit = function (self, unit, context, hit)
	return
end

EnemyComponent.call_master_decay = function (self, unit, context)
	self:trigger_rpc_event_to_others("rpc_start_decay", unit)
	self:call_slave_decay(unit, context)
end

EnemyComponent.call_slave_decay = function (self, unit, context)
	local settings = context.settings

	if settings.on_decay_start then
		settings.on_decay_start(unit, context, self)
	end

	self:queue_command(unit, "motion", "destroy", true)
	self.despawner:decay_unit(unit, {
		time_before_decay = settings.time_before_decay,
		decay_duration = settings.decay_duration,
	})
end

EnemyComponent.call_master_change_state = function (self, unit, context, data)
	context.state.wanted_state_change = data
end

EnemyComponent.call_master_set_target_unit = function (self, unit, context, data)
	local state = context.state

	state.target_unit = data.target_unit

	if data.duration then
		state.next_target_select_time = _G.GAME_TIME + data.duration
	end
end

EnemyComponent.call_slave_set_target_unit = function (self, unit, context, data)
	context.state.target_unit = data.target_unit
end

EnemyComponent.call_master_run_ability = function (self, unit, context, data)
	local state = context.state

	state.selected_ability_name = nil

	local ability_name = data
	local next_state = StateCommon.try_select_ability(self, unit, context, ability_name)

	state.wanted_state_change = next_state
end

EnemyComponent.rpc_start_decay = function (self, sender, unit)
	if not unit then
		return
	end

	if EntityAux.has_component(unit, self.name) then
		self:queue_command_predictor(unit, self.name, "decay")
	end
end

local SILHOUETTE_START_DELAY_DEFAULT = 3

EnemyComponent.rpc_enemy_awaken = function (self, sender, unit)
	if not unit then
		return
	end

	if EntityAux.has_component(unit, self.name) then
		local settings = LuaSettingsManager:get_settings_by_unit(unit)

		EntityAux._state_raw(unit, self.name).awaken_time = _G.GAME_TIME + (settings.silhouette_start_delay or SILHOUETTE_START_DELAY_DEFAULT)

		if settings.shadow_blob then
			local shadow_blob = settings.shadow_blob

			EntityAux.call_slave(unit, "linked_unit", "link_unit", shadow_blob.decal, shadow_blob.scale)
		end
	end
end

EnemyComponent.rpc_destroy_ghost = function (self, sender, unit, flow_event)
	if not unit then
		return
	end

	if flow_event then
		Unit.flow_event(unit, flow_event)
	end

	if EntityAux.owned(unit) then
		self.entity_spawner:despawn_entity(unit)
	else
		Unit.set_unit_visibility(unit, false)
	end
end

EnemyComponent.rpc_set_target_unit = function (self, sender, unit, target_unit, duration)
	if not unit then
		return
	end

	if target_unit == nil then
		return
	end

	if EntityAux.has_component(unit, self.name) then
		EntityAux.call(unit, self.name, "set_target_unit", TempTableFactory:get_map("target_unit", target_unit, "duration", duration))
	end
end

EnemyComponent.on_faction_changed = function (self, unit)
	if EntityAux.has_component(unit, self.name) then
		EntityAux.call_master(unit, self.name, "set_target_unit", TempTableFactory:get())
	end
end
