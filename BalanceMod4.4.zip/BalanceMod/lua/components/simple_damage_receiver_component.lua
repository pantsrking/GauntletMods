﻿-- chunkname: @lua/components/simple_damage_receiver_component.lua

require("foundation/lua/util/value_mixers")
require("foundation/lua/debug/plugin_component_aux")
require("lua/managers/entity_event_modifier_manager")
require("lua/components/base_damage_receiver_component")
require("lua/components/component_aux")

SimpleDamageReceiverComponent = class("SimpleDamageReceiverComponent", "BaseDamageReceiverComponent")

SimpleDamageReceiverComponent.init = function (self, creation_context)
	BaseDamageReceiverComponent.init(self, creation_context, "simple_damage_receiver")
	self:register_flow_events("flow_kill_damage_receiver")
	self:register_rpc_events("rpc_kill_damage_receiver")

	self.prediction_list = {}
	self.last_prediction_index = 1
end

SimpleDamageReceiverComponent.pause = function (self, unit, master_context, slave_context)
	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable_disabled")
	end

	if not master_context then
		ComponentAux.remove(self.prediction_list, slave_context)
	end
end

SimpleDamageReceiverComponent.resume = function (self, unit, master_context, slave_context)
	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable")
	end

	if not master_context then
		ComponentAux.add(self.prediction_list, unit, slave_context)
	end
end

SimpleDamageReceiverComponent.migrated_away = function (self, unit, slave_context, master_context)
	BaseDamageReceiverComponent.migrated_away(self, unit, slave_context, master_context)
	ComponentAux.add(self.prediction_list, unit, slave_context)
end

SimpleDamageReceiverComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseDamageReceiverComponent.migrated_to_me(self, unit, slave_context, master_context)

	if not self:is_paused(unit) then
		ComponentAux.remove(self.prediction_list, slave_context)
	end
end

SimpleDamageReceiverComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.hitpoints = 1
	state.max_hitpoints = 1
end

SimpleDamageReceiverComponent.setup_slave = function (self, unit, context, setup_info)
	BaseDamageReceiverComponent.setup_slave(self, unit, context, setup_info)

	context.state.max_hitpoints = 1

	local actor = Unit.actor(unit, "a_damageable")

	Actor.set_collision_filter(actor, "damageable")

	if not EntityAux.has_component_master(unit, self.name) then
		ComponentAux.add(self.prediction_list, unit, context)
	end
end

SimpleDamageReceiverComponent.remove_slave = function (self, unit, context)
	BaseDamageReceiverComponent.remove_slave(self, unit, context)

	if not EntityAux.has_component_master(unit, self.name) and not self:is_paused(unit) then
		ComponentAux.remove(self.prediction_list, context)
	end
end

SimpleDamageReceiverComponent.apply_authorative_hit = function (self, unit, state, context, hit)
	if state.hitpoints == 0 then
		return
	end

	local settings = context.settings

	if hit.damage_amount == nil or hit.damage_amount == 0 then
		local instakill = false

		if settings.instakill_on then
			for key, val in pairs(settings.instakill_on) do
				instakill = hit.settings[key] == val

				if instakill then
					break
				end
			end
		end

		if not instakill then
			return
		end
	end

	state.hitpoints = 0
	state.alive = false

	if settings.on_death_authorative then
		settings.on_death_authorative(unit, not hit.is_remote_hit, hit, self)
	end

	self:do_settings_death_action(unit, state, settings)

	if EntityAux.owned(unit) then
		self:handle_death_stats(unit, state, hit)
		self.replicator:write_fields(context)
	end

	local slave_state = EntityAux._state_raw(unit, self.name)

	slave_state.alive = false
	slave_state.hitpoints = 0

	self:notify_death(unit, context, nil)
end

SimpleDamageReceiverComponent.handle_death_stats = function (self, unit, state, hit)
	local victim_type = StatsComponent.unit_to_stats_damage_type(unit)

	if hit.stat_creditor_go_id then
		local player_info = PlayerManager:get_player_info(hit.stat_creditor_go_id)

		if player_info then
			local victim_settings_path = Unit.get_data(unit, "settings_path")

			self:trigger_rpc_event_to(EntityAux.owner_go_id(hit.stat_creditor_go_id), "rpc_avatar_killed_something", player_info.player_unit, victim_type, victim_settings_path, hit.ability_name, Unit.world_position(unit, 0))
		end
	end
end

SimpleDamageReceiverComponent.notify_death = function (self, unit, context, hit)
	Unit.destroy_actor(unit, "a_damageable")
	Unit.flow_event(unit, "on_death")

	local settings = context.settings

	if settings.on_death_notified then
		settings.on_death_notified(unit, self)
	end
end

SimpleDamageReceiverComponent.update = function (self, dt)
	Profiler.start(self.name)
	Profiler.start("update_predictors")
	self:update_predictors(dt)
	Profiler.stop()
	Profiler.stop()
end

local MAX_CHECKS_PER_FRAME = 20

SimpleDamageReceiverComponent.update_predictors = function (self, dt)
	local count = #self.prediction_list
	local index = self.last_prediction_index or 1

	for i = index, math.min(count, self.last_prediction_index + MAX_CHECKS_PER_FRAME) do
		local context = self.prediction_list[i]

		if context and context.state.alive then
			local state = context.state

			state.alive = state.hitpoints > 0

			if not state.alive then
				self:notify_death(context.unit, context)
			end
		end
	end

	self.last_prediction_index = self.last_prediction_index + MAX_CHECKS_PER_FRAME + 1

	if self.last_prediction_index > #self.prediction_list then
		self.last_prediction_index = 1
	end
end

local function _kill_damage_receiver(victim_unit, stat_creditor_go_id)
	local hit = {
		damage_amount = 9999,
		is_authorative = true,
		unit = victim_unit,
		position = Vector3Aux.box_temp(Unit.world_position(victim_unit, 0)),
		settings = {
			ability_name = "",
			settings_path = "",
		},
		stat_creditor_go_id = stat_creditor_go_id,
	}

	EntityAux.call(victim_unit, "simple_damage_receiver", "hit", hit)
end

SimpleDamageReceiverComponent.flow_kill_damage_receiver = function (self, params)
	local victim_unit = params.victim_unit
	local killer_unit = params.killer_unit

	if EntityAux.owned(killer_unit) then
		local stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(killer_unit)

		if not EntityAux.is_alive_entity(victim_unit) then
			return
		end

		_kill_damage_receiver(victim_unit, stat_creditor_go_id)

		if not EntityAux.owned(victim_unit) then
			self:trigger_rpc_event_to(EntityAux.owner(victim_unit), "rpc_kill_damage_receiver", victim_unit, stat_creditor_go_id)
		end
	end
end

SimpleDamageReceiverComponent.rpc_kill_damage_receiver = function (self, sender, victim_unit, stat_creditor_go_id)
	if victim_unit == nil then
		return
	end

	_kill_damage_receiver(victim_unit, stat_creditor_go_id)
end
