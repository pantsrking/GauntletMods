﻿-- chunkname: @lua/components/hud_info_component.lua

require("foundation/lua/component/base_component")

HudInfoComponent = class("HudInfoComponent", "BaseComponent")

local DEATH_PENALTY_DURATION = 5

HudInfoComponent.init = function (self, creation_context)
	BaseComponent.init(self, "hud_info", creation_context)
	self:register_events("on_equipment_updated", "on_player_avatar_linked")
end

local function progress_from_combo(combo)
	local progress = 1

	if combo then
		local now = GAME_TIME

		if now < combo.time_when_available then
			progress = math.saturate((now - combo.activation_time) / (combo.time_when_available - combo.activation_time))
		end
	end

	return math.saturate(progress)
end

HudInfoComponent.update = function (self, dt)
	Profiler.start(self.name)

	local master_entities = self.entity_manager:get_master_entities(self.name)
	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("write_game_objects")
	self:write_game_objects(master_entities, slave_entities)
	Profiler.stop()
	Profiler.stop()
end

HudInfoComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local player_info = PlayerManager:get_player_info(unit)
		local state = context.state

		if player_info.avatar_type then
			local user = ProfileManager:get_user(player_info.controller_name)

			state.gold = user:get_gold(player_info.avatar_type)
		end

		local avatar_unit = player_info.avatar_unit

		if avatar_unit then
			local avatar_state = EntityAux.state_master(avatar_unit, "avatar")
			local combo_ui_info = avatar_state.combo_ui_info

			if combo_ui_info then
				local combo_action = combo_ui_info.special
				local combo_relic = combo_ui_info.relic
				local combo_talisman = combo_ui_info.talisman

				if player_info.avatar_type == "necromagus" then
					state.progress_action = SoulLeechComponent.can_summon_skeletons(avatar_unit) and 1 or 0
					state.action_amount = SoulLeechComponent.get_skeleton_amount(avatar_unit)
				else
					state.progress_action = progress_from_combo(combo_action)
				end

				state.progress_relic = progress_from_combo(combo_relic)
				state.progress_talisman = progress_from_combo(combo_talisman)
			end

			if not state.dead and player_info.state == "dead" then
				state.dead = true
				state.died_time = _G.GAME_TIME
				state.free_revive = false
				state.death_penalty_duration = DEATH_PENALTY_DURATION
				state.death_penalty_time = DEATH_PENALTY_DURATION
			end

			if state.dead then
				local time_left = _G.GAME_TIME - state.died_time
				local time_before = time_left - dt

				if time_left % 1 < time_before % 1 then
					state.death_penalty_time = math.ceil(math.max(state.death_penalty_duration - time_left, 0))
				end

				if player_info.state ~= "dead" then
					state.dead = false
				end
			end
		end
	end
end

HudInfoComponent.get_special_ability_material = function (self, unit)
	local player_info = PlayerManager:get_player_info_by_player_unit(unit)
	local avatar_unit = player_info.avatar_unit
	local equipment_state = EntityAux.state(avatar_unit, "equipment")
	local weapon_path = ItemLookup.item_id_to_path(equipment_state.weapon)
	local weapon_settings = LuaSettingsManager:get_settings_by_unit_path(weapon_path)
	local has_special = weapon_settings.combo.abilities.special

	if not has_special then
		return nil
	end

	local ability_name
	local transitions = weapon_settings.combo.combo_transitions

	for _, transition in ipairs(transitions) do
		if transition.type == "special" then
			ability_name = transition.to
		end
	end

	local ability = weapon_settings.abilities[ability_name]
	local ui_info = ability.ui_info

	return ui_info.material
end

HudInfoComponent.on_equipment_updated = function (self, unit)
	local player_info = PlayerManager:get_player_info_by_avatar(unit)

	if player_info then
		player_info.special_ability_material = self:get_special_ability_material(player_info.player_unit)
	end
end

HudInfoComponent.on_player_avatar_linked = function (self, player_go_id, avatar_unit)
	local player_info = PlayerManager:get_player_info_by_avatar(avatar_unit)

	player_info.special_ability_material = self:get_special_ability_material(player_info.player_unit)
end
