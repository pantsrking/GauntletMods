﻿-- chunkname: @lua/components/linked_unit_component.lua

require("foundation/lua/component/base_component")

LinkedUnitComponent = class("LinkedUnitComponent", "BaseComponent")

LinkedUnitComponent.init = function (self, creation_context)
	BaseComponent.init(self, "linked_unit", creation_context)
	self:register_rpc_events("rpc_link_unit", "game_object_sync_done")

	self.component_aux = LinkedUnitComponentAux()
end

LinkedUnitComponent.setup_slave = function (self, unit, context)
	context.state.linked_unit_state = LinkedUnitComponentAux.add_unit(self.component_aux, unit)

	local settings = context.settings

	if settings.shadow_blob then
		if settings.link_shadow_blob_on_spawn then
			local shadow_blob = settings.shadow_blob

			EntityAux.call_slave(unit, self.name, "link_unit", shadow_blob.decal, shadow_blob.scale)
		end

		self:register_unit_events(unit, "unit_on_death")
	end
end

LinkedUnitComponent.remove_slave = function (self, unit, context, setup_info)
	local state = context.state

	if state.linked_unit then
		local world = self.world_proxy:get_world()

		World.destroy_unit(world, state.linked_unit)

		state.linked_unit = nil
	end

	self:unregister_unit_event(unit, "unit_on_death")
	LinkedUnitComponentAux.remove_unit(self.component_aux, unit)
end

LinkedUnitComponent.update = function (self, dt)
	LinkedUnitComponentAux.update(self.component_aux, dt)
end

LinkedUnitComponent.call_slave_link_unit = function (self, unit, context, linked_unit_path, scale)
	local rotate_unit = false

	if not linked_unit_path then
		local settings = context.settings

		if settings.linked_unit_info then
			linked_unit_path = settings.linked_unit_info.linked_unit
			rotate_unit = true
		end

		if not linked_unit_path then
			return
		end
	end

	local world = self.world_proxy:get_world()
	local pose = Unit.world_pose(unit, 0)

	if rotate_unit then
		Matrix4x4.set_rotation(pose, Quaternion.look(Vector3.down(), Vector3.right()))
	end

	local state = context.state

	state.linked_unit = World.spawn_unit(world, linked_unit_path, pose)

	if scale then
		Unit.set_local_scale(state.linked_unit, 0, Vector3(scale, scale, scale))
	end

	LinkedUnitState.set_linked_unit(state.linked_unit_state, state.linked_unit)
end

LinkedUnitComponent.call_slave_unlink_unit = function (self, unit, context)
	local state = context.state

	if state.linked_unit then
		local world = self.world_proxy:get_world()

		World.destroy_unit(world, state.linked_unit)

		state.linked_unit = nil

		LinkedUnitState.set_linked_unit(context.state.linked_unit_state, nil)
	end
end

LinkedUnitComponent.game_object_sync_done = function (self, peer_id)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		if context.settings.linked_unit_info then
			local is_linked = EntityAux.state(unit, self.name).linked_unit ~= nil

			if is_linked then
				self:trigger_rpc_event_to(peer_id, "rpc_link_unit", unit)
			end
		end
	end
end

LinkedUnitComponent.rpc_link_unit = function (self, sender, unit)
	if unit then
		EntityAux.call_slave(unit, self.name, "link_unit")
	end
end

LinkedUnitComponent.unit_on_death = function (self, unit)
	EntityAux.call_slave(unit, self.name, "unlink_unit")
end
