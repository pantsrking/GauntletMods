﻿-- chunkname: @lua/components/inventory_component.lua

require("foundation/lua/component/base_component")
require("lua/settings/items")

InventoryComponent = class("InventoryComponent", "BaseComponent")
InventoryComponent.MAX_KEYS = 5
InventoryComponent.MAX_POTIONS = 5

InventoryComponent.init = function (self, creation_context)
	BaseComponent.init(self, "inventory", creation_context)
	self:register_rpc_events("rpc_item_dropped")
end

InventoryComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.num_keys = setup_info and setup_info.num_keys or 0
	state.num_potions = setup_info and setup_info.num_potions or 0

	self:register_unit_events(unit, "unit_on_death")
end

InventoryComponent.remove_master = function (self, unit, context)
	self:unregister_unit_event(unit, "unit_on_death")
end

InventoryComponent.update = function (self, dt)
	return
end

InventoryComponent.on_changed = function (self, unit, context, field)
	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name)[field] = context.state[field]
end

InventoryComponent.call_master_add_key = function (self, unit, context, data)
	local state = context.state

	state.num_keys = math.clamp(state.num_keys + 1, 0, InventoryComponent.MAX_KEYS)

	self:on_changed(unit, context, "num_keys")
end

InventoryComponent.call_master_remove_key = function (self, unit, context, data)
	local state = context.state

	state.num_keys = math.clamp(state.num_keys - 1, 0, InventoryComponent.MAX_KEYS)

	self:on_changed(unit, context, "num_keys")
end

InventoryComponent.call_master_add_potion = function (self, unit, context, data)
	local state = context.state

	state.num_potions = math.clamp(state.num_potions + 1, 0, InventoryComponent.MAX_POTIONS)

	self:on_changed(unit, context, "num_potions")
end

InventoryComponent.call_master_remove_potion = function (self, unit, context, data)
	local state = context.state

	state.num_potions = math.clamp(state.num_potions - 1, 0, InventoryComponent.MAX_POTIONS)

	Unit.flow_event(unit, "on_potion_lost")
	self:on_changed(unit, context, "num_potions")
end

InventoryComponent.call_master_clear_keys_and_potions = function (self, unit, context, data)
	local state = context.state

	state.num_potions = 0
	state.num_keys = 0

	local slave_state = EntityAux._state_raw(unit, self.name)

	slave_state.num_potions = 0
	slave_state.num_keys = 0

	self.replicator:write_fields(context)
end

InventoryComponent.drop_inventory = function (self, unit)
	local motion_state = EntityAux.state_master(unit, "motion")
	local last_ground_position = MotionState.get_last_ground_position(motion_state.motion_state)
	local position = last_ground_position
	local rotation = Unit.local_rotation(unit, 0)
	local state = EntityAux.state_master(unit, "inventory")

	for i = 1, state.num_keys do
		local x = (Math.random() - 0.5) * 2
		local y = (Math.random() - 0.5) * 2
		local p = Vector3.copy(position, x, y, 0)

		p = QueryManager:snap_to_navgrid(p, 0.5, 5)

		local entity_item_path = "gameobjects/keys/small"
		local dropped_unit = self.entity_spawner:spawn_entity(entity_item_path, position, rotation)

		NetworkUnitSynchronizer:add(dropped_unit)
		self:trigger_rpc_event("rpc_item_dropped", dropped_unit)
		EntityAux.call_master(unit, self.name, "remove_key")
	end
end

InventoryComponent.drop_inventory_on_player_drop = function (entity_spawner, player_info, position)
	local network_router = FlowCallbacks.state_game.network_router
	local rotation = Quaternion.identity()

	for i = 1, player_info.num_keys do
		local x = (Math.random() - 0.5) * 2
		local y = (Math.random() - 0.5) * 2
		local p = Vector3.copy(position, x, y, 0)

		p = QueryManager:snap_to_navgrid(p, 0.5, 5)

		local entity_item_path = "gameobjects/keys/small"
		local dropped_unit = entity_spawner:spawn_entity(entity_item_path, p, rotation)

		NetworkUnitSynchronizer:add(dropped_unit)
		network_router:transmit_to_all("rpc_item_dropped", dropped_unit)
	end

	for i = 1, player_info.num_potions do
		local x = (Math.random() - 0.5) * 2
		local y = (Math.random() - 0.5) * 2
		local p = Vector3.copy(position, x, y, 0)

		p = QueryManager:snap_to_navgrid(p, 0.5, 5)

		local entity_item_path = "gameobjects/potions/potion_blue"
		local dropped_unit = entity_spawner:spawn_entity(entity_item_path, p, rotation)

		NetworkUnitSynchronizer:add(dropped_unit)
		network_router:transmit_to_all("rpc_item_dropped", dropped_unit)

		local t = TempTableFactory:get_map("id", "potion_dropped", "state", "on")

		EntityAux.queue_command_master_interface(dropped_unit, "i_damage_receiver", "set_invincibility", t)
		Game.scheduler:delay_action(1, function ()
			if Unit.alive(dropped_unit) then
				local t = TempTableFactory:get_map("id", "potion_dropped", "state", "off")

				EntityAux.queue_command_master_interface(dropped_unit, "i_damage_receiver", "set_invincibility", t)
			end
		end)
	end
end

InventoryComponent.unit_on_death = function (self, unit)
	self:drop_inventory(unit)
end

InventoryComponent.rpc_item_dropped = function (self, sender, item)
	if item == nil then
		return
	end

	MaterialAux.set_scalar(item, nil, nil, "silhouette_transparency", 0, true)
	Unit.flow_event(item, "on_dropped")
end

InventoryComponent.setup_console_library = function (self)
	return {
		text = "Can add/remove items to ones inventory.",
		parts = {
			add_key = {
				usage = "[go_id|all]",
				fun = function (target)
					return
				end,
			},
			remove_key = {
				text = "Removes one item of item_type. (keys)",
				usage = "[go_id|all]",
				fun = function (target)
					return
				end,
			},
			add_potion = {
				usage = "[go_id|all]",
				fun = function (target)
					return
				end,
			},
			remove_potion = {
				text = "Removes one item of item_type. (potion)",
				usage = "[go_id|all]",
				fun = function (target)
					return
				end,
			},
		},
	}
end
