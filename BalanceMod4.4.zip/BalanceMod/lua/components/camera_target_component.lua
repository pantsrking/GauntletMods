﻿-- chunkname: @lua/components/camera_target_component.lua

require("foundation/lua/component/base_component")

CameraTargetComponent = class("CameraTargetComponent", "BaseComponent")

CameraTargetComponent.init = function (self, creation_context)
	BaseComponent.init(self, "camera_target", creation_context)
	self.event_delegate:register(self, "on_avatar_exiting_floor")
	self.network_router:register(self, "rpc_add_camera_target", "game_object_sync_done")
end

CameraTargetComponent.setup_slave = function (self, unit, context)
	self:register_unit_events(unit, "unit_on_death")
end

CameraTargetComponent.remove_slave = function (self, unit, context)
	CameraManager:remove_target(unit)
	self:unregister_unit_event(unit, "unit_on_death")
end

CameraTargetComponent.update = function (self, dt)
	return
end

CameraTargetComponent.call_slave_set_targeted = function (self, unit, context, data)
	local state = context.state

	if state.is_targeted and not data then
		state.is_targeted = false

		CameraManager:remove_target(unit)
	elseif not state.is_targeted and data then
		state.is_targeted = true

		CameraManager:add_target(unit)
	end
end

CameraTargetComponent.unit_on_death = function (self, unit)
	EntityAux.call_slave(unit, self.name, "set_targeted", false)
end

CameraTargetComponent.on_avatar_exiting_floor = function (self, unit, player_go_id)
	EntityAux.call_slave(unit, self.name, "set_targeted", false)
end

CameraTargetComponent.rpc_add_camera_target = function (self, sender, unit)
	if unit then
		EntityAux.call_slave(unit, self.name, "set_targeted", true)
	end
end

CameraTargetComponent.game_object_sync_done = function (self, peer_id)
	local masters = self.entity_manager:get_master_entities(self.name)

	for unit, context in pairs(masters) do
		if EntityAux.state(unit, self.name).is_targeted then
			self:trigger_rpc_event_to(peer_id, "rpc_add_camera_target", unit)
		end
	end
end
