﻿-- chunkname: @lua/components/carryable_component.lua

require("foundation/lua/component/base_component")

CarryableComponent = class("CarryableComponent", "BaseComponent")

CarryableComponent.init = function (self, creation_context)
	BaseComponent.init(self, "carryable", creation_context, true)

	self.nav_grid = creation_context.nav_grid

	self:register_dependencies("interactable")
	self:register_events("on_entity_unregistering")
	self:register_rpc_events("rpc_reactivate_carryable")
end

local function _set_rotation(unit)
	local rot = Unit.local_rotation(unit, 0)
	local forward = Quaternion.forward(rot)
	local projected_forward = Vector3.dot(Vector3.up(), forward) * Vector3.up()
	local forward_xy = forward - projected_forward

	Unit.set_local_rotation(unit, 0, Quaternion.look(forward_xy))
end

CarryableComponent.set_rotation = _set_rotation

CarryableComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context)

	local slave_state = slave_context.state

	if slave_state.carrier then
		self:force_drop(unit, slave_state)
	end
end

CarryableComponent.force_drop = function (self, unit, state)
	local world = self.world_proxy:get_world()

	World.unlink_unit(world, unit)

	local position, snapped_position = CarrierComponent.find_dropoff_position(unit, unit, self.world_proxy:get_physics_world(), self.nav_grid, 2)

	position.z = snapped_position.z

	Unit.teleport_local_position(unit, 0, position)
	self:trigger_rpc_event_to_others("rpc_teleport_slaves", unit, position)
	EntityAux.queue_command_master(unit, "motion", "force_move_to_position", Vector3Aux.box_temp(position))
	self:queue_command_master(unit, self.name, "reactivate")
	_set_rotation(unit)

	state.carrier = nil

	if not EntityAux.has_interface(unit, "i_damage_receiver") or EntityAux.state_interface(unit, "i_damage_receiver").alive then
		Unit.create_actor(unit, "a_collision")
	end
end

CarryableComponent.setup_master = function (self, unit, context, setup_info)
	EntityAux.queue_command_master(unit, "motion", "constrain_to_navgrid", true)
	EntityAux.queue_command_master(unit, "motion", "disable", self.name)
end

CarryableComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "enter_carry" then
		state.carrier = data

		Unit.destroy_actor(unit, "a_collision")
		EntityAux.call_slave(unit, "dynamic_blocker", "unblock")
	elseif command_name == "exit_carry" then
		if state.carrier then
			_set_rotation(unit)

			state.carrier = nil

			if EntityAux.has_interface(unit, "i_damage_receiver") and EntityAux.state_interface(unit, "i_damage_receiver").alive then
				-- Nothing
			end
		end
	elseif command_name == "reactivate" then
		EntityAux.queue_command_master(unit, "motion", "change_state", "default")
		EntityAux.queue_command_master(unit, "motion", "disable", self.name)

		if DamageReceiverComponent.is_alive(unit) then
			EntityAux.queue_command_master(unit, "interactable", "set_enabled", true)
			self:reactivate_carryable(unit)
			self:trigger_rpc_event_to_others("rpc_reactivate_carryable", unit)
		end
	end
end

CarryableComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "enter_carry" then
		if not Unit.alive(data) then
			return
		end

		state.carrier = data

		Unit.destroy_actor(unit, "a_collision")
		EntityAux.call_slave(unit, "dynamic_blocker", "unblock")
		EntityAux.queue_command(unit, "motion", "disable", self.name)
	elseif command_name == "exit_carry" then
		_set_rotation(unit)

		state.carrier = nil

		EntityAux.queue_command(unit, "motion", "enable", self.name)
	end
end

CarryableComponent.on_entity_unregistering = function (self, entity)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		if context.state.carrier == entity then
			_set_rotation(unit)

			context.state.carrier = nil
		end
	end
end

CarryableComponent.rpc_reactivate_carryable = function (self, sender, unit)
	if unit ~= nil then
		self:reactivate_carryable(unit)
	end
end

CarryableComponent.reactivate_carryable = function (self, unit)
	EntityAux.call_slave(unit, "dynamic_blocker", "block")
	EntityAux.call_slave(unit, "dynamic_blocker", "update_position")
	Unit.create_actor(unit, "a_collision")
end
