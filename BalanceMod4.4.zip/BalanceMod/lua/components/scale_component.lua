﻿-- chunkname: @lua/components/scale_component.lua

require("foundation/lua/component/base_component")

ScaleComponent = class("ScaleComponent", "BaseComponent")

ScaleComponent.init = function (self, creation_context)
	BaseComponent.init(self, "scale", creation_context)

	local type_info = Network.type_info("mesh_scale")

	self.SCALE_MIN = type_info.min
	self.SCALE_MAX = type_info.max

	self:register_interfaces("i_scale")
end

local function _calculate_scale(component, settings, new_scale)
	new_scale = math.clamp(new_scale or settings.scale_info.scale, component.SCALE_MIN, component.SCALE_MAX)

	return new_scale + (settings.scale_info.variation or 0) * (math.random() * 2 - 1)
end

local function _update_unit_scale(unit, state, scale)
	state.current_scale = scale

	Unit.set_local_scale(unit, 0, Vector3(scale, scale, scale))

	if state.scale_speed_variable then
		Unit.animation_set_variable(unit, state.scale_speed_variable, 1 / scale)
	end

	local inv_scale = scale > 0 and Vector3(1 / scale, 1 / scale, 1 / scale) or Vector3.zero()
	local c = {}

	Unit.children(unit, c)

	for i, u in ipairs(c) do
		if Unit.num_lights(u) > 0 then
			Unit.set_local_scale(u, 0, inv_scale)
		end
	end
end

ScaleComponent.set_scale_master = function (self, unit, context, scale)
	context.state.scale = scale

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).scale = scale
end

ScaleComponent.setup_master = function (self, unit, context, setup_info)
	context.state.scale = _calculate_scale(self, context.settings)
end

ScaleComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	if EntityAux.owned(unit) then
		local master_context = EntityAux._context_master_raw(unit, self.name)

		self.replicator:write_fields(master_context)

		state.scale = master_context.state.scale
	end

	if Unit.has_animation_state_machine(unit) then
		state.scale_speed_variable = Unit.animation_find_variable(unit, "scale_speed")
	end

	state.current_scale = state.scale

	_update_unit_scale(unit, state, state.scale)
end

ScaleComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entities = self.entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(entities) do
		local state = context.state

		if state.disabled ~= true and not math.equals(state.current_scale, state.scale) then
			local new_scale = math.lerp(state.current_scale, state.scale, 0.04)

			_update_unit_scale(unit, state, new_scale)
		end
	end

	Profiler.stop()
end

ScaleComponent.call_master_set_scale = function (self, unit, context, data)
	local scale = _calculate_scale(self, context.settings, data)

	self:set_scale_master(unit, context, scale)
end

ScaleComponent.call_slave_force_reset = function (self, unit, context, data)
	local state = context.state

	state.scale = _calculate_scale(self, context.settings)

	_update_unit_scale(unit, state, state.scale)

	state.disabled = true
end

ScaleComponent.setup_console_plugin = function (self)
	local plugin = {
		scale = function (argument_array, command_string)
			if argument_array[2] == "set_scale" then
				local target = argument_array[4]
				local scale = tonumber(argument_array[3])
				local msg = {
					message = sprintf("Scale set to %d for %s.", scale, PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_call(self, "set_scale", scale, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		scale = {
			"set_scale",
		},
	}
	local docs = {
		scale = {
			set_scale = {
				usage = "set_scale <scale> [go_id]",
			},
		},
	}

	return plugin, auto_complete, docs
end
