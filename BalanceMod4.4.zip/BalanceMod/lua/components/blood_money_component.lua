﻿-- chunkname: @lua/components/blood_money_component.lua

require("foundation/lua/component/base_component")

BloodMoneyComponent = class("BloodMoneyComponent", "BaseComponent")

BloodMoneyComponent.init = function (self, creation_context)
	BaseComponent.init(self, "blood_money", creation_context)
end

BloodMoneyComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.gold = setup_info and setup_info.gold or 500
	state.player_go_id = setup_info and setup_info.player_go_id or nil
	EntityAux._state_raw(unit, self.name).gold = state.gold
end

BloodMoneyComponent.setup_slave = function (self, unit, context, setup_info)
	if EntityAux.owned(unit) then
		self.replicator:write_fields(context)
	end
end

BloodMoneyComponent.update = function (self)
	return
end
