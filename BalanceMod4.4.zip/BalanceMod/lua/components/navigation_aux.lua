﻿-- chunkname: @lua/components/navigation_aux.lua

require("foundation/lua/component/base_component")
require("lua/dungeon/nav_grid")

NavigationAux = NavigationAux or {}

local DEFAULT_MOVESPEED_RANGE = {
	0.5,
	1,
}

NavigationAux.setup_movespeed = function (unit, context, randomizer)
	local state, settings = context.state, context.settings
	local range = settings.random_movespeed_range or DEFAULT_MOVESPEED_RANGE
	local movespeed_modifier = randomizer:rangef(range[1], range[2])

	NavigationState.setup_movespeed(state.navigation_state, movespeed_modifier, settings.max_movespeed or settings.movespeed, settings.movespeed, settings.movespeed_0_to_100_duration or 0)
end

NavigationAux.rotate_angle_towards = function (source, destination, speed, dt)
	local direction = math.sign(destination - source)
	local distance = math.abs(destination - source)

	if distance > math.pi then
		direction = -direction
	end

	local next_step = math.wrap_angle(source + direction * speed * dt)
	local distance_before = distance
	local distance_after = math.abs(destination - next_step)

	if distance_before > math.pi then
		distance_before = math.tau - distance_before
	end

	if distance_after > math.pi then
		distance_after = math.tau - distance_after
	end

	local was_closer_before = distance_before < distance_after

	return was_closer_before and destination or next_step
end
