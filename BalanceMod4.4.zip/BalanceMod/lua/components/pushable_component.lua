﻿-- chunkname: @lua/components/pushable_component.lua

require("foundation/lua/component/base_component")

PushableComponent = class("PushableComponent", "BaseComponent")

PushableComponent.init = function (self, creation_context)
	BaseComponent.init(self, "pushable", creation_context, true)
	self:register_flow_events("connect_neighbor", "connect_pushable")
	self:register_events("on_remove_units", "on_entity_unregistering")

	self.graph_lookup = {}
end

PushableComponent.on_remove_units = function (self)
	self.graph_lookup = {}
end

PushableComponent.on_entity_unregistering = function (self, unit)
	for pushable_unit, context in self.entity_manager:all_masters_iterator(self.name) do
		if context.state.controlling_avatar == unit then
			self:queue_command_master(pushable_unit, self.name, "set_controller", nil)
		end
	end
end

PushableComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context)

	slave_context.state.previous_position = nil
end

PushableComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.is_being_pushed = false

	self:on_idle_enter(unit, context)
end

PushableComponent.setup_slave = function (self, unit, context, setup_info)
	EntityAux.call_slave(unit, "dynamic_blocker", "block")
end

local function _axis_align(vector)
	local rd = Vector3.dot(vector, Vector3.right())
	local fd = Vector3.dot(vector, Vector3.forward())

	if math.abs(fd) > math.abs(rd) then
		vector = Vector3.forward() * math.sign(fd)
	else
		vector = Vector3.right() * math.sign(rd)
	end

	return vector
end

local function _flat_position(unit, node_name)
	local node_index = node_name and Unit.node(unit, node_name) or 0
	local position = Unit.world_position(unit, node_index)
	local height = position.z

	position.z = 0

	return position, height
end

PushableComponent.handle_pushed = function (self, unit, context, translation)
	local state = context.state

	if translation and Vector3.length_xy_squared(translation) > math.EPSILON and state.current_state == "pushed" then
		if not state.is_being_pushed then
			Unit.flow_event(unit, "on_pushed_start")
			self:trigger_rpc_event_to_others("flow_event", unit, "on_pushed_start")

			state.is_being_pushed = true
		end

		Unit.destroy_actor(unit, "c_collision")
	elseif state.is_being_pushed then
		Unit.flow_event(unit, "on_pushed_stop")
		self:trigger_rpc_event_to_others("flow_event", unit, "on_pushed_stop")

		state.is_being_pushed = false

		Unit.create_actor(unit, "c_collision")
		EntityAux.queue_command(unit, "ability", "interrupt")
	end
end

PushableComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.current_state == "idle" then
			-- Nothing
		elseif state.current_state == "pushed" and state.controlling_avatar ~= nil then
			local root = EntityAux.state(unit, self.name).root_track_unit

			state.graph = state.graph or self.graph_lookup[root]

			local center = Unit.world_position(unit, Unit.node(unit, "j_center"))
			local root = Unit.world_position(unit, 0)
			local to_center = center - root
			local position, height = _flat_position(unit, "j_center")
			local avatar_position, _ = _flat_position(state.controlling_avatar)
			local to_avatar = Vector3.normalize(avatar_position - position)
			local movement = -to_avatar

			movement = _axis_align(movement)

			local to_avatar_aligned = _axis_align(to_avatar)
			local getting_pushed = Vector3.dot(to_avatar_aligned, movement) < -0.9

			if getting_pushed and not state.previous_getting_pushed then
				state.first_push_frame = true
				state.previous_getting_pushed = getting_pushed

				local command = TempTableFactory:get_map("ability_name", "pushed", "owner_unit", state.controlling_avatar)

				EntityAux.queue_command(unit, "ability", "execute_ability", command)

				return
			elseif not getting_pushed and state.previous_getting_pushed then
				state.previous_getting_pushed = getting_pushed

				EntityAux.queue_command(unit, "ability", "interrupt")

				return
			end

			if getting_pushed then
				local target_node, direction = self:get_next_node(unit, context, movement)

				if target_node then
					state.last_target_node = target_node

					local target_position, _ = _flat_position(target_node)
					local to_target = target_position - position
					local d = Vector3.dot(to_target, direction)
					local proj = to_target - d * direction
					local wanted_velocity = Vector3.zero()

					wanted_velocity = direction * Vector3.length(movement) * (context.settings.push_speed or 2)

					EntityAux.call_master(state.controlling_avatar, "motion", "wanted_velocity", wanted_velocity)

					local wanted_translation = wanted_velocity * dt
					local actual_translation = MovementConstraints.camera_constrain(self, state.controlling_avatar, Unit.world_position(state.controlling_avatar, 0), wanted_translation, dt)
					local constrained_by_camera = Vector3.length_squared(actual_translation) < Vector3.length_squared(wanted_translation)
					local motion_velocity = wanted_velocity

					if constrained_by_camera then
						motion_velocity = Vector3.zero()
					end

					local speed = Vector3.length(motion_velocity)

					if speed > math.EPSILON then
						local physics_world = self.world_proxy:get_physics_world()
						local collision_filter = "pushblock_blocker"
						local query_pose = Matrix4x4.from_quaternion_position(Quaternion.look(wanted_velocity, Vector3.up()), center + Vector3.normalize(wanted_velocity) * 1.2)
						local half_extents = Vector3(1.7, 1.5, 1.7)
						local results = PhysicsWorld.immediate_overlap(physics_world, "shape", "oobb", "pose", query_pose, "size", half_extents, "collision_filter", collision_filter)

						if results and #results > 0 then
							for i, actor in ipairs(results) do
								local pos = Matrix4x4.translation(query_pose)
								local result = results[1]
								local p = Actor.position(result)
								local to_hit = p - pos

								to_hit.z = 0

								local ahead = Vector3.normalize(motion_velocity)
								local dot = Vector3.dot(to_hit, ahead)

								if dot >= 0 then
									local aligned_to_hit = dot * ahead
									local aligned_length = Vector3.length(aligned_to_hit)

									if aligned_length > 1.7 then
										motion_velocity = Vector3.zero()
										speed = 0

										break
									end
								end
							end
						end
					end

					local aligned_velocity = _axis_align(Vector3.normalize(motion_velocity))
					local dot = Vector3.dot(aligned_velocity, direction)

					if dot > 0 then
						local projected_velocity = dot * direction
						local actual_velocity = projected_velocity * speed

						wanted_velocity = actual_velocity
						actual_velocity.z = 0
						state.first_push_frame = false

						local previous_position = Vector3Aux.unbox(state.position)
						local translation = actual_velocity * dt

						if Vector3.length_squared(proj) > math.EPSILON then
							translation = translation + proj
						end

						if Vector3.length_squared(translation) > Vector3.length_squared(to_target) then
							position = target_position
							position.z = height
							position = position - to_center

							Vector3Aux.box(state.position, position)
						else
							Vector3Aux.box(state.position, previous_position + translation)
						end

						local any_hit, hit_position, _, _, _ = PhysicsWorld.immediate_raycast(self.world_proxy:get_physics_world(), center, Vector3.down(), 3, "closest", "types", "statics", "collision_filter", "floor")

						if not any_hit then
							self:on_fall_enter(unit, context, target_node)

							state.fall_target_node = target_node
						elseif self.debug_draw then
							local drawer = Debug.drawer("pushable")

							drawer:sphere(hit_position, 0.3, Color(255, 255, 255))
						end
					else
						wanted_velocity = Vector3.zero()
					end

					self:handle_pushed(unit, context, wanted_velocity)
				else
					if state.last_target_node then
						local target_node = state.last_target_node
						local target_position, _ = _flat_position(target_node)
						local to_target = target_position - position

						state.last_target_node = nil

						if Vector3.length(to_target) < 0.1 and Unit.get_data(target_node, "end_state") ~= nil then
							local end_state = Unit.get_data(target_node, "end_state")

							if end_state == "destruct" then
								self:on_exploding_enter(unit, context)

								return
							elseif end_state == "disable" then
								self:on_disable_enter(unit, context)

								return
							end
						end
					end

					self:handle_pushed(unit, context, nil)
				end
			else
				self:handle_pushed(unit, context, nil)
			end
		elseif state.current_state == "falling" then
			local target = Vector3Aux.unbox(state.fall_target_position)
			local source_rot = QuaternionAux.unbox(state.fall_source_rotation)
			local target_rot = QuaternionAux.unbox(state.fall_target_rotation)
			local center = Unit.world_position(unit, Unit.node(unit, "j_center"))
			local root = Unit.world_position(unit, 0)
			local timer = state.timer or 0

			state.timer = ((state.timer or 0) + dt * 1) % state.duration

			if timer < state.timer then
				local position = state.trajectory(state.timer)

				Vector3Aux.box(state.position, position)

				local t = math.saturate(state.timer / state.duration)
				local rot = Quaternion.slerp(source_rot, target_rot, t)

				QuaternionAux.box(state.rotation, rot)

				if self.debug_draw then
					local drawer = Debug.drawer("pushable")

					drawer:sphere(position, 0.2, Color(255, 255, 0))
					drawer:sphere(target, 0.2, Color(255, 255, 255))
					drawer:pose(Matrix4x4.from_quaternion_position(rot, position), 0.2)
				end
			else
				Vector3Aux.box(state.position, state.trajectory(state.duration))
				QuaternionAux.box(state.rotation, target_rot)

				if Unit.get_data(state.fall_target_node, "end_state") ~= nil then
					local end_state = Unit.get_data(state.fall_target_node, "end_state")

					if end_state == "destruct" then
						local command = TempTableFactory:get_map("ability_name", "land", "owner_unit", state.controlling_avatar)

						EntityAux.queue_command(unit, "ability", "execute_ability", command)
						self:on_exploding_enter(unit, context)

						return
					elseif end_state == "disable" then
						local command = TempTableFactory:get_map("ability_name", "land", "owner_unit", state.controlling_avatar)

						EntityAux.queue_command(unit, "ability", "execute_ability", command)
						self:on_disable_enter(unit, context)

						return
					end
				else
					EntityAux.command_master_immediately(unit, "interactable", "set_enabled", true)
					self:on_idle_enter(unit, context)
				end

				local command = TempTableFactory:get_map("ability_name", "land", "owner_unit", state.controlling_avatar)

				EntityAux.queue_command(unit, "ability", "execute_ability", command)
			end
		elseif state.current_state == "exploding" then
			if _G.GAME_TIME > state.start_time + context.settings.explode_delay then
				self:on_destroyed_enter(unit, context)
			end
		elseif state.current_state == "destroyed" then
			-- Nothing
		elseif state.current_state == "disabled" then
			-- Nothing
		end
	end
end

PushableComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local position = Vector3Aux.unbox(state.position)
		local previous_position = Vector3Aux.unbox(state.previous_position or state.position)

		position = Vector3.lerp(previous_position or position, position, dt * 13)

		Vector3Aux.box(state.position, position)

		state.previous_position = Vector3Aux.box(state.previous_position or {}, position)

		local rotation = QuaternionAux.unbox(state.rotation)
		local previous_rotation = QuaternionAux.unbox(state.previous_rotation or state.rotation)

		rotation = Quaternion.slerp(previous_rotation or rotation, rotation, dt * 35)

		QuaternionAux.box(state.rotation, rotation)

		state.previous_rotation = QuaternionAux.box(state.previous_rotation or {}, rotation)
	end
end

PushableComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local position = Vector3Aux.unbox(state.position)
		local rotation = QuaternionAux.unbox(state.rotation)
		local update_blocker = false

		if state.previous_position_blocked == nil then
			update_blocker = true
			state.previous_position_blocked = Vector3Aux.box_copy({}, position)
		else
			local previous = Vector3Aux.unbox(state.previous_position_blocked)
			local distance = Vector3.manhattan_distance(previous, position)

			update_blocker = distance > 0.5
		end

		if update_blocker then
			Vector3Aux.box(state.previous_position_blocked, position)
			EntityAux.call_slave(unit, "dynamic_blocker", "update_position")
		end

		Unit.teleport_local_position(unit, 0, position)
		Unit.teleport_local_rotation(unit, 0, rotation)
	end
end

PushableComponent.on_idle_enter = function (self, unit, context)
	local state = context.state

	state.current_state = "idle"

	EntityAux.queue_command(unit, "ability", "interrupt")
	self:handle_pushed(unit, context, nil)
end

PushableComponent.on_pushed_enter = function (self, unit, context)
	local state = context.state

	state.current_state = "pushed"
	state.previous_getting_pushed = false
end

PushableComponent.on_fall_enter = function (self, unit, context, target_node)
	local state = context.state

	state.current_state = "falling"
	state.controlling_avatar = nil
	state.trajectory = self:calculate_trajectory(unit, context, target_node)

	self:handle_pushed(unit, context, nil)
end

PushableComponent.on_exploding_enter = function (self, unit, context)
	local state = context.state

	state.current_state = "exploding"

	EntityAux.queue_command(unit, "ability", "interrupt")

	local command = TempTableFactory:get_map("ability_name", "explode", "owner_unit", state.controlling_avatar)

	EntityAux.queue_command(unit, "ability", "execute_ability", command)

	state.start_time = _G.GAME_TIME

	self:handle_pushed(unit, context, nil)
end

PushableComponent.on_destroyed_enter = function (self, unit, context)
	local state = context.state
	local drop_unit_path = Unit.get_data(unit, "drop_unit_path")

	if drop_unit_path and #drop_unit_path > 0 then
		local center = Unit.world_position(unit, Unit.node(unit, "j_center"))
		local local_center = Unit.local_position(unit, Unit.node(unit, "j_center"))
		local dropped_unit = self.entity_spawner:spawn_entity(drop_unit_path, center - local_center, Quaternion.identity(), EntityAux.go_id(unit))

		Unit.set_data(dropped_unit, "is_dropped", true)
		self:trigger_rpc_event("flow_event", dropped_unit, "on_dropped")
		NetworkUnitSynchronizer:add(dropped_unit)
	end

	self:handle_pushed(unit, context, nil)

	state.current_state = "destroyed"

	self.entity_spawner:despawn_entity(unit)
end

PushableComponent.on_disable_enter = function (self, unit, context)
	local state = context.state

	state.current_state = "disabled"

	EntityAux.queue_command_master(unit, "interactable", "destroy")
	self:handle_pushed(unit, context, nil)
end

PushableComponent.get_next_node = function (self, unit, context, direction)
	local state = context.state
	local root = state.root_track_unit

	state.graph = state.graph or self.graph_lookup[root]

	local position, box_height = _flat_position(unit, "j_center")
	local potential_edges = TempTableFactory:get()

	for track, connections in pairs(state.graph) do
		local tp, _ = _flat_position(track)

		for i, node in ipairs(connections) do
			local np, _ = _flat_position(node)
			local line_segment = np - tp
			local to_point = position - tp
			local dot = Vector3.dot(Vector3.normalize(to_point), Vector3.normalize(line_segment))

			if dot > 0.99 then
				local length_squared = Vector3.length_squared(line_segment)
				local t = Vector3.dot(to_point, line_segment) / length_squared

				if t >= -0.01 and t <= 1.01 then
					potential_edges[#potential_edges + 1] = TempTableFactory:get_array(track, node)
				end
			end
		end
	end

	local min_distance_sq, next_node, best_direction = 99999

	for _, edge in ipairs(potential_edges) do
		for _, node in ipairs(edge) do
			local node_position, node_height = _flat_position(node)

			if node_height <= box_height then
				local to_target = node_position - position
				local to_target_n = Vector3.normalize(to_target)
				local dot = Vector3.dot(to_target_n, direction)
				local valid_target = dot >= 0.999

				if self.debug_draw and dot > 0.7 then
					local drawer = Debug.drawer("pushable")

					drawer:sphere(Unit.local_position(node, 0), 0.4, valid_target and Color(0, 255, 0) or Color(255, 0, 0))
					drawer:line(position, position + to_target)
				end

				if valid_target then
					local length_squared = Vector3.length_squared(to_target)

					if length_squared < min_distance_sq then
						min_distance_sq = length_squared
						next_node = node
						best_direction = to_target_n
					end
				end
			end
		end
	end

	return next_node, direction
end

local GRAVITY = 20

PushableComponent.calculate_trajectory = function (self, unit, context, target_node)
	local state = context.state
	local source_rotation = Unit.world_rotation(unit, 0)
	local source = Unit.world_position(unit, 0)
	local rotated_to_center = Quaternion.rotate(Unit.world_rotation(unit, 0), Unit.local_position(unit, Unit.node(unit, "j_center")))
	local source_center = source + rotated_to_center
	local target = Unit.world_position(target_node, 0)
	local to_target = target - source_center

	to_target.z = 0

	local world_axis_of_rotation = Vector3.cross(Vector3.normalize(to_target), Vector3.up())
	local axis_of_rotation = Quaternion.rotate(Quaternion.inverse(source_rotation), world_axis_of_rotation)
	local delta_rotation = Quaternion.axis_angle(axis_of_rotation, -math.pi / 2)
	local target_rotation = Quaternion.multiply(source_rotation, delta_rotation)

	state.fall_source_rotation = QuaternionAux.box({}, source_rotation)
	state.fall_target_rotation = QuaternionAux.box({}, target_rotation)

	local to_center = Unit.local_position(unit, Unit.node(unit, "j_center"))

	target = target + to_center

	local target_center = target
	local rotated_to_center = Quaternion.rotate(target_rotation, to_center)

	target = target - rotated_to_center
	state.fall_source_position = Vector3Aux.box({}, source)
	state.fall_target_position = Vector3Aux.box({}, target)

	local height = source.z - target.z
	local distance = Vector3.length_xy(target - source)
	local nominator = math.sqrt(GRAVITY / 2) * distance
	local denominator = math.sqrt(height)
	local speed = nominator / denominator
	local direction_of_velocity = Vector3.normalize(to_target)
	local velocity = direction_of_velocity * speed
	local x = 2 * GRAVITY * height

	state.duration = math.sqrt(x) / GRAVITY

	local velocity_box = Vector3Aux.box({}, velocity)
	local source_box = Vector3Aux.box({}, source)

	source_box.z = 0

	local target_z = target.z

	local function trajectory(t)
		local position = Vector3Aux.unbox(source_box) + Vector3Aux.unbox(velocity_box) * t
		local y = height - 0.5 * GRAVITY * t * t

		position.z = target_z + y

		return position
	end

	return trajectory
end

PushableComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set_controller" then
		state.controlling_avatar = data

		if data then
			if state.current_state == "idle" then
				self:on_pushed_enter(unit, context)
			end
		elseif state.current_state == "pushed" then
			self:on_idle_enter(unit, context)
		end
	end
end

PushableComponent.command_slave = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "connect_track" then
		state.root_track_unit = data
	end
end

local function _is_unit_in_graph(graph, unit)
	for graph_member, connections in pairs(graph) do
		if unit == graph_member then
			return true
		end
	end

	return false
end

local function _merge(graph_a, graph_b)
	for unit, connections in pairs(graph_b) do
		local existing_connections = graph_a[unit]

		if existing_connections == nil then
			graph_a[unit] = connections
		else
			graph_a[unit] = array.append(graph_a[unit], existing_connections)
		end
	end

	return graph_a
end

PushableComponent.connect_neighbor = function (self, params)
	local unit = params.unit
	local neighbor = params.neighbor

	if not Unit.alive(neighbor) then
		return
	end

	local graph_a = self.graph_lookup[unit]
	local graph_b = self.graph_lookup[neighbor]

	if graph_a then
		assert(not _is_unit_in_graph(graph_a, neighbor), "[Pushable] Trying to connect a track piece twice! (or level_loaded is triggered more than once) (unit=%t, neighbor=%t)", unit, neighbor)
	end

	if graph_b then
		assert(not _is_unit_in_graph(graph_b, unit), "[Pushable] Trying to connect a track piece twice! (or level_loaded is triggered more than once) (unit=%t, neighbor=%t)", unit, neighbor)
	end

	local graph

	if graph_a then
		graph = graph_a

		if graph_b then
			graph = _merge(graph_a, graph_b)
		else
			graph[neighbor] = {}
		end
	elseif graph_b then
		graph = graph_b
		graph[unit] = {}
	else
		graph = {
			[unit] = {},
			[neighbor] = {},
		}
	end

	graph[unit][#graph[unit] + 1] = neighbor
	graph[neighbor][#graph[neighbor] + 1] = unit
	self.graph_lookup[unit] = graph
	self.graph_lookup[neighbor] = graph

	for unit, connections in pairs(graph) do
		for i, node in ipairs(connections) do
			self.graph_lookup[node] = graph
		end
	end
end

PushableComponent.connect_pushable = function (self, params)
	local unit = params.unit
	local track_unit = params.track_unit

	if Unit.alive(track_unit) then
		EntityAux.command_slave_immediately(unit, self.name, "connect_track", track_unit)
	elseif EntityAux.owned(unit) then
		EntityAux.queue_command_master(unit, "interactable", "destroy")
	end
end
