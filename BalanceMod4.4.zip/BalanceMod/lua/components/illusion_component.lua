﻿-- chunkname: @lua/components/illusion_component.lua

IllusionComponent = class("IllusionComponent", "EnemyComponent")

IllusionComponent.init = function (self, creation_context)
	EnemyComponent.init(self, creation_context, "illusion")
	self:register_interfaces("i_speed_listener")

	self.combo = self:create_extension(Combo)
end

IllusionComponent.setup_master = function (self, unit, context, setup_info)
	EnemyComponent.setup_master(self, unit, context, setup_info)

	local state = context.state

	state.disable_target_lock_aim = true
	state.combo_input = {}

	self.combo:add_unit(unit)

	state.movespeed_multiplier_mixer = AddMixer()

	state.movespeed_multiplier_mixer:add("default", 1)

	state.movespeed_multiplier = 1
	state.next_ability_time = 0.2 + math.random() * 1.5

	local weapon_path = context.settings.weapon_path

	self.combo:build_combo(unit, weapon_path)
end

IllusionComponent.setup_slave = function (self, unit, context, setup_info)
	Unit.flow_event(unit, "on_avatar_spawn")

	local outline_color = Color.from_normalized_rgba(1, 0, 0, 0)

	MaterialAux.set_color(unit, nil, nil, "outline_color", outline_color, true)

	local state = context.state

	state.speed_variable = Unit.animation_find_variable(unit, "move_speed")
	state.charge_variable = Unit.animation_find_variable(unit, "charge_amount")
	state.windup_amount = 0
end

IllusionComponent.remove_master = function (self, unit, context)
	EnemyComponent.remove_master(self, unit, context)
	self.combo:remove_unit(unit)
end

IllusionComponent.remove_slave = function (self, unit, context)
	return
end

IllusionComponent.handle_death = function (self, unit, context)
	if EntityAux.owned(unit) then
		EntityAux.queue_command_master(unit, "rotation", "disable", "death")
	else
		EntityAux.queue_command(unit, "motion", "set_override_movement", true)
		EntityAux.queue_command(unit, "rotation", "set_override_rotation", true)
	end

	self:queue_command(unit, "rotation", "rotate_towards_unit", nil)
	self:queue_command(unit, "ability", "set_enabled", false)
end

IllusionComponent.post_update = function (self, dt)
	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(slave_entities) do
		local state = context.state
		local velocity

		if EntityAux.has_component_master(unit, "motion") then
			velocity = MotionState.get_velocity(EntityAux.state_master(unit, "motion").motion_state)
		else
			velocity = Vector3Aux.unbox(EntityAux.state(unit, "motion").velocity)
		end

		local move_speed = math.clamp(Vector3.length(velocity), 0, context.settings.animation_movespeed_max)

		Unit.animation_set_variable(unit, state.speed_variable, move_speed)

		if state.charge_variable and state.previous_windup_amount ~= state.windup_amount then
			state.previous_windup_amount = state.windup_amount

			Unit.animation_set_variable(unit, state.charge_variable, math.clamp(state.windup_amount, 0, 1))
			Unit.set_flow_variable(unit, "charge_amount", state.windup_amount)
			Unit.flow_event(unit, "charge_amount_updated")
		end
	end
end

IllusionComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "add_speed_multiplier" then
		local id = data.id

		state.movespeed_multiplier_mixer:add(id, data.value)

		state.movespeed_multiplier = state.movespeed_multiplier_mixer:get()
	elseif command_name == "remove_speed_multiplier" then
		state.movespeed_multiplier_mixer:remove(data)

		state.movespeed_multiplier = state.movespeed_multiplier_mixer:get()
	else
		EnemyComponent.command_master(self, unit, context, command_name, data)
	end
end

local function _noop()
	return
end

IllusionComponent.rpc_start_decay = _noop
IllusionComponent.rpc_enemy_awaken = _noop
IllusionComponent.rpc_initiate_boss = _noop
IllusionComponent.update_slaves = _noop
