﻿-- chunkname: @gameobjects/relics/swirling_vortex_trap_tier3.lua

local t = SettingsAux.override_settings("gameobjects/relics/swirling_vortex_trap_tier2", {
	lifetime = 300,
})

return t
