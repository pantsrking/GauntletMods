﻿-- chunkname: @equipment/warrior/weapon02.lua

return SettingsAux.override_settings("equipment/warrior/weapon01", {})
