﻿-- chunkname: @equipment/warrior/weapon10.lua

return SettingsAux.override_settings("equipment/warrior/weapon11", {})
