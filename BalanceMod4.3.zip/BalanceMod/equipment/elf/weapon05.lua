﻿-- chunkname: @equipment/elf/weapon05.lua

return SettingsAux.override_settings("equipment/elf/weapon01", {})
