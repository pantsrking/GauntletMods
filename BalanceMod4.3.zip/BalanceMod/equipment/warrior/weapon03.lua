﻿-- chunkname: @equipment/warrior/weapon03.lua

return SettingsAux.override_settings("equipment/warrior/weapon01", {})
