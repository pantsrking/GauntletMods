﻿-- chunkname: @lua/components/connected_stream_component.lua

require("foundation/lua/component/base_component")

ConnectedStreamComponent = class("ConnectedStreamComponent", "BaseComponent")

ConnectedStreamComponent.init = function (self, creation_context)
	BaseComponent.init(self, "connected_stream", creation_context, true)
	self:register_flow_events("connect_previous", "start_stream")
end

ConnectedStreamComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.next_entity = nil
	state.is_playing = false
	state.progress = 0
end

ConnectedStreamComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.previous_progress = 0
	state.animation_played = false
end

ConnectedStreamComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.is_playing then
			local info = context.settings.stream_info
			local duration = Unit.get_data(unit, "duration") or info.duration / 30

			state.progress = math.clamp((_G.GAME_TIME - state.start_time) / duration, 0, 1)

			if state.progress == 1 then
				state.is_playing = false

				Unit.flow_event(unit, "done")

				if state.next_entity then
					self:queue_command_master(state.next_entity, self.name, "start")
				end
			end
		end
	end
end

ConnectedStreamComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, p_state = context.state, context.prediction_state

		state.progress = math.move_towards(p_state.previous_progress or state.progress, state.progress, 1, dt)
		p_state.previous_progress = state.progress
	end
end

ConnectedStreamComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings
		local dirty = not math.equals(state.previous_progress, state.progress)

		if dirty then
			state.previous_progress = state.progress

			local info = settings.stream_info

			if not state.animation_played and not info.is_looping then
				Unit.flow_event(unit, "play")
			end

			state.animation_played = true

			if info.animate_material_scalar then
				MaterialAux.set_scalar(unit, nil, info.animate_material_scalar, "fill_amount", state.progress, true)
			end
		end
	end
end

ConnectedStreamComponent.command_master = function (self, unit, context, command_name, data)
	local state, settings = context.state, context.settings

	if command_name == "start" then
		if settings.stream_started then
			settings.stream_started(unit, context, self)
		end

		state.is_playing = true
		state.start_time = _G.GAME_TIME
	elseif command_name == "connect_previous" then
		self:queue_command_master(data, self.name, "connect_next", unit)
	elseif command_name == "connect_next" then
		state.next_entity = data
	end
end

ConnectedStreamComponent.connect_previous = function (self, params)
	local unit = params.unit

	if EntityAux.has_component_master(unit, self.name) and Unit.alive(params.previous) then
		EntityAux.command_master_immediately(unit, self.name, "connect_previous", params.previous)
	end
end

ConnectedStreamComponent.start_stream = function (self, params)
	local unit = params.unit

	if EntityAux.has_component_master(unit, self.name) then
		EntityAux.queue_command_master(unit, self.name, "start")
	end
end
