﻿-- chunkname: @lua/components/positioning_component.lua

require("foundation/lua/component/base_component")

PositioningComponent = class("PositioningComponent", "BaseComponent")

PositioningComponent.init = function (self, creation_context)
	BaseComponent.init(self, "positioning", creation_context)
end

PositioningComponent.reload_master = function (self, unit, context)
	context.num_commands = 0
end

PositioningComponent.update = function (self, dt)
	local entities = self.entity_manager:get_master_entities(self.name)

	for unit, context in pairs(entities) do
		if context.state.active then
			local state = context.state
			local info = state.positioning_data
			local source_rotation = QuaternionAux.unbox(info.source_rotation)
			local source_position = Vector3Aux.unbox(info.source_position)
			local target_rotation = QuaternionAux.unbox(info.target_rotation)
			local target_position = Vector3Aux.unbox(info.target_position)
			local now = _G.GAME_TIME

			if now < info.start_time + info.duration then
				local timer = now - info.start_time

				if info.translation_window then
					local translation_timer = timer - info.translation_window[1]
					local t = math.saturate(translation_timer / (info.translation_window[2] - info.translation_window[1]))
					local slerp = -2 * t * t * t + 3 * t * t
					local position = Vector3.lerp(source_position, target_position, slerp)

					EntityAux.queue_command_master(unit, "motion", "set_position", position)
				end

				if info.rotation_window then
					local rotation_timer = timer - info.rotation_window[1]
					local t = math.saturate(rotation_timer / (info.rotation_window[2] - info.rotation_window[1]))
					local slerp = -2 * t * t * t + 3 * t * t
					local rotation = Quaternion.lerp(source_rotation, target_rotation, slerp)

					EntityAux.queue_command_master(unit, "rotation", "set_rotation", rotation)
				end
			else
				state.active = false

				EntityAux.queue_command_master(unit, "motion", "set_position", target_position)
				EntityAux.queue_command_master(unit, "rotation", "set_rotation", target_rotation)
			end
		end
	end
end

PositioningComponent.call_master_start_positioning = function (self, unit, context, data)
	local state = context.state
	local source_rotation = QuaternionAux.box({}, Unit.local_rotation(unit, 0))
	local source_position = Vector3Aux.box({}, Unit.local_position(unit, 0))
	local target_rotation = QuaternionAux.box({}, data.target_rotation)
	local target_position = Vector3Aux.box({}, data.target_position)
	local positioning_settings = data.settings
	local translation_window = positioning_settings.translation_window

	translation_window = translation_window and {
		translation_window[1] / 30,
		translation_window[2] / 30,
	}

	local rotation_window = positioning_settings.rotation_window

	rotation_window = rotation_window and {
		rotation_window[1] / 30,
		rotation_window[2] / 30,
	}
	state.positioning_data = {
		duration = positioning_settings.duration / 30,
		start_time = _G.GAME_TIME,
		translation_window = translation_window,
		rotation_window = rotation_window,
		source_rotation = source_rotation,
		source_position = source_position,
		target_rotation = target_rotation,
		target_position = target_position,
		settings = positioning_settings,
	}
	state.active = true

	if positioning_settings.animation_event then
		EntityAux.queue_command_master(unit, "animation", "trigger_event", positioning_settings.animation_event)
	end
end
