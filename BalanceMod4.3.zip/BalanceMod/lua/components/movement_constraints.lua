﻿-- chunkname: @lua/components/movement_constraints.lua

require("lua/managers/camera_manager")
require("lua/dungeon/nav_grid")

MovementConstraints = MovementConstraints or {}

MovementConstraints.navgrid_constrain = function (component, unit, position, translation)
	local target_position = position + translation
	local radius = 0.4
	local new_position, normal = component.nav_grid:sweep_circle(position, target_position, radius)

	if normal then
		local norm_translation = Vector3.normalize(translation)
		local dot = Vector3.dot(normal, norm_translation)

		if dot < 0 then
			local vector = dot * normal
			local to_head = norm_translation - vector
			local new_translation = Vector3.normalize(to_head) * Vector3.length(translation)

			target_position = position + new_translation
			new_position, normal = component.nav_grid:sweep_circle(position, target_position, radius)
		end
	end

	return new_position - position
end

local FIND_CLOSEST_CELL_MAX_RADIUS = 15

MovementConstraints.navgrid_teleport = function (component, unit, position)
	return component.nav_grid:move_to_where_we_can_stand(position, nil, FIND_CLOSEST_CELL_MAX_RADIUS)
end

MovementConstraints.camera_constrain = function (component, unit, position, translation, dt)
	if CameraManager:get_state() ~= "follow" then
		return translation
	end

	local planes = CameraManager:get_frustum_planes()
	local cam_dirs = CameraManager:get_frustum_dirs_2D(TempTableFactory:get())
	local target_position = position + translation
	local px, py, pz = Vector3.to_elements(target_position)
	local tx, ty, tz = Vector3.to_elements(translation)
	local SOFT_CUTOFF = CameraManager.PLAYER_SLOWDOWN_SOFT_CUTOFF
	local HARD_CUTOFF = CameraManager.PLAYER_SLOWDOWN_HARD_CUTOFF

	for pi = 3, 6 do
		local nx, ny, nz, pd = Quaternion.to_elements(planes[pi])
		local insideness = px * nx + py * ny + pz * nz - pd

		if insideness < SOFT_CUTOFF then
			local dir = cam_dirs[pi]
			local dot = dir.x * tx + dir.y * ty

			if dot > 0 then
				local strength = math.saturate(math.scale_to_01(insideness, SOFT_CUTOFF, HARD_CUTOFF))

				tx = tx - dir.x * dot * strength
				ty = ty - dir.y * dot * strength
			end
		end
	end

	return Vector3(tx, ty, tz)
end

local Unit_mover = Unit.mover
local Mover_move = Mover.move
local Mover_position = Mover.position
local Mover_set_position = Mover.set_position

MovementConstraints.mover_move = function (component, unit, position, translation, dt)
	local mover = Unit_mover(unit)

	Mover_move(mover, translation, dt)

	local new_position = Mover_position(mover)

	return new_position - position
end

MovementConstraints.mover_teleport = function (component, unit, position)
	local mover = Unit_mover(unit)

	if mover then
		Mover_set_position(mover, position)

		return Mover_position(mover)
	end

	return position
end

MovementConstraints.simple_mover_move = function (component, unit, position, translation, context)
	local mover_world = component.simple_mover_world

	return SimpleMoverWorld.constrain_translation(mover_world, unit, translation)
end

MovementConstraints.simple_mover_teleport = function (component, unit, position, context)
	local mover_world = component.simple_mover_world

	SimpleMoverWorld.set_position(mover_world, unit, position)
end

local PLANE_CACHE_DURATION = 0.25

MovementConstraints.ground_constrain = function (component, unit, position, translation, context)
	local new_position = position + translation
	local state = context.state
	local plane = state.plane

	if plane == nil then
		plane = {
			position = {
				x = 0,
				y = 0,
				z = 0,
			},
			normal = {
				x = 0,
				y = 0,
				z = 0,
			},
			time_to_recreate = _G.GAME_TIME,
		}
	end

	state.plane = plane

	if _G.GAME_TIME >= plane.time_to_recreate then
		plane.time_to_recreate = _G.GAME_TIME + PLANE_CACHE_DURATION
		plane.valid = true
		plane.is_slope = false

		local any_hit, hit_position, hit_distance, hit_normal, _ = component:raycast_ground(unit, new_position, context)

		if any_hit then
			if hit_distance == 0 then
				translation.z = 0
			else
				translation.z = hit_position.z - position.z

				Vector3Aux.box(plane.normal, hit_normal)
				Vector3Aux.box(plane.position, hit_position)

				plane.is_slope = Vector3.dot(hit_normal, Vector3.up()) < 0.9
			end

			state.down_ray_hit = true

			Vector3Aux.box(state.last_ground_position, hit_position)
		else
			local length = Vector3.length(translation)
			local normalized_translation = Vector3.normalize(translation)

			any_hit, hit_position, _, hit_normal, _ = component:raycast(position, normalized_translation, length)

			if any_hit then
				translation = hit_position - position

				Vector3Aux.box(plane.normal, hit_normal)
				Vector3Aux.box(plane.position, hit_position)

				state.down_ray_hit = true

				Vector3Aux.box(state.last_ground_position, hit_position)

				plane.is_slope = Vector3.dot(hit_normal, Vector3.up()) < 0.9
			else
				plane.valid = false
				state.down_ray_hit = false
			end
		end
	elseif plane.valid then
		local plane_normal = Vector3Aux.unbox(plane.normal)
		local plane_position = Vector3Aux.unbox(plane.position)

		state.down_ray_hit = true

		Vector3Aux.box(state.last_ground_position, plane_position)

		if plane.is_slope then
			translation.z = 0

			local length = Vector3.length(translation)

			translation = Vector3Aux.project_onto(translation, plane_normal)
			translation = Vector3.normalize(translation) * length
			plane_position.z = plane_position.z + translation.z
		else
			translation.z = plane_position.z - position.z
		end
	end

	return translation
end

MovementConstraints.ground_teleport = function (component, unit, position, context)
	local any_hit, hit_position, hit_distance, hit_normal, hit_actor = component:raycast_ground(unit, position, context)

	return any_hit and hit_position or position
end
