﻿-- chunkname: @lua/components/trap_component.lua

require("foundation/lua/component/base_component")

TrapComponent = class("TrapComponent", "BaseComponent")

TrapComponent.init = function (self, creation_context)
	BaseComponent.init(self, "trap", creation_context)
	self:register_interfaces("i_trap")
	self:register_dependencies("ability")
end

TrapComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.active = Unit.get_data(unit, "start_active") or false
end

TrapComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	state.previous_active = false
	state.previous_enable = nil
end

TrapComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings
		local dirty = state.previous_active ~= state.active

		state.previous_active = state.active

		if dirty then
			local event, timer

			if state.active then
				timer = settings.trap_activate(unit, context, self, EntityAux.owned(unit))
				event = "trap_start"
			else
				timer = settings.trap_deactivate(unit, context, self, EntityAux.owned(unit))
				event = "trap_stop"
			end

			state.delayed_event = {
				event = event,
				timer = timer,
			}
		end

		if state.delayed_event then
			local d_event = state.delayed_event

			d_event.timer = d_event.timer - dt

			if d_event.timer <= 0 then
				state.delayed_event = nil

				settings[d_event.event](unit, context, self, EntityAux.owned(unit))
			end
		end
	end
end

TrapComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "activate" then
		state.active = true
	elseif command_name == "deactivate" then
		state.active = false
	end
end
