﻿-- chunkname: @lua/components/interactor_component.lua

require("foundation/lua/managers/broadphase_manager")
require("foundation/lua/input/input_manager")
require("foundation/lua/component/base_component")
require("foundation/lua/debug/plugin_component_aux")
require("foundation/lua/gui/gui")
require("lua/components/interactable_component")

InteractorComponent = class("InteractorComponent", "BaseComponent")

InteractorComponent.init = function (self, creation_context)
	BaseComponent.init(self, "interactor", creation_context)
	self:register_dependencies("interactable")

	self.hud = creation_context.hud

	self:register_events("on_entity_unregistering", "on_death", "on_interact_result", "on_pickup_result")
end

InteractorComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings

	if settings.interactor_radius then
		state.radius = settings.interactor_radius
	else
		local extents = UnitAux.unit_extents(unit)

		state.radius = math.max(extents.x, extents.y)
		state.radius = math.max(state.radius, 0.5)
	end

	if state.best_interactable_info.active then
		local i_unit = state.best_interactable_info.interactable_unit

		state.best_interactable_info.settings = LuaSettingsManager:get_settings_by_unit(i_unit)
	end
end

InteractorComponent.setup_master = function (self, unit, context)
	local state = context.state

	state.enabled = true
	state.best_interactable_info = {}
	state.ignore_interactables = {}

	self:reload_master(unit, context)
end

InteractorComponent.send_request = function (self, unit, state, interactable_unit, interactable_settings, predicted_result)
	local interactable_owner = EntityAux.owner(interactable_unit)

	if interactable_settings.require_busy == true or interactable_settings.require_waiting_for_request_results then
		state.busy = interactable_settings.require_busy == true
		state.waiting_for_request_results = interactable_unit
		state.request = {
			timeout = _G.GAME_TIME + Network.ping(interactable_owner) * 2 + 0.2,
			predicted_result = predicted_result,
			interactable_unit = interactable_unit,
		}
	end

	state.interactable_settings = interactable_settings

	if interactable_owner == Network.peer_id() then
		local command = TempTableFactory:get_map("interactor_unit", unit, "expected_result", predicted_result)

		self:queue_command_master(interactable_unit, "interactable", "interact_request", command)
	else
		local settings_path = LuaSettingsManager:get_settings_path_by_unit_path(Unit.get_data(interactable_unit, "unit_path"))

		self:trigger_rpc_event_to(interactable_owner, "rpc_interact_request", interactable_unit, unit, predicted_result, settings_path)

		if interactable_settings.require_migration and predicted_result == InteractableComponent.RESULT_SUCCESS then
			self:queue_command_predictor(interactable_unit, "interactable", "pending_interact_migration", unit)
		end
	end
end

InteractorComponent.update = function (self, dt)
	Profiler.start(self.name)

	local master_entities = self.entity_manager:get_master_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

InteractorComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.enabled then
			if state.waiting_for_request_results then
				if _G.GAME_TIME > state.request.timeout then
					local interactable_unit = state.waiting_for_request_results

					self:send_request(unit, state, interactable_unit, state.interactable_settings, state.request.predicted_result)
				end
			else
				local current_info = state.best_interactable_info

				if current_info.active then
					local interactable_unit = current_info.interactable_unit
					local interactable_state = current_info.state
					local interactable_settings = current_info.settings
					local do_interact

					if interactable_settings.interact_on_contact and current_info.new_interactable then
						do_interact = current_info.new_interactable
						current_info.new_interactable = false
					else
						do_interact = state.do_interact
					end

					if interactable_state.enabled and do_interact then
						local can_interact = interactable_settings.interactor_can_interact(self, unit, interactable_unit, state)
						local predicted_result = interactable_settings.interactor_predict_result(self, unit, interactable_unit, can_interact)

						if can_interact or predicted_result then
							if can_interact and predicted_result == nil then
								predicted_result = InteractableComponent.REQUEST_SUCCESS
							end

							self:send_request(unit, state, interactable_unit, interactable_settings, predicted_result)
						end
					end
				end
			end

			self:check_interactable_overlaps(unit, context)
		end

		state.do_interact = false
	end
end

InteractorComponent.check_interactable_overlaps = function (self, unit, context)
	local state = context.state
	local ignore_interactables = state.ignore_interactables
	local my_position = UnitAux.unit_center(unit)
	local my_direction = Quaternion.forward(Unit.world_rotation(unit, 0))
	local best_distance = -math.huge
	local best_interactable
	local result = TempTableFactory:get()

	BroadphaseManager:query(InteractableComponent.BROADPHASE_ID, my_position, state.radius, result)

	for _, interactable_unit in ipairs(result) do
		repeat
			if unit == interactable_unit then
				break
			end

			if ignore_interactables[interactable_unit] then
				break
			end

			local pickup_state = EntityAux.state(interactable_unit, "pickup")

			if pickup_state then
				local pickup_unit = interactable_unit

				ignore_interactables[pickup_unit] = true

				local settings = LuaSettingsManager:get_settings_by_unit(pickup_unit)
				local can_pickup = settings.interactor_can_pickup(self, unit, pickup_unit, state)
				local predicted_result = settings.interactor_predict_result(self, unit, pickup_unit, can_pickup)

				if can_pickup or predicted_result then
					local pickup_owner = EntityAux.owner(pickup_unit)

					if pickup_owner == Network.peer_id() then
						EntityAux.call_master(pickup_unit, "pickup", "pickup_request", unit)

						break
					end

					local settings_path = LuaSettingsManager:get_settings_path_by_unit_path(Unit.get_data(pickup_unit, "unit_path"))

					self:trigger_rpc_event_to(pickup_owner, "rpc_pickup_request", pickup_unit, unit, settings_path)
				end

				break
			end

			local interactable_state = EntityAux.state(interactable_unit, "interactable")

			if not interactable_state or not interactable_state.enabled then
				break
			end

			local position = UnitAux.unit_center(interactable_unit)
			local delta = position - my_position
			local projected_distance = Vector3.dot(delta, my_direction)

			if best_distance < projected_distance then
				best_interactable = interactable_unit
				best_distance = projected_distance
			end
		until true
	end

	for ignore_unit, _ in pairs(ignore_interactables) do
		local exists = false

		for _, interactable_unit in ipairs(result) do
			if interactable_unit == ignore_unit then
				exists = true

				break
			end
		end

		if not exists then
			ignore_interactables[ignore_unit] = nil
		end
	end

	local info = state.best_interactable_info

	if best_interactable then
		if info.interactable_unit ~= best_interactable then
			info.new_interactable = true

			if info.interactable_unit then
				Unit.flow_event(info.interactable_unit, "on_interactor_exit")
			end

			Unit.flow_event(best_interactable, "on_interactor_enter")
		end

		info.settings = LuaSettingsManager:get_settings_by_unit(best_interactable)
		info.state = EntityAux.state(best_interactable, "interactable")
	elseif info.interactable_unit ~= nil then
		Unit.flow_event(info.interactable_unit, "on_interactor_exit")
	end

	info.interactable_unit = best_interactable
	info.active = best_interactable ~= nil
end

InteractorComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "interact" then
		state.do_interact = true
	elseif command_name == "set_locked" then
		state.locked = data
		state.enabled = not data

		if not state.enabled then
			state.best_interactable_info.active = false
		end
	elseif command_name == "add_ignore_interactable" then
		local ignores = state.ignore_interactables

		ignores[data] = true
	elseif command_name == "remove_ignore_interactable" then
		local ignores = state.ignore_interactables

		ignores[data] = nil
	elseif command_name == "request_results_received" then
		local interactable_unit = data.interactable_unit
		local interactable_settings_path = data.interactable_settings_path

		if state.waiting_for_request_results == nil or state.waiting_for_request_results == interactable_unit then
			local settings

			if interactable_settings_path then
				settings = LuaSettingsManager:get_settings_by_settings_path(interactable_settings_path)
			else
				settings = LuaSettingsManager:get_settings_by_unit(interactable_unit)
			end

			local result = data.result

			if result == InteractableComponent.RESULT_SUCCESS then
				settings.interactor_interact_result(self, unit, interactable_unit, state)
			elseif settings.interactor_interact_failed then
				settings.interactor_interact_failed(self, unit, interactable_unit, state)
			end

			state.busy = false
			state.waiting_for_request_results = nil
		end
	elseif command_name == "disable" then
		state.enabled = false
	elseif command_name == "enable" then
		state.enabled = true
	elseif command_name == "plugin_draw" then
		state.plugin_draw = not state.plugin_draw
	end
end

InteractorComponent.on_entity_unregistering = function (self, destroyed_unit)
	self:_handle_entity_removal(destroyed_unit, true)
end

InteractorComponent.on_death = function (self, dead_unit)
	self:_handle_entity_removal(dead_unit, false)
end

InteractorComponent._handle_entity_removal = function (self, entity, is_unregistering)
	if EntityAux.has_component(entity, "interactable") then
		for unit, context in self.entity_manager:all_masters_iterator(self.name) do
			local state = context.state
			local info = state.best_interactable_info

			if state.waiting_for_request_results == entity and is_unregistering then
				self:command_master(unit, context, "request_results_received", TempTableFactory:get_map("interactable_unit", entity, "result", InteractableComponent.RESULT_INTERACT_DISABLED))
			end

			if info.interactable_unit == entity then
				table.clear(info)
			end
		end
	end

	if EntityAux.has_component_master(entity, self.name) then
		self:queue_command_master(entity, self.name, "disable", true)
	end
end

InteractorComponent.on_interact_result = function (self, interactable_unit, interactor_unit, result, interactable_settings_path)
	if not interactor_unit then
		return
	end

	if not EntityAux.has_component_master(interactor_unit, self.name) then
		return
	end

	EntityAux.command_master_immediately(interactor_unit, self.name, "request_results_received", TempTableFactory:get_map("interactable_unit", interactable_unit, "result", result, "interactable_settings_path", interactable_settings_path))
end

InteractorComponent.on_pickup_result = function (self, pickup_unit, interactor_unit, success, pickup_settings_path)
	if not interactor_unit then
		return
	end

	if not EntityAux.has_component_master(interactor_unit, self.name) then
		return
	end

	local settings

	if pickup_settings_path then
		settings = LuaSettingsManager:get_settings_by_settings_path(pickup_settings_path)
	else
		settings = LuaSettingsManager:get_settings_by_unit(pickup_unit)
	end

	local state = EntityAux._state_master_raw(interactor_unit, self.name)

	if success then
		settings.interactor_pickup_result(self, interactor_unit, pickup_unit, state)
	elseif settings.interactor_pickup_failed then
		settings.interactor_pickup_failed(self, interactor_unit, pickup_unit, state)
	end
end

InteractorComponent.setup_console_plugin = function (self)
	local plugin = {
		interactor = function (argument_array, command_string)
			if argument_array[2] == "draw" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Interactor debug draw toggled for %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "plugin_draw", true, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		interactor = {
			"draw",
		},
	}
	local docs = {
		interactor = {
			text = "Shows interaction debug information.",
			draw = {
				text = "Renders the interactor volume.",
				usage = "draw [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end

local KEY_TO_LOC = {
	backspace = "loc_key_backspace",
	["break"] = "loc_key_break",
	["caps lock"] = "loc_key_caps_lock",
	clear = "loc_key_clear",
	["context menu"] = "loc_key_context_menu",
	delete = "loc_key_delete",
	["end"] = "loc_key_end",
	enter = "loc_key_enter",
	esc = "loc_key_esc",
	home = "loc_key_home",
	insert = "loc_key_insert",
	["left alt"] = "loc_key_left_alt",
	["left ctrl"] = "loc_key_left_ctrl",
	["left shift"] = "loc_key_left_shift",
	["left win"] = "loc_key_left_win",
	["num lock"] = "loc_key_num_lock",
	["numpad enter"] = "loc_key_numpad_enter_2",
	["page down"] = "loc_key_page_down",
	["page up"] = "loc_key_page_up",
	pause = "loc_key_pause",
	["print screen"] = "loc_key_print_screen",
	["right alt"] = "loc_key_right_alt",
	["right ctrl"] = "loc_key_right_ctrl",
	["right shift"] = "loc_key_right_shift",
	["right win"] = "loc_key_right_win",
	space = "loc_key_space",
	tab = "loc_key_tab",
}

InteractorComponent.button_has_translation = function (button_index)
	local key = Keyboard.button_name(button_index)

	if key then
		if KEY_TO_LOC[key] then
			return true
		elseif key == "up" or key == "down" or key == "right" or key == "left" then
			return true
		else
			local numpad_sign = key:match("^numpad .$")

			if numpad_sign then
				return true
			else
				local text = Keyboard.button_locale_name(button_index)
				local length = Utf8.length(text)

				return length == 1
			end
		end
	else
		return false
	end
end

local controller_lookups = require("lua/settings/controller_lookups")

local function get_text_icon_for(key_map, value, device_map)
	local key = controller_lookups.reverse_key(value.key) or controller_lookups.reverse_key(value.alt_key)

	if value.key == "FilterInputButtonCombiner" then
		if value.input[1] then
			local index = array.find(key_map, value.input[1], "output_name")

			if index then
				value = key_map[index]
				key = value.key or value.alt_key
			else
				return nil
			end
		end
	elseif value.key == "FilterOnModifier" then
		key = value.input.input
	end

	local text, icon
	local is_arrowkey = false

	if value.func == "sc_button" then
		text = Keyboard.scan_code_name(value.scan_code)
		icon = "hud_button_key"
	elseif value.key == "FilterTriggerAsButton" then
		local key = value.input.trigger

		icon = sprintf("hud_button_%s", key)
	elseif value.controller_type == "keyboard" or value.controller_type == nil then
		if key then
			if KEY_TO_LOC[key] then
				text = tr(KEY_TO_LOC[key])
			elseif key == "up" or key == "down" or key == "right" or key == "left" then
				text = ""
				is_arrowkey = true
			else
				local numpad_sign = key:match("^numpad (.*)$")

				if numpad_sign then
					text = tr_format("loc_key_numpad", "#SYMBOL", numpad_sign)
				else
					local button_index = Keyboard.button_index(key)

					text = Utf8.upper(Keyboard.button_locale_name(button_index))
				end
			end
		else
			text = "??"

			return text, "hud_button_widekey"
		end

		if is_arrowkey then
			icon = "hud_button_key_" .. key
		else
			local length = Utf8.length(text)

			if length == 1 then
				icon = "hud_button_key"
			elseif length < 5 then
				icon = "hud_button_widekey"
			else
				icon = "hud_button_spacebar"
			end
		end
	elseif value.controller_type == "pad" then
		if IS_PS4 then
			key = ControllerSettings.remote_play_remap_menu_key(device_map, key)
		end

		if value.func == "axis" then
			icon = sprintf("hud_axis_%s", key)
		else
			icon = sprintf("hud_button_%s", key)
		end
	elseif value.controller_type == "mouse" then
		local is_left_handed = Mouse.left_handed_mouse and Mouse.left_handed_mouse()

		if key == "left" then
			icon = is_left_handed and "hud_button_rmb" or "hud_button_lmb"
		elseif key == "middle" then
			icon = "hud_button_mmb"
		elseif key == "right" then
			icon = is_left_handed and "hud_button_lmb" or "hud_button_rmb"
		elseif key == "extra_1" then
			icon = "hud_button_mb"
			text = "4"
		elseif key == "extra_2" then
			icon = "hud_button_mb"
			text = "5"
		elseif key == "extra_3" then
			icon = "hud_button_mb"
			text = "6"
		elseif key == "extra_4" then
			icon = "hud_button_mb"
			text = "7"
		elseif key == "extra_5" then
			icon = "hud_button_mb"
			text = "8"
		elseif key == nil then
			icon = "hud_button_widekey"
			text = "??" or text
		end
	end

	return text, icon
end

InteractorComponent.get_visual_for_button = function (user_name, input_name, interface_name)
	if not user_name then
		return
	end

	Profiler.start("get_visual_for_button")

	interface_name = interface_name or "character"

	local device_map = InputManager:get_user_device_map(user_name)
	local key_map

	if InputManager:has_interface(user_name, interface_name) then
		key_map = InputManager:get_interface_key_map(user_name, interface_name)
	else
		local keyboard_user = InputManager:get_user_device_map(user_name) == InputManager.KEYBOARD_MOUSE

		key_map = InputRebinder:get(keyboard_user and "keyboard" or "pad")
	end

	for _, value in ipairs(key_map) do
		if value.output_name == input_name then
			local text, icon = get_text_icon_for(key_map, value, device_map)

			if text or icon then
				Profiler.stop()

				return text, icon
			end
		end
	end

	Profiler.stop()
end

InteractorComponent.set_widget_visual_for_button = function (widget, user_name, input_name, interface_name)
	Profiler.start("set_widget_visual_for_button")

	interface_name = interface_name or "character"

	local text, icon = InteractorComponent.get_visual_for_button(user_name, input_name, interface_name)

	if icon then
		if text and Utf8.length(text) > 1 then
			local w, h = widget:get_size()
			local font = "fonts/default"
			local font_size_px = h - 5
			local gui_im = GUI:get_gui_im()
			local _, max_px, _, _ = Gui.text_extents(gui_im, text, font, font_size_px)

			widget:set_size({
				math.max(w, max_px.x),
				h,
			})
		else
			local w, h = widget:get_size()

			widget:set_size({
				h,
				h,
			})
		end

		widget:set_text(text or "")
		widget:set_bg_img(icon)
	elseif text then
		widget:set_text(text)
		widget:set_bg_img(nil)
	end

	Profiler.stop()
end

InteractorComponent.draw_button_bitmap = function (gui_im, color, pos_px, size_px, user_name, interface_name, input_name, icon)
	if not Gui.material(gui_im, icon) then
		return
	end

	pos_px = Vector3.copy(pos_px)
	pos_px.y = pos_px.y - 2

	Gui.bitmap(gui_im, icon, pos_px, size_px, color)
end

InteractorComponent.draw_visual_for_button = function (gui_im, color, pos_px, size_px, user_name, input_name, input_modifier, interface_name)
	gui_im = gui_im or GUI:get_gui_im()
	color = color or Color(255, 255, 255, 255)
	interface_name = interface_name or "character"

	local text, icon = InteractorComponent.get_visual_for_button(user_name, input_name, interface_name)
	local return_size = Vector2(0, 0)

	if icon and Gui.material(gui_im, icon) then
		if text then
			size_px.x = size_px.y * 1.2

			local text_length = Utf8.length(text)

			if text_length > 1 then
				size_px.x = size_px.x + text_length * 6
			end
		end

		local icon_pos_px = pos_px - 0.5 * size_px

		if input_modifier == "mash" then
			icon_pos_px = InteractorComponent.mash_position(icon_pos_px)
			size_px = InteractorComponent.mash_size(size_px)
		end

		InteractorComponent.draw_button_bitmap(gui_im, color, icon_pos_px, size_px, user_name, interface_name, input_name, icon)

		return_size = size_px
	end

	if text then
		local font = "fonts/default"
		local material = font:match("[^/]*$")
		local font_size_px = size_px.y - 5
		local _, max_px, _, _ = Gui.text_extents(gui_im, text, font, font_size_px)
		local w = max_px.x
		local h = max_px.y
		local text_pos_px = pos_px + 0.5 * Vector2(-w, -h)

		if icon then
			local a, _, _, _ = Quaternion.to_elements(color)

			color = Color(a, 0, 0, 0)
			text_pos_px.z = text_pos_px.z + 1
		else
			return_size = Vector2(w, 2 * h)
		end

		if input_modifier == "mash" then
			text_pos_px = InteractorComponent.mash_position(text_pos_px)
		end

		Gui.text(gui_im, text, font, font_size_px, material, text_pos_px, color)
	end

	return return_size
end

InteractorComponent.mash_position = function (starting_position)
	local mash_speed = 20
	local max_offset = 1
	local offset = math.sin(_G.GAME_TIME * mash_speed) * max_offset

	return Vector3(offset + starting_position.x, offset + starting_position.y, starting_position.z)
end

InteractorComponent.mash_size = function (starting_size)
	local mash_speed = 20
	local max_offset = 1
	local offset = math.sin(_G.GAME_TIME * mash_speed) * max_offset

	return Vector2(offset + starting_size.x, offset + starting_size.y)
end

InteractorComponent.set_menu_gamepad_button = function (user_name, widget, input_name)
	if user_name == _G.INPUT_USER_KEYBOARD_MOUSE then
		widget:set_visible(false)
	else
		widget:set_visible(true)
		InteractorComponent.set_widget_visual_for_button(widget, user_name, input_name, "menu")
	end
end
