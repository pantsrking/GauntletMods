﻿-- chunkname: @lua/components/component_aux.lua

ComponentAux = ComponentAux or {}

ComponentAux.add = function (list, unit, context)
	context.unit = unit
	context.index = #list + 1
	list[context.index] = context
end

ComponentAux.remove = function (list, context)
	if context.index < #list then
		local last_entry = list[#list]

		last_entry.index = context.index
		list[last_entry.index] = last_entry
		list[#list] = nil
	else
		list[context.index] = nil
	end
end
