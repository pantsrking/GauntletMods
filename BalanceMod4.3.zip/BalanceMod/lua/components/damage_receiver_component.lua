﻿-- chunkname: @lua/components/damage_receiver_component.lua

require("lua/managers/entity_event_modifier_manager")
require("lua/components/base_damage_receiver_component")

DamageReceiverComponent = class("DamageReceiverComponent", "BaseDamageReceiverComponent")

DamageReceiverComponent.init = function (self, creation_context)
	BaseDamageReceiverComponent.init(self, creation_context, "damage_receiver")

	self.despawner = creation_context.despawner

	self:register_events("on_party_changed")

	self.players_count = 1
end

DamageReceiverComponent.setup_master = function (self, unit, context, setup_info)
	BaseDamageReceiverComponent.setup_master(self, unit, context, setup_info)

	local state = context.state

	state.max_hitpoints = self:get_max_hitpoints(context, self.players_count)
	state.hitpoints = setup_info and setup_info.hitpoints or state.max_hitpoints
	state.hitpoints, state.max_hitpoints = self:get_hitpoints(context, self.players_count)
end

DamageReceiverComponent.setup_slave = function (self, unit, context, setup_info)
	BaseDamageReceiverComponent.setup_slave(self, unit, context, setup_info)

	local state = context.state

	state.max_hitpoints = self:get_max_hitpoints(context, self.players_count)
end

DamageReceiverComponent.apply_authorative_hit = function (self, unit, state, context, hit)
	local hit_settings = hit.settings

	if state.hitpoints <= 0 or hit.blocked and not hit_settings.damage_despite_blocking then
		return true
	end

	local damage_amount = math.round(hit_settings.heal_amount and -hit_settings.heal_amount or hit.damage_amount)

	if not hit.is_remote_hit and hit.allow_instakill ~= false or hit.stat_creditor_go_id == nil then
		local settings = context.settings

		if hit_settings.instakill then
			damage_amount = state.max_hitpoints
		end

		if settings.instakill_on then
			for key, val in pairs(settings.instakill_on) do
				if hit_settings[key] == val then
					damage_amount = state.max_hitpoints
				end
			end
		end
	end

	if hit.is_deathblow then
		damage_amount = state.max_hitpoints
	end

	self:apply_damage(unit, state, context, damage_amount, hit)

	hit.is_deathblow = state.hitpoints <= 0
	hit.modifiers.is_deathblow = hit.is_deathblow
end

DamageReceiverComponent.apply_damage = function (self, unit, state, context, damage, hit)
	if state.hitpoints == 0 then
		return 0
	end

	local settings = context.settings

	if damage > 0 then
		damage = math.min(damage, settings.max_damage or state.hitpoints)
	end

	self:set_hitpoints(state, math.round(math.clamp(state.hitpoints - damage, 0, state.max_hitpoints)))

	state.dirty = true

	if hit.stat_creditor_go_id then
		local player_info = PlayerManager:get_player_info(hit.stat_creditor_go_id)

		if player_info and EntityAux.owned(player_info.player_unit) and player_info.avatar_type then
			-- Nothing
		end
	end

	if state.hitpoints <= 0 then
		state.alive = state.hitpoints > 0

		if settings.on_death_authorative then
			settings.on_death_authorative(unit, not hit.is_remote_hit, hit, self)
		end

		if hit.stat_creditor_go_id then
			if settings.increment_perk_when_killed then
				PerkManager:increment(hit.stat_creditor_go_id, settings.increment_perk_when_killed)
			end

			local player_info = PlayerManager:get_player_info(hit.stat_creditor_go_id)

			if player_info and EntityAux.owned(player_info.player_unit) and player_info.avatar_type == "wizard" then
				local victim_type = StatsComponent.unit_to_stats_damage_type(unit)

				if victim_type == "monster" then
					local status_state = EntityAux.state(unit, "status_receiver")
					local should_increment_frostweaver = status_state and (status_state.frozen or status_state.chilled)

					should_increment_frostweaver = should_increment_frostweaver or PerkManager.ICE_SPELLS[hit.ability_name]

					if should_increment_frostweaver then
						PerkManager:increment(hit.stat_creditor_go_id, "frostweaver")
					end
				end
			end
		end

		self:do_settings_death_action(unit, state, settings)
		self:handle_death_stats(unit, state, hit)
	end
end

DamageReceiverComponent.handle_death_stats = function (self, unit, state, hit)
	if EntityAux.owned(unit) then
		local victim_type = StatsComponent.unit_to_stats_damage_type(unit)

		if hit.stat_creditor_go_id then
			local player_info = PlayerManager:get_player_info(hit.stat_creditor_go_id)

			if player_info then
				local victim_settings_path = Unit.get_data(unit, "settings_path")

				self:trigger_rpc_event_to(EntityAux.owner_go_id(hit.stat_creditor_go_id), "rpc_avatar_killed_something", player_info.player_unit, victim_type, victim_settings_path, hit.ability_name, Unit.world_position(unit, 0))
			end
		end
	end
end

DamageReceiverComponent.notify_death = function (self, unit, context, hit)
	local actor = Unit.actor(unit, "a_damageable")

	if actor then
		Actor.set_collision_filter(actor, "damageable_disabled")
	end

	local settings = context.settings

	if settings.on_death_notified then
		settings.on_death_notified(unit)
	end

	self:trigger_event("pre_on_death", unit)
	self:trigger_event("on_death", unit)
	self:trigger_unit_event(unit, "unit_on_death")
	Unit.flow_event(unit, "on_death")
end

DamageReceiverComponent.get_max_hitpoints = function (self, context, players_count)
	local settings = context.settings
	local max_hitpoints = type(settings.hitpoints) == "number" and settings.hitpoints or settings.hitpoints[players_count]

	max_hitpoints = math.round(max_hitpoints)

	return max_hitpoints
end

DamageReceiverComponent.get_hitpoints = function (self, context, players_count)
	local state = context.state
	local ratio = state.hitpoints / state.max_hitpoints
	local max_hitpoints = self:get_max_hitpoints(context, self.players_count)
	local hitpoints = max_hitpoints * ratio

	return hitpoints, max_hitpoints
end

DamageReceiverComponent.on_party_changed = function (self, players, players_map, players_type, players_count)
	self.players_count = players_count > 0 and players_count or 1

	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		state.hitpoints, state.max_hitpoints = self:get_hitpoints(context, self.players_count)
		state.dirty = true
	end

	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state
		local hp

		hp, state.max_hitpoints = self:get_hitpoints(context, self.players_count)
	end
end

DamageReceiverComponent.is_alive = function (unit)
	if not Unit.alive(unit) then
		return false
	end

	if not EntityAux.has_interface(unit, "i_damage_receiver") then
		return true
	end

	local state = EntityAux.state_interface(unit, "i_damage_receiver")

	if state then
		return state.alive ~= false
	else
		return true
	end
end
