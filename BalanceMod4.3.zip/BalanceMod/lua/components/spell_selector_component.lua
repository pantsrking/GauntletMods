﻿-- chunkname: @lua/components/spell_selector_component.lua

require("foundation/lua/component/base_component")

SpellSelectorComponent = class("SpellSelectorComponent", "BaseComponent")

SpellSelectorComponent.init = function (self, creation_context)
	BaseComponent.init(self, "spell_selector", creation_context)

	self.hud = creation_context.hud

	self:register_dependencies("animation")

	self.unit_paths = creation_context.unit_paths
end

SpellSelectorComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	self:reset_spell(unit, context)

	if setup_info then
		local loadout_ids = setup_info.loadout_ids
		local item_id = loadout_ids.weapon
		local weapon_path = ItemLookup.item_id_to_path(item_id)

		state.weapon_settings = LuaSettingsManager:get_settings_by_unit_path(weapon_path)

		local spells = state.weapon_settings.spells
		local spell_lookup = self:create_spell_lookup(spells)

		state.spells = spells
		state.spell_lookup = spell_lookup

		if setup_info.spell_info then
			local spell_info = setup_info.spell_info

			state.current_spell = spell_info.current_spell
			state.active_spell = table.clone(spell_info.active_spell)
			state.hud_spell_info = state.active_spell

			self:check_spell(unit, context)

			if not state.spell_ready then
				local spell_lookup = state.spell_lookup

				state.spell_ready = state.key_to_spell_info[spell_lookup[state.current_spell]]
			end
		else
			state.hud_spell_info = state.active_spell
			state.active_spell.inputs = {
				"energy",
				"energy",
			}
		end

		self:check_spell(unit, context)
	end
end

SpellSelectorComponent.setup_slave = function (self, unit, context, setup_info)
	context.state.spell_ready = {}
end

SpellSelectorComponent.create_spell_lookup = function (self, spells)
	local spell_lookup = {}

	for key, name in pairs(spells) do
		spell_lookup[#spell_lookup + 1] = key
	end

	spell_lookup = table.make_bimap(spell_lookup)

	return spell_lookup
end

local SIZE = 20
local MATERIALS = {
	astral = "hud_element_astral",
	energy = "hud_element_energy",
	matter = "hud_element_matter",
}

SpellSelectorComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local gui_im = GUI:get_gui_im()
		local world_proxy = WorldManager:get_world_proxy("game_world")
		local viewport = world_proxy:viewport("game_viewport")
		local pos_world = Unit.local_position(unit, 0)
		local pos_pixels = viewport:world_to_screen(pos_world)
		local hud_spell_info = state.hud_spell_info
		local inputs = hud_spell_info.inputs
		local size = Vector3(SIZE, SIZE * 1.2, 0)

		pos_pixels = pos_pixels - size / 2
		pos_pixels.x = pos_pixels.x - 12
		pos_pixels.y = pos_pixels.y + 75
		pos_pixels.z = 1

		local time_since_pressed = _G.GAME_TIME - (state.hud_spell_info.last_input_time or 0)
		local speed = 3

		time_since_pressed = time_since_pressed * speed

		local t = math.saturate(4 - time_since_pressed * speed)

		if not Game.DISABLE_GUI then
			for i, input in ipairs(inputs) do
				local material_name = MATERIALS[input]

				Gui.bitmap(gui_im, material_name, pos_pixels, size, Color(t * 255, 255, 255, 255))

				pos_pixels.x = pos_pixels.x + 24
			end
		end

		if t <= 0 then
			inputs[1] = nil
			inputs[2] = nil
		end
	end
end

SpellSelectorComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.current_spell ~= state.previous_current_spell then
			local equipment_state = EntityAux.state(unit, "equipment")
			local weapon_path = ItemLookup.item_id_to_path(equipment_state.weapon)
			local weapon_settings = LuaSettingsManager:get_settings_by_unit_path(weapon_path)
			local spells = weapon_settings.spells
			local spell_lookup = self:create_spell_lookup(spells)

			state.spells = spells
			state.spell_lookup = spell_lookup

			local spell_key = spell_lookup[state.current_spell]
			local spell_name = spells[spell_key]
			local ui_info = weapon_settings.abilities[spell_name].ui_info

			state.spell_ready.name = spell_name
			state.spell_ready.material = ui_info.material
			state.previous_current_spell = state.current_spell
		end
	end
end

SpellSelectorComponent.spell_to_string = function (array)
	return table.concat(array, "_")
end

SpellSelectorComponent.string_to_spell = function (str)
	return string.split(str, "_")
end

local function build_spellkey(key, key_to_spell_info, weapon_settings)
	for elem_key, spell_name in pairs(weapon_settings.spells) do
		local ui_info = weapon_settings.abilities[spell_name].ui_info

		key_to_spell_info[elem_key] = {
			name = spell_name,
			material = ui_info.material,
		}
	end
end

SpellSelectorComponent.setup_spells = function (self, unit, state, weapon_settings)
	local key_to_spell_info = {}

	build_spellkey("", key_to_spell_info, weapon_settings)

	state.key_to_spell_info = key_to_spell_info
end

SpellSelectorComponent.check_spell = function (self, unit, context)
	local state = context.state
	local active_spell = state.active_spell
	local inputs = active_spell.inputs
	local nr_inputs = #inputs
	local animation_event = "conjure_" .. tostring(inputs[#inputs])

	self:queue_command_master(unit, "animation", "trigger_event", animation_event)

	if nr_inputs == 2 then
		local spell_key = SpellSelectorComponent.spell_to_string(inputs)

		state.hud_spell_info.new_state = "spell_ready"
		state.spell_input = inputs
		state.spell_ready = state.key_to_spell_info[spell_key]

		local current = state.spell_lookup[spell_key]

		state.current_spell = current
		state.conjuring = false
		state.conjuring_stop_time = _G.GAME_TIME
	end
end

SpellSelectorComponent.reset_spell = function (self, unit, context)
	local state = context.state
	local equipment_state = EntityAux.state_master(unit, "equipment")
	local weapon_path = ItemLookup.item_id_to_path(equipment_state.weapon)
	local weapon_settings = LuaSettingsManager:get_settings_by_unit_path(weapon_path)

	self:setup_spells(unit, state, weapon_settings)

	state.active_spell = {
		inputs = {},
		weapon_path = weapon_path,
	}
end

SpellSelectorComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "conjuring_start" then
		-- Nothing
	elseif command_name == "conjuring_stop" then
		state.conjuring = false
		state.conjuring_stop_time = _G.GAME_TIME
	elseif command_name == "input" then
		if not state.conjuring then
			state.conjuring = true

			self:reset_spell(unit, context)

			state.hud_spell_info = state.active_spell
			state.hud_spell_info.new_state = "selecting_spell"
		end

		state.hud_spell_info = state.active_spell

		local active_spell = state.active_spell
		local inputs = active_spell.inputs
		local spell_key = data

		if #inputs <= 2 then
			inputs[#inputs + 1] = spell_key
			state.hud_spell_info.last_input_time = _G.GAME_TIME

			self:check_spell(unit, context)
		end
	end
end

SpellSelectorComponent.command_slave = function (self, unit, context, command_name, data)
	return
end
