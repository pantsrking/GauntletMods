﻿-- chunkname: @lua/components/physics_component.lua

require("foundation/lua/component/base_component")

PhysicsComponent = class("PhysicsComponent", "BaseComponent")

PhysicsComponent.init = function (self, creation_context)
	BaseComponent.init(self, "physics", creation_context)

	self._position_info = Network.type_info("position_lowp")
	self._velocity_info = Network.type_info("velocity_lowp")
	self._angular_velocity_info = Network.type_info("angular_velocity_lowp")
end

PhysicsComponent._set_state_from_unit = function (self, unit, context)
	local state = context.state

	state.position = Vector3Aux.box(state.position or {}, Unit.world_position(unit, 0))
	state.rotation = QuaternionAux.box(state.rotation or {}, Unit.world_rotation(unit, 0))

	local actor = Unit.actor(unit, 0)

	if actor then
		local velocity = Vector3.clamp_inplace(Actor.velocity(actor), -32, 32)
		local angular_velocity = Vector3.clamp_inplace(Actor.angular_velocity(actor), -32, 32)

		state.velocity = Vector3Aux.box(state.velocity or {}, velocity)
		state.angular_velocity = Vector3Aux.box(state.angular_velocity or {}, angular_velocity)
	end
end

PhysicsComponent.setup_slave = function (self, unit, context, setup_info)
	self:_set_state_from_unit(unit, context)

	local state = context.state

	state.disabled = false
end

PhysicsComponent.setup_master = function (self, unit, context, setup_info)
	self:_set_state_from_unit(unit, context)

	local state = context.state

	state.disabled = false
	state._disabled_refmix = RefMixer()
end

PhysicsComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "enable" then
		if state._disabled_refmix:get() then
			state._disabled_refmix:remove(data)

			state.disabled = state._disabled_refmix:get()
		end
	elseif command_name == "disable" then
		state._disabled_refmix:add(data, true)

		state.disabled = state._disabled_refmix:get()
	end
end

PhysicsComponent.command_slave = function (self, unit, context, command_name, data)
	return
end

PhysicsComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings

		if not state.disabled then
			self:_set_state_from_unit(unit, context)
		end
	end
end

PhysicsComponent.update_slaves = function (self, entities, dt)
	return
end

PhysicsComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if not state.disabled then
			local target_position = Vector3Aux.unbox(state.position)
			local target_velocity = Vector3Aux.unbox(state.velocity)
			local target_rotation = QuaternionAux.unbox(state.rotation)
			local target_angular_velocity = Vector3Aux.unbox(state.angular_velocity)
			local new_position = target_position
			local new_rotation = target_rotation

			Unit.teleport_local_position(unit, 0, new_position)
			Unit.teleport_local_rotation(unit, 0, new_rotation)

			local actor = Unit.actor(unit, 0)

			if actor then
				Actor.set_velocity(actor, target_velocity)
				Actor.set_angular_velocity(actor, target_angular_velocity)
			end
		end
	end
end
