﻿-- chunkname: @lua/components/navigation_component.lua

require("foundation/lua/component/base_component")
require("lua/dungeon/nav_grid")
require("lua/components/navigation_aux")

local FULL_UPDATES_PER_SECOND = 5

NavigationComponent = class("NavigationComponent", "PeriodicBaseComponent")

local STATES = {
	follow_path = 1,
	idling = 0,
	paused = 2,
}
local NAVIGATION_MODES = {
	animation_driven = 0,
	simple = 2,
	use_force = 1,
}

NavigationStates = NavigationStates or {}

NavigationStates.paused = function (component, unit, context, dt, full_update)
	return
end

NavigationStates.manual_override = function (component, unit, context, dt, full_update)
	local state = context.state

	state.movespeed = component:lerp_movespeed(unit, state, context.settings, dt)
end

NavigationComponent.init = function (self, creation_context)
	PeriodicBaseComponent.init(self, "navigation", creation_context, true, 1 / FULL_UPDATES_PER_SECOND)
	self:register_dependencies("motion", "rotation", "animation")

	self.nav_grid = creation_context.nav_grid
	self.seed = creation_context.seed
	self.randomizer = Randomizer(self.seed)
	self.animation_variables = {}
	self.navigation_component_aux = NavigationComponentAux()

	DifficultyManager:register(self)
end

local function _add_to_navigation_aux(navigation_aux, unit, state)
	state.navigation_state = NavigationComponentAux.add_unit(navigation_aux, unit)
end

NavigationComponent.destroy = function (self)
	DifficultyManager:unregister(self)
	PeriodicBaseComponent.destroy(self)
end

NavigationComponent.migrated_to_me = function (self, unit, slave_context, master_context, setup_info)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context, setup_info)
	NavigationState.set_game_object_id(master_context.state.navigation_state, EntityAux.go_id(unit))
end

NavigationComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	_add_to_navigation_aux(self.navigation_component_aux, unit, state)
	NavigationAux.setup_movespeed(unit, context, self.randomizer)

	if context.settings.animation_driven_movement then
		NavigationState.set_movement_mode(state.navigation_state, NAVIGATION_MODES.animation_driven)
	elseif context.settings.navigation_movement_mode then
		NavigationState.set_movement_mode(state.navigation_state, NAVIGATION_MODES[context.settings.navigation_movement_mode])
	else
		NavigationState.set_movement_mode(state.navigation_state, NAVIGATION_MODES.simple)
	end
end

NavigationComponent.reload_master = function (self, unit, context)
	context.num_commands = 0

	NavigationAux.setup_movespeed(unit, context, self.randomizer)
end

NavigationComponent.remove_master = function (self, unit)
	NavigationComponentAux.remove_unit(self.navigation_component_aux, unit)
end

NavigationComponent._setup_motion_variables = function (self, unit, context)
	local state = context.state
	local animation_variables = self.animation_variables[context.settings]

	if not animation_variables then
		animation_variables = {
			Unit.animation_find_variable(unit, "legs_angle"),
			Unit.animation_find_variable(unit, "move_speed"),
		}
		self.animation_variables[context.settings] = animation_variables
	end

	state.torso_legs_angle_variable = animation_variables[1]
	state.speed_variable = animation_variables[2]
end

NavigationComponent.setup_slave = function (self, unit, context, setup_info)
	self:_setup_motion_variables(unit, context)

	if context.settings.max_movespeed ~= nil then
		local max = context.settings.max_movespeed
	end

	if EntityAux.has_component_master(unit, self.name) then
		NavigationState.set_game_object_id(EntityAux._state_master_raw(unit, self.name).navigation_state, EntityAux.go_id(unit))
	end
end

NavigationComponent.reload_slave = function (self, unit, context)
	self:_setup_motion_variables(unit, context)
end

NavigationComponent.difficulty_changed = function (self, difficulty)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		NavigationAux.setup_movespeed(unit, context, self.randomizer)
	end
end

NavigationComponent.update = function (self, dt)
	Profiler.start(self.name)

	local master_entities = self.entity_manager:get_master_entities(self.name)
	local prediction_entities = self.entity_manager:get_prediction_entities(self.name)

	self:command_masters(master_entities)

	if dt > math.EPSILON then
		local network_session = self.network_session_handler:get_network_session()

		NavigationComponentAux.update(self.navigation_component_aux, network_session, EntityAux.get_component("motion").motion_component_aux, EntityAux.get_component("rotation").rotation_component_aux, self.nav_grid._nav_grid_cpp, dt)
	end

	self:filter_slave_commands(prediction_entities)
	self:update_predictors(prediction_entities, dt)
	Profiler.stop()
end

NavigationComponent.update_predictors = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state, settings = context.state, context.settings
		local speed = state.movespeed

		if settings.slave_movespeed_lerp_speed then
			local previous = state.previous_movespeed or speed

			speed = math.lerp(previous, speed, dt * settings.slave_movespeed_lerp_speed)
			state.movespeed = speed
			state.previous_movespeed = speed
		end

		local angle = NavigationAux.rotate_angle_towards(math.rad(state.previous_torso_angle or state.torso_legs_angle), math.rad(state.torso_legs_angle), math.tau * 0.2, dt)

		state.previous_torso_angle = math.deg(angle)
		state.torso_legs_angle = math.deg(angle)

		Unit.animation_set_variable(unit, state.speed_variable, state.movespeed)
		Unit.animation_set_variable(unit, state.torso_legs_angle_variable, state.torso_legs_angle)
	end
end

NavigationComponent.set_path_find_to = function (self, unit, context, target, target_unit)
	local state = context.state

	if EntityAux.has_component(target_unit, "dynamic_blocker") then
		local settings = LuaSettingsManager:get_settings_by_unit(target_unit)

		if settings.nav_grid_offset_radius then
			local position = Unit.local_position(unit, 0)
			local to_target = target - position

			target = target - Vector3.normalize(to_target) * settings.nav_grid_offset_radius
		end
	end

	NavigationState.set_is_backing(state.navigation_state, state.is_backing)
	NavigationComponentAux.set_path_find_to(self.navigation_component_aux, self.nav_grid._nav_grid_cpp, state.navigation_state, EntityAux.state_master(unit, "motion").motion_state, EntityAux.state_master(unit, "rotation").rotation_state, target, target_unit)
end

NavigationComponent.call_master_wanted_velocity = function (self, unit, context, data)
	local state = context.state

	NavigationState.set_wanted_velocity(state.navigation_state, EntityAux.state_master(unit, "motion").motion_state, data)
end

NavigationComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "go_to" then
		state.is_backing = false

		local target = Vector3Aux.unbox(data)

		self:set_path_find_to(unit, context, target, nil)
	elseif command_name == "path_find_to_unit" then
		state.is_backing = false

		local target = Unit.world_position(data, 0)

		self:set_path_find_to(unit, context, target, data)
	elseif command_name == "path_find_to" then
		state.is_backing = false

		local target = Vector3Aux.unbox(data)

		self:set_path_find_to(unit, context, target, nil)
	elseif command_name == "path_find_away_from_unit" then
		state.is_backing = true

		local target = Vector3Aux.unbox(data.target)

		self:set_path_find_to(unit, context, target, data.unit)
	elseif command_name == "idle" then
		NavigationState.set_state(state.navigation_state, STATES.idling)

		state.custom_move_update = data
	elseif command_name == "set_wanted_movespeed" then
		NavigationState.set_wanted_movespeed(state.navigation_state, data)
	elseif command_name == "set_pause" then
		NavigationState.set_pause(state.navigation_state, data)
	elseif command_name == "disable" then
		NavigationState.set_pause(state.navigation_state, true)
	end
end
