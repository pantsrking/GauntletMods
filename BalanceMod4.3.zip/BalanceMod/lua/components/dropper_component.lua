﻿-- chunkname: @lua/components/dropper_component.lua

require("foundation/lua/component/base_component")
require("foundation/lua/util/randomizer")
require("foundation/lua/network/network_unit_synchronizer")

DropperComponent = class("DropperComponent", "BaseComponent")

DropperComponent.init = function (self, creation_context)
	BaseComponent.init(self, "dropper", creation_context, true)

	self.unit_paths = creation_context.unit_paths
	self.randomizer = Randomizer(creation_context.seed)
end

DropperComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings

	if settings.drop_joint then
		state.drop_joint = Unit.node(unit, settings.drop_joint)
	else
		state.drop_joint = 0
	end
end

DropperComponent.reload_slave = function (self, unit, context)
	local state, settings = context.state, context.settings

	if settings.drop_joint then
		state.drop_joint = Unit.node(unit, settings.drop_joint)
	else
		state.drop_joint = 0
	end
end

DropperComponent.setup_master = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	self:reload_master(unit, context)

	if not settings and not settings.drops then
		state.drop = nil
	elseif setup_info and setup_info.force_drop then
		state.drop = setup_info.force_drop

		self.scheduler:delay_action(0, function ()
			if Unit.alive(unit) then
				self:trigger_rpc_event("flow_event", unit, "keybearer_spawned")
			end
		end)
	else
		local total_weight = 0

		for _, drop in pairs(settings.drops) do
			total_weight = total_weight + (tonumber(drop.weight) or 1)
		end

		local number = self.randomizer()

		for _, drop in pairs(settings.drops) do
			number = number - (tonumber(drop.weight) or 1) / total_weight

			if number <= 0 then
				state.drop = drop.unit_path

				break
			end
		end
	end
end

DropperComponent.setup_slave = function (self, unit, context)
	self:reload_master(unit, context)
end

DropperComponent.update = function (self, dt)
	return
end

DropperComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "spawn_drop" then
		local unit_path = state.drop

		if unit_path and string.len(unit_path) > 0 then
			local joint = state.drop_joint
			local position = Unit.world_position(unit, joint)
			local rotation = Quaternion.identity()
			local parent_id = EntityAux.go_id(unit)
			local dropped_unit = self.entity_spawner:spawn_entity(unit_path, position, rotation, parent_id)

			Unit.set_data(dropped_unit, "is_dropped", true)
			Unit.flow_event(dropped_unit, "on_dropped")
			NetworkUnitSynchronizer:add(dropped_unit)
		end
	end
end

DropperComponent.filter_slave_command = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "spawn_drop" then
		local unit_path = state.drop

		if unit_path then
			local is_authorative = data

			if is_authorative then
				local parent_id = EntityAux.go_id(unit)
				local joint = state.drop_joint
				local position = Unit.world_position(unit, joint)
				local rotation = Quaternion.identity()
				local dropped_unit = self.entity_spawner:spawn_dummy_entity(unit_path, position, rotation, parent_id)

				Unit.set_data(dropped_unit, "is_dropped", true)
				Unit.flow_event(dropped_unit, "on_dropped")
			end
		end

		return true
	end
end
