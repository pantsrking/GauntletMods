﻿-- chunkname: @lua/components/crest_user_component.lua

require("lua/crests/crests")
require("foundation/lua/component/base_component")

CrestUserComponent = class("CrestUserComponent", "BaseComponent")

CrestUserComponent.init = function (self, creation_context)
	BaseComponent.init(self, "crest_user", creation_context)
	self:register_events("on_entity_unregistering")
end

CrestUserComponent.setup_master = function (self, unit, context, setup_info)
	local state = context.state

	state.crests = {}
end

CrestUserComponent.stop_master = function (self, unit, crest_item_id, data)
	if data.active then
		Crests[crest_item_id].stop_master(self, unit, data)
		EntityAux.queue_command_master(unit, "interactor", "set_locked", false)

		data.active = false
	end
end

CrestUserComponent.update = function (self, dt)
	Profiler.start(self.name)

	local master_entities = self.entity_manager:get_master_entities(self.name)

	self:command_masters(master_entities)
	self:update_masters(master_entities, dt)
	Profiler.stop()
end

CrestUserComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		for crest_item_id, data in pairs(state.crests) do
			if data.active then
				local done = Crests[crest_item_id].update_master(self, unit, data, dt)

				if done then
					self:stop_master(unit, crest_item_id, data)
				end
			end
		end
	end
end

CrestUserComponent.command_master = function (self, unit, context, command_name, data)
	local state, settings = context.state, context.settings

	if command_name == "predict_activate" then
		local plate_unit = data.plate_unit

		if not Unit.alive(plate_unit) then
			return
		end

		local crest_item_id = data.name
		local crest_data = state.crests[crest_item_id] or {}

		state.crests[crest_item_id] = crest_data
		crest_data.plate_unit = plate_unit

		Crests[crest_item_id].predict_start_master(self, unit, crest_data)
	elseif command_name == "prediction_failed" then
		local crest_item_id = data.name
		local crest_data = state.crests[crest_item_id]

		Crests[crest_item_id].predict_stop_master(self, unit, crest_data)
	elseif command_name == "activate" then
		local plate_unit = data.plate_unit

		if not Unit.alive(plate_unit) then
			return
		end

		local crest_item_id = data.name
		local crest_data = state.crests[crest_item_id] or {}

		state.crests[crest_item_id] = crest_data

		EntityAux.queue_command_master(unit, "interactor", "set_locked", true)

		crest_data.plate_unit = plate_unit
		crest_data.active = true

		Crests[crest_item_id].start_master(self, unit, crest_data)
	end
end

CrestUserComponent.on_entity_unregistering = function (self, entity)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if entity == unit then
			for crest_item_id, crest_data in pairs(state.crests) do
				self:stop_master(unit, crest_item_id, crest_data)
			end

			state.crests = {}
		else
			for crest_item_id, crest_data in pairs(state.crests) do
				if crest_data.plate_unit == entity then
					crest_data.plate_unit = nil

					self:stop_master(unit, crest_item_id, crest_data)

					state.crests[crest_item_id] = nil
				end
			end
		end
	end
end
