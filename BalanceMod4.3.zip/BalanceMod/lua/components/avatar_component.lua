﻿-- chunkname: @lua/components/avatar_component.lua

require("lua/extensions/combo")
require("lua/extensions/footstep_extension")
require("lua/extensions/pain_shadow_extension")
require("lua/extensions/target_alignment_melee")
require("lua/extensions/target_locking")
require("lua/ai_states/ability_event_listener_aux")
require("lua/ai_states/state_warrior")
require("lua/ai_states/state_necromagus")
require("lua/ai_states/state_elf")
require("lua/ai_states/state_valkyrie")
require("lua/ai_states/state_wizard")
require("lua/ai_states/state_common_character")
require("lua/ai_states/state_common_character_builder")
require("lua/managers/vo_manager")
require("foundation/lua/component/base_component")

AvatarComponent = class("AvatarComponent", "BaseComponent")

local FONT_SIZE = 21
local FONT = "fonts/default"
local MATERIAL = FONT:match("[^/]*$")
local NAME_ALPHA = 210

AvatarComponent.init = function (self, creation_context)
	BaseComponent.init(self, "avatar", creation_context)
	self:register_dependencies("motion", "ability", "inventory", "interactor", "input", "rotation", "animation", "i_damage_receiver")
	self:register_interfaces("i_hit_receiver", "i_speed_listener")
	self:register_events("on_equipment_changed", "on_enter_menu", "on_exit_menu", "on_avatar_talking_start", "on_avatar_talking_stop", "on_avatar_exiting_floor")

	self.unit_paths = creation_context.unit_paths
	self.nav_grid = creation_context.nav_grid
	self.footstep_extension = self:create_extension(FootstepExtension)
	self.pain_shadow_extension = self:create_extension(PainShadowExtension)
	self.target_alignment_melee = self:create_extension(TargetAlignmentMelee)
	self.target_locking = self:create_extension(TargetLocking)
	self.combo = self:create_extension(Combo)
	self.viewport = self.world_proxy:viewport("game_viewport")
end

AvatarComponent.reload_master = function (self, unit, context)
	local state = context.state
	local settings = context.settings
	local all_states, cache_component_states = settings.states(self)

	state.all_states = all_states
	state.component_states = cache_component_states(unit, context)
end

AvatarComponent.reload_slave = function (self, unit, context)
	local state = context.state

	state.speed_variable = Unit.animation_find_variable(unit, "move_speed")
	state.charge_variable = Unit.animation_find_variable(unit, "charge_amount")
	state.torso_legs_angle_variable = Unit.animation_find_variable(unit, "legs_angle")
	state.look_angle_variable = Unit.animation_find_variable(unit, "look_angle")
	state.move_exit_angle_variable = Unit.animation_find_variable(unit, "move_exit_angle")
end

AvatarComponent.migrated_to_me = function (self, unit, slave_context, master_context)
	BaseComponent.migrated_to_me(self, unit, slave_context, master_context, {
		input_data = {},
	})
end

AvatarComponent.setup_master = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.use_target_lock = settings.target_locking ~= nil
	state.walk_direction = Vector3Aux.box({}, Vector3(0, 1, 0))

	self:reload_master(unit, context)
	self.target_alignment_melee:add_unit(unit)

	if state.use_target_lock then
		self.target_locking:add_unit(unit)
	end

	state.spawn_info_key = self:get_spawn_key(unit, state, setup_info)
	state.can_cancel_wisp = state.spawn_info_key == "revived"

	if state.spawn_info_key == "revived" and self.sirens_lute_expiration_time and _G.GAME_TIME < self.sirens_lute_expiration_time then
		local d = TempTableFactory:get_map("hidden", {
			duration = self.sirens_lute_expiration_time - _G.GAME_TIME,
		})
		local t = TempTableFactory:get_map("component", "status_receiver", "command", "add_status_effect", "data", d)

		self:queue_command_master(unit, self.name, "post_setup_command", t)
	end

	local is_keyboard_user = setup_info.input_data.cursor ~= nil

	state.controller_type = is_keyboard_user and "keyboard" or "pad"

	self.target_alignment_melee:set_controller_type(unit, state.controller_type)

	if state.use_target_lock then
		self.target_locking:set_controller_type(unit, state.controller_type)
	end

	self.combo:add_unit(unit)

	local dungeon_layout = Game:get_dungeon_layout(setup_info.floor)
	local should_walk_into_scene = false

	if GameClient.should_walk_in_scene(dungeon_layout, state.spawn_info_key ~= "changed_floor") then
		should_walk_into_scene = true
	else
		EntityAux.queue_command_master(unit, "motion", "constrain_to_mover", true)
	end

	state.current_state_name = should_walk_into_scene and "walk_into_scene" or "setup"
	state.previous_state_name = state.current_state_name

	StateMachineAI.on_enter(self, unit, context)

	local actor = Unit.create_actor(unit, "a_collision")

	Actor.set_collision_filter(actor, "player_local")

	state.combo_ui_info = {}

	EntityAux.queue_command_master(unit, "motion", "constrain_to_camera", true)
	EntityAux.queue_command_master(unit, "motion", "constrain_to_simple_mover", true)
	self:open_direct_communication_channel(unit, "motion", TempTableFactory:get_array("wanted_velocity"))

	state.movespeed_multiplier_mixer = AddMixer()

	state.movespeed_multiplier_mixer:add("default", 1)

	state.movespeed_multiplier = 1
	state.force_animation_busy_mixer = RefMixer()

	if setup_info.previous_player_state == "dead" then
		local d = TempTableFactory:get_map("ethereal", {
			duration = 3,
		})
		local t = TempTableFactory:get_map("component", "status_receiver", "command", "add_status_effect", "data", d)

		self:queue_command_master(unit, self.name, "post_setup_command", t)
	end

	state.held = {}
	state.pressed = {}
	state.released = {}
	state.held_time = {}
	state.input = setup_info.input_data
	state.last_aim = Vector3Aux.box({}, Vector3.zero())
end

AvatarComponent.setup_slave = function (self, unit, context)
	local state = context.state

	self:reload_slave(unit, context)

	state.walk_direction = Vector3Aux.box({}, UnitAux.unit_forward(unit))
	state.look_angle = 0

	self.footstep_extension:add_unit(unit)
	self.pain_shadow_extension:add_unit(unit)
	Unit.create_actor(unit, "a_collision")
	Unit.flow_event(unit, "on_avatar_spawn")

	state.outline_activation = 0
	state.outline_boost_time = nil
	state.animation_movespeed = 0
	state.vo_talking = false
	state.show_name = true

	DungeonManager:add_target(unit)
	self:register_unit_events(unit, "unit_on_death")
end

AvatarComponent.remove_master = function (self, unit, context)
	StateMachineAI.on_exit(self, unit, context)
	self:close_direct_communication_channel(unit, "motion")
end

AvatarComponent.remove_slave = function (self, unit, context)
	DungeonManager:remove_target(unit)
	self:unregister_unit_event(unit, "unit_on_death")
end

local function convert_raw_input(vector_input)
	local length_sq = Vector3.length(vector_input)

	if length_sq > 1 then
		vector_input = Vector3.normalize(vector_input)
		length_sq = 1
	end

	return vector_input, length_sq
end

AvatarComponent.trigger_vo = function (self, trigger_id, avatar_type)
	if VO_Manager:may_hero_talk(avatar_type) then
		self:trigger_rpc_event_to_host("from_client_trigger_vo", trigger_id)
	end
end

AvatarComponent.update_held_times = function (self, context, dt)
	local state = context.state
	local input_data = state.input
	local held = state.held
	local pressed = state.pressed
	local released = state.released
	local held_time = state.held_time

	state.previous_values = state.previous_values or {}

	for key, value in pairs(input_data) do
		held_time[key] = held_time[key] or 0

		local value_type = type(value)

		if value_type == "boolean" then
			local was_held = held[key]

			pressed[key] = was_held == false and value
			released[key] = was_held == true and not value
			held[key] = value
			held_time[key] = was_held == true and held_time[key] + dt or 0
		elseif value_type == "number" then
			local was_held = held[key]

			pressed[key] = was_held == false and value > 0
			released[key] = was_held == true and value == 0
			held[key] = value > 0
			held_time[key] = was_held == true and held_time[key] + dt or 0
		end
	end
end

AvatarComponent.clear_input = function (self)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		table.clear(state.held)
		table.clear(state.pressed)
		table.clear(state.released)
		table.clear(state.held_time)
	end
end

AvatarComponent.on_enter_menu = function (self)
	self:clear_input()
end

AvatarComponent.on_exit_menu = function (self)
	self:clear_input()
end

AvatarComponent.on_avatar_talking_start = function (self, unit)
	if EntityAux.has_component(unit, self.name) then
		EntityAux.call_slave(unit, self.name, "vo_status", true)
	end
end

AvatarComponent.on_avatar_talking_stop = function (self, unit)
	if EntityAux.has_component(unit, self.name) then
		EntityAux.call_slave(unit, self.name, "vo_status", false)
	end
end

AvatarComponent.DEAD_ZONE = 0.1
AvatarComponent.DEAD_ZONE_SQUARED = AvatarComponent.DEAD_ZONE * AvatarComponent.DEAD_ZONE

AvatarComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("write_game_objects")
	self:write_game_objects(master_entities, slave_entities)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

AvatarComponent.post_update = function (self, dt)
	local slave_entities = self.entity_manager:get_slave_entities(self.name)

	Profiler.start("post_update_slaves")
	self:post_update_slaves(slave_entities, dt)
	Profiler.stop()
end

AvatarComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local settings = context.settings

		Profiler.start("input handling")

		local input_data = state.input
		local cursor = input_data.cursor

		state.keyboard_mouse = cursor ~= nil

		if input_data.is_active then
			local aim_magnitude_sq, move_magnitude_sq = 1, 1

			if state.keyboard_mouse then
				local camera = CameraManager:get_camera()
				local viewport = CameraManager:get_viewport()
				local unit_pos = Unit.local_position(unit, 0) + Vector3.up()
				local camera_pos = Camera.local_position(camera)
				local aim_pos_gui = cursor
				local aim_pos_world = viewport:screen_to_world(aim_pos_gui.x, aim_pos_gui.y, CameraManager.follow_distance)
				local aim_point = InputAux.project_onto_unit_plane(camera_pos, unit_pos, aim_pos_world)

				input_data.aim = Vector3.normalize(aim_point - unit_pos)
				input_data.move = Vector3.normalize(input_data.move)

				if Vector3.length_squared(input_data.aim) <= math.EPSILON then
					state.active_aim_direction = UnitAux.unit_forward(unit)
				else
					state.active_aim_direction = input_data.aim
				end
			else
				input_data.aim, aim_magnitude_sq = convert_raw_input(input_data.aim_raw)
				input_data.move, move_magnitude_sq = convert_raw_input(input_data.move)

				if aim_magnitude_sq <= AvatarComponent.DEAD_ZONE_SQUARED then
					if move_magnitude_sq <= AvatarComponent.DEAD_ZONE_SQUARED then
						state.active_aim_direction = UnitAux.unit_forward(unit)
					else
						state.active_aim_direction = state.input.move
					end
				else
					state.active_aim_direction = input_data.aim
				end
			end

			self:update_held_times(context, dt)

			if state.confused then
				state.input.move = -state.input.move
			end

			local avatar_type = settings.avatar_type

			if input_data.emote_cheer then
				self:trigger_vo("emote_cheer_" .. avatar_type, avatar_type)
			end

			if input_data.emote_help then
				self:trigger_vo("emote_help_" .. avatar_type, avatar_type)
			end

			if input_data.emote_letsgo then
				self:trigger_vo("emote_letsgo_" .. avatar_type, avatar_type)
			end

			if input_data.emote_thanks then
				self:trigger_vo("emote_thanks_" .. avatar_type, avatar_type)
			end
		else
			state.input.move, state.input.aim = Vector3.zero(), Vector3.zero()
			state.active_aim_direction = UnitAux.unit_forward(unit)
		end

		state.active_aim_direction = Vector3.normalize(state.active_aim_direction)

		Profiler.start("target_lock")

		if state.use_target_lock then
			local aim = state.input.aim
			local disabled

			if settings.only_target_lock_on_attack then
				disabled = self.combo:get_state(unit).current_combo == nil
			else
				disabled = Vector3.length(aim) <= AvatarComponent.DEAD_ZONE
			end

			self.target_locking:update(unit, dt, disabled)

			local target_lock = self.target_locking:get_state(unit)

			state.current_target = target_lock.current_target and target_lock.current_target.target
		end

		Profiler.stop()
		Profiler.stop()
		Profiler.start("motion")

		local velocity = MotionState.get_velocity(EntityAux.state_master(unit, "motion").motion_state)

		state.move_speed = Vector3.length(velocity)
		state.move_speed = state.move_speed <= 0.001 and 0 or state.move_speed

		Profiler.stop()
		Profiler.start("Avatar StateMachine")
		StateMachineAI.update(self, unit, context, dt)
		Profiler.stop()
		Profiler.start("target_alignment")
		self.target_alignment_melee:update(unit)

		if settings.avatar_type == "wizard" then
			local spell_state = EntityAux.state_master(unit, "spell_selector")
			local current_spell = spell_state.spell_ready.name

			if current_spell ~= state.previous_spell then
				state.previous_spell = current_spell

				local node = self.combo:get_node(unit, current_spell)

				self.combo:parse_new_combo(self.combo:get_state(unit), node)
			end
		end

		Profiler.stop()
		Profiler.start("combo get_ui_info")

		state.combo_ui_info = self.combo:get_ui_info(unit)

		Profiler.stop()

		state.animation_busy = state.force_animation_busy_mixer:get()
	end
end

local function _update_animation(component, unit, context, dt)
	local state = context.state
	local move_speed = state.move_speed

	if state.animation_state ~= "move" then
		state.animation_state = "move"

		EntityAux.queue_command_slave(unit, "animation", "trigger_event", "move")
	end
end

local ANIMATION_MOVE_LERPSPEED_ACCELERATION = 40
local ANIMATION_MOVE_LERPSPEED_DECELERATION = 30

AvatarComponent.post_update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state
		local settings = context.settings
		local avatar_type = settings.avatar_type

		Profiler.start("move_speed")

		local velocity

		if EntityAux.has_component_master(unit, "motion") then
			velocity = MotionState.get_velocity(EntityAux.state_master(unit, "motion").motion_state)
		else
			velocity = Vector3Aux.unbox(EntityAux.state(unit, "motion").velocity)
		end

		velocity.z = 0

		local previous_move_speed = state.move_speed or 0
		local move_speed = Vector3.length(velocity)

		state.move_speed = move_speed
		state.target_animation_movespeed = move_speed

		if settings.animation_movespeed_max ~= nil then
			local movespeed_max = settings.animation_movespeed_max

			state.target_animation_movespeed = math.clamp(state.target_animation_movespeed, 0, movespeed_max)
		end

		local acceleration = state.target_animation_movespeed > state.animation_movespeed

		state.animation_movespeed = math.move_towards(state.animation_movespeed, state.target_animation_movespeed, acceleration and ANIMATION_MOVE_LERPSPEED_ACCELERATION or ANIMATION_MOVE_LERPSPEED_DECELERATION, dt)

		Unit.animation_set_variable(unit, state.speed_variable, state.animation_movespeed)
		Profiler.stop()
		Profiler.start("charge_variable")

		if state.charge_variable and state.previous_windup_amount ~= state.windup_amount then
			state.previous_windup_amount = state.windup_amount

			Unit.animation_set_variable(unit, state.charge_variable, math.clamp(state.windup_amount, 0, 1))
			Unit.set_flow_variable(unit, "charge_amount", state.windup_amount)
			Unit.flow_event(unit, "charge_amount_updated")
		end

		Profiler.stop()
		Profiler.start("animation")

		if state.animation_busy then
			state.animation_state = nil
		else
			if state.move_speed > 0.1 then
				Vector3Aux.box(state.walk_direction, Vector3.normalize(velocity))

				state.walk_direction.z = 0
			end

			if avatar_type == "valkyrie" then
				local blocking = EntityAux.state(unit, "blocker").blocking

				if blocking then
					if state.animation_state ~= "block_enter" then
						state.torso_legs_angle = state.look_angle
						state.animation_state = "block_enter"
					end

					StateValkyrie.update_walk_angle(self, unit, context, dt)
				end
			elseif settings.slave_update_walk_angle then
				if state.animation_state == nil then
					_update_animation(self, unit, context, dt)
				end

				Profiler.start("animation move_started/stopped")

				if previous_move_speed == 0 and state.move_speed > 0.1 then
					EntityAux.queue_command_slave(unit, "animation", "trigger_event", "move_started")
				elseif previous_move_speed > 0.1 and state.move_speed == 0 then
					local anim_variable = state.move_exit_angle_variable

					if anim_variable then
						Unit.animation_set_variable(unit, anim_variable, state.torso_legs_angle)
					end

					EntityAux.queue_command_slave(unit, "animation", "trigger_event", "move_stopped")
				end

				Profiler.stop()
				StateCommonCharacter.update_walk_angle(self, unit, context, dt)

				state.look_angle = state.torso_legs_angle
			end
		end

		Profiler.start("animation variables")

		if settings.slave_update_look_angle then
			local animation_look_angle = state.animation_look_angle or state.look_angle

			animation_look_angle = math.move_towards(animation_look_angle, state.look_angle, 1800, dt)

			Unit.animation_set_variable(unit, state.look_angle_variable, animation_look_angle)

			state.animation_look_angle = animation_look_angle
		end

		if settings.slave_update_torso_legs_angle then
			Unit.animation_set_variable(unit, state.torso_legs_angle_variable, state.look_angle)
		end

		Profiler.stop()
		Profiler.start("animation move_started/stopped")

		if state.animation_state == "move" then
			if previous_move_speed == 0 and state.move_speed > 0.1 then
				EntityAux.queue_command_slave(unit, "animation", "trigger_event", "move_started")
			elseif previous_move_speed > 0.1 and state.move_speed == 0 then
				EntityAux.queue_command_slave(unit, "animation", "trigger_event", "move_stopped")
			end
		end

		Profiler.stop()
		Profiler.stop()
	end
end

AvatarComponent.call_slave_set_ragdoll = function (self, unit, context, data)
	context.state.ragdolling = data
end

AvatarComponent.update_slaves = function (self, entities, dt)
	local VoiceManager = VoiceManager

	for unit, context in pairs(entities) do
		local state = context.state

		self.pain_shadow_extension:update(unit, dt)

		local avatar_type = context.settings.avatar_type

		Profiler.start("animation")

		if not state.animation_busy then
			if avatar_type == "valkyrie" then
				local blocking = EntityAux.state(unit, "blocker").blocking

				if blocking then
					if state.animation_state ~= "block_enter" then
						EntityAux.queue_command_slave(unit, "animation", "trigger_event", "block_enter")
					end
				else
					_update_animation(self, unit, context, dt)
				end
			elseif not context.settings.slave_update_walk_angle then
				_update_animation(self, unit, context, dt)
			end
		end

		Profiler.stop()
		Profiler.start("outline_see_through_alpha")

		local dist_to_exit = math.huge
		local unit_pos = Unit.world_position(unit, 0)

		for i, exit_data in DungeonManager:exits_iterator() do
			local exit_pos = Vector3Aux.unbox(exit_data.position)
			local dist = Vector3.distance(unit_pos, exit_pos)

			dist_to_exit = math.min(dist_to_exit, dist)
		end

		local outline_see_through_alpha = math.fade_between(dist_to_exit, 10, 15)

		if outline_see_through_alpha ~= state.outline_see_through_alpha then
			MaterialAux.set_scalar(unit, nil, nil, "outline_see_through_transparency", 1 - outline_see_through_alpha, true)

			state.outline_see_through_alpha = outline_see_through_alpha
		end

		Profiler.stop()
		Profiler.start("outline")

		local max_width = 0.05

		if state.outline_boost_time then
			local time_since_boost = GAME_TIME - state.outline_boost_time
			local INCREASE_TIME = 0.25
			local DECREASE_TIME = 3

			if time_since_boost < 0.5 then
				state.outline_activation = state.outline_activation + dt / INCREASE_TIME

				if state.outline_activation > 1 then
					state.outline_activation = 1
				end
			else
				state.outline_activation = state.outline_activation - dt / DECREASE_TIME

				if state.outline_activation < 0 then
					state.outline_activation = 0
					state.outline_boost_time = nil
				end
			end

			max_width = max_width * math.remap_range_clamped(time_since_boost, 0, 0.25, 2, 1)

			self:set_outline(unit, avatar_type, state.outline_activation, max_width)
		end

		Profiler.stop()

		if not Game.DISABLE_GUI then
			Profiler.start("hud")

			local gui_im = GUI:get_gui_im()

			do
				local user = ProfileManager:get_main_user()

				if state.show_name and Game:show_player_names(user.user_id) then
					local player_info = PlayerManager:get_player_info_by_avatar(unit)
					local text = player_info and player_info.name or tr(sprintf("loc_hero_%s", avatar_type))
					local _, max, _, _ = Gui.text_extents(gui_im, text, FONT, FONT_SIZE)
					local w = max.x
					local pos_world = Unit.world_position(unit, 0)
					local pos_pixels = self.viewport:world_to_screen(pos_world)

					pos_pixels.x = pos_pixels.x - 0.5 * w
					pos_pixels.y = pos_pixels.y - 40
					pos_pixels.z = 1

					local color = AvatarSettings.get_avatar_color(avatar_type, NAME_ALPHA)

					Gui.text(gui_im, text, FONT, FONT_SIZE, MATERIAL, pos_pixels + Vector2(1, -1), Color(NAME_ALPHA, 0, 0, 0))
					Gui.text(gui_im, text, FONT, FONT_SIZE, MATERIAL, pos_pixels, color)

					if player_info and VoiceManager:is_voice_active(player_info.name) then
						local size = Vector2(32, 32)

						pos_pixels.x = pos_pixels.x + w
						pos_pixels.y = pos_pixels.y - 10
						pos_pixels.z = 1

						Gui.bitmap(gui_im, "icon_voice_chatting", pos_pixels, size, color)
					end
				end
			end

			if state.vo_talking then
				local size = Vector2(40, 40)
				local pos_world = Unit.local_position(unit, 0)

				pos_world.x = pos_world.x - 0.75
				pos_world.y = pos_world.y + 1.4

				local pos_pixels = self.viewport:world_to_screen(pos_world)

				pos_pixels.z = 1

				Gui.bitmap(gui_im, "hud_talking_bubble", pos_pixels, size, Color(255, 255, 255, 255))
			end

			Profiler.stop()
		end
	end
end

AvatarComponent.call_slave_set_show_name = function (self, unit, context, data)
	context.state.show_name = data
end

AvatarComponent.on_avatar_exiting_floor = function (self, avatar_unit, player_go_id)
	EntityAux.call_slave(avatar_unit, self.name, "set_show_name", false)
	UnitPropertyAux.add_ref(avatar_unit, "target_hidden", "exit_floor")
end

AvatarComponent.set_outline = function (self, unit, avatar_type, outline_activation, max_width)
	max_width = max_width or 0.05

	local outline_width = math.remap_range_clamped(outline_activation, 0, 1, 0, 1)

	MaterialAux.set_scalar(unit, nil, nil, "outline_width", math.sqrt(outline_width) * max_width, true)

	local outline_alpha = outline_width
	local outline_color

	if avatar_type == "warrior" then
		outline_color = Color.from_normalized_rgba(1, 0, 0, outline_alpha)
	elseif avatar_type == "elf" then
		outline_color = Color.from_normalized_rgba(0, 0.6, 0, outline_alpha)
	elseif avatar_type == "valkyrie" then
		outline_color = Color.from_normalized_rgba(0.05, 0.161, 1, outline_alpha)
	elseif avatar_type == "wizard" then
		outline_color = Color.from_normalized_rgba(0.7, 0.3, 0.03, outline_alpha)
	elseif avatar_type == "necromagus" then
		outline_color = Color.from_normalized_rgba(1, 0, 0.8, outline_alpha)
	end

	MaterialAux.set_color(unit, nil, nil, "outline_color", outline_color, true)
end

AvatarComponent.get_spawn_key = function (self, unit, context, setup_info)
	local previous_player_state = setup_info.previous_player_state
	local player_info = setup_info.player_go_id and PlayerManager:get_player_info(setup_info.player_go_id)

	if setup_info.hitpoint_ratio == 0 then
		EntityAux.queue_command_master(unit, "animation", "trigger_event", "die")
		Game:delay_frames(1, function ()
			if not EntityAux.is_alive_entity(unit) then
				return
			end

			EntityAux.queue_command_master(unit, "animation", "trigger_event_death", "ragdoll")
		end)

		return "default"
	elseif player_info and player_info.floor_started then
		player_info.floor_started = false

		return "changed_floor"
	elseif previous_player_state == "playing" then
		return "default"
	elseif previous_player_state == "dead" then
		return "revived"
	elseif previous_player_state == "exited_floor" then
		return "changed_floor"
	end
end

AvatarComponent.call_master_hit = function (self, unit, context, hit)
	self:call_slave_hit(unit, EntityAux._context_raw(unit, self.name), hit)
end

AvatarComponent.call_slave_hit = function (self, unit, context, hit)
	context.state.outline_boost_time = GAME_TIME
end

AvatarComponent.call_master_set_shield_thrown = function (self, unit, context, shield_thrown)
	context.state.shield_thrown = shield_thrown

	EntityAux.call_slave(unit, self.name, "set_shield_thrown", shield_thrown)
	self:call_slave_set_shield_thrown(unit, context, shield_thrown)
end

AvatarComponent.call_slave_set_shield_thrown = function (self, unit, context, shield_thrown)
	context.state.shield_thrown = shield_thrown
end

AvatarComponent.call_slave_vo_status = function (self, unit, context, data)
	context.state.vo_talking = data
end

AvatarComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "toggle_debug_states" then
		state.debug_states = not state.debug_states
	elseif command_name == "force_state_change" then
		state.wanted_state_change = data
	elseif command_name == "add_speed_multiplier" then
		local id = data.id

		state.movespeed_multiplier_mixer:add(id, data.value)

		state.movespeed_multiplier = state.movespeed_multiplier_mixer:get()
	elseif command_name == "remove_speed_multiplier" then
		state.movespeed_multiplier_mixer:remove(data)

		state.movespeed_multiplier = state.movespeed_multiplier_mixer:get()
	elseif command_name == "set_confused" then
		state.confused = data
	elseif command_name == "post_setup_command" then
		EntityAux.call_master(unit, data.component, data.command, data.data)
	end
end

AvatarComponent.unit_on_death = function (self, unit)
	self:queue_command(unit, "motion", "destroy")

	local ACTORS_TO_DESTROY = {
		"a_collision",
		"a_damageable",
	}

	for i, actor_name in ipairs(ACTORS_TO_DESTROY) do
		Unit.destroy_actor(unit, actor_name)
	end

	local weapons = TempTableFactory:get_array("weapon")

	if not EntityAux.state(unit, self.name).shield_thrown then
		weapons[#weapons + 1] = "shield"
	end

	EntityAux.call_slave(unit, "equipment", "drop_weapons", weapons)
	self:queue_command(unit, "animation", "trigger_event_death", "die")
	self:queue_command(unit, "ability", "set_enabled", false)
	self:queue_command(unit, "interactor", "disable")
end

AvatarComponent.on_equipment_changed = function (self, unit)
	StateCommonCharacter.ensure_combo(self, unit)
end

AvatarComponent.setup_console_library = function (self)
	return {
		text = "Plugin for avatar component.",
		parts = {
			debug_states = {
				text = "Toggles showing which state the avatar is in.",
				usage = "[go_id|all]",
				fun = function (target)
					local msg = {
						message = sprintf("Toggle debug states for %s", PluginComponentAux.target_description(target)),
					}

					msg = PluginComponentAux.execute_command(self, "toggle_debug_states", true, target) or msg

					return msg
				end,
			},
		},
	}
end
