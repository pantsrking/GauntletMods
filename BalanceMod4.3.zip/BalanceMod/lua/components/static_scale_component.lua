﻿-- chunkname: @lua/components/static_scale_component.lua

require("foundation/lua/component/base_component")

StaticScaleComponent = class("StaticScaleComponent", "BaseComponent")

StaticScaleComponent.init = function (self, creation_context)
	BaseComponent.init(self, "static_scale", creation_context)
	self:register_interfaces("i_scale")
end

local function _calculate_scale(component, unit, settings, new_scale)
	new_scale = new_scale or settings.scale_info.scale

	local rand = Randomizer(EntityAux.go_id(unit) * 10000):random()

	return new_scale + (settings.scale_info.variation or 0) * (rand * 2 - 1)
end

local function _update_unit_scale(unit, state, scale)
	state.current_scale = scale

	Unit.set_local_scale(unit, 0, Vector3(scale, scale, scale))

	if state.scale_speed_variable then
		Unit.animation_set_variable(unit, state.scale_speed_variable, 1 / scale)
	end
end

StaticScaleComponent.setup_slave = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.scale = _calculate_scale(self, unit, context.settings)

	if Unit.has_animation_state_machine(unit) then
		state.scale_speed_variable = Unit.animation_find_variable(unit, "scale_speed")
	end

	state.current_scale = state.scale

	_update_unit_scale(unit, state, state.scale)
end

StaticScaleComponent.update = function ()
	return
end
