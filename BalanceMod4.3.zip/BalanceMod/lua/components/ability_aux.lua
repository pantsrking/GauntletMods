﻿-- chunkname: @lua/components/ability_aux.lua

require("lua/components/ability_building_blocks")

AbilityAux = AbilityAux or {}

rawset(_G, "ANIMFRAMES_PER_SECOND", 30)

local bit = require("bit")
local lshift = bit.lshift
local rshift = bit.rshift
local bor = bit.bor
local band = bit.band

AbilityAux.BITS_GOID = 16
AbilityAux.BITS_ABILITY = 3
AbilityAux.BITS_EVENT = 4
AbilityAux.BITS_HIT = 9

AbilityAux.generate_event_id = function (goid, ability_id, event_index)
	local mask = goid

	mask = lshift(mask, AbilityAux.BITS_ABILITY)
	mask = bor(mask, ability_id)
	mask = lshift(mask, AbilityAux.BITS_EVENT)
	mask = bor(mask, event_index)

	return lshift(mask, AbilityAux.BITS_HIT)
end

AbilityAux.generate_ability_id = function (unit, state)
	local ability_id = state.ability_id_counter
	local ABILITY_ID_MAX = 2^AbilityAux.BITS_ABILITY

	state.ability_id_counter = (state.ability_id_counter + 1) % ABILITY_ID_MAX

	return ability_id
end

AbilityAux.next_ability_id = function (unit, state, current_ability_id)
	local ABILITY_ID_MAX = 2^AbilityAux.BITS_ABILITY

	state.ability_id_counter = (current_ability_id + 1) % ABILITY_ID_MAX

	return AbilityAux.generate_ability_id(unit, state)
end

AbilityAux.event_id_from_hit_id = function (hit_id)
	local max = 4294967295
	local mask = lshift(max, AbilityAux.BITS_HIT)

	return band(mask, hit_id)
end

AbilityAux.event_from_hit_id = function (hit_id)
	local max = 4294967295
	local id_without_goid_and_ability = band(hit_id, rshift(max, AbilityAux.BITS_GOID + AbilityAux.BITS_ABILITY))
	local only_event = rshift(id_without_goid_and_ability, AbilityAux.BITS_HIT)

	return only_event
end

AbilityAux.get_stat_creditor_go_id = function (owner_unit)
	local stat_creditor = owner_unit
	local stat_creditor_go_id

	if EntityAux.has_component_master(stat_creditor, "avatar") then
		local player_go_id = PlayerManager:get_player_info_by_avatar(stat_creditor).go_id

		stat_creditor_go_id = player_go_id
	end

	return stat_creditor_go_id
end

local function debug_cond_error(condition, format, ...)
	return
end

local function handle_inheritance(info, settings, ability_name, settings_path)
	if info.inherit_from then
		debug_cond_error(settings[info.inherit_from], "There is no block named %s in abilities", tostring(info.inherit_from))

		local parent_info = table.clone(settings[info.inherit_from])

		if not parent_info then
			debug_cond_error(false, "handle_inheritance failed! (info.inherit_from=%t, ability_name=%t, settings_path=%t)", info.inherit_from, ability_name, settings_path)

			return
		end

		handle_inheritance(parent_info, settings, ability_name, settings_path)
		SettingsAux.recursive_inheritance(info, parent_info)
	end
end

AbilityAux.create_ability_by_path = function (ability_name, settings_path, master_version, caster_unit)
	local abilities_settings = LuaSettingsManager:get_settings_by_settings_path(settings_path).abilities

	return AbilityAux.create_ability(abilities_settings, ability_name, settings_path, master_version, caster_unit)
end

local function _add_ability_callbacks(ability_callbacks, frame, ability_callback, duration)
	if ability_callbacks == nil then
		return
	end

	local updates = ability_callbacks[frame] or {}

	updates[#updates + 1] = {
		func = ability_callback,
		duration = duration,
	}
	ability_callbacks[frame] = updates
end

AbilityAux.create_ability = function (settings, ability_name, settings_path, master_version, caster_unit)
	local ability_settings = settings[ability_name]

	if ability_settings.event_data or ability_settings.ability_data then
		return
	end

	Profiler.start("create_ability %s", ability_name)

	local ability_info = table.clone(ability_settings)

	ability_info.name = ability_name
	ability_info.ability_name = ability_name
	ability_info.settings_path = settings_path

	if ability_info.inherit_from then
		handle_inheritance(ability_info, settings, ability_name, settings_path)
	end

	local afps = _G.ANIMFRAMES_PER_SECOND
	local exit_callbacks = {}
	local ability_callbacks = {}
	local migration_callbacks = ability_settings.allow_migration and {} or nil

	ability_info.ability_callbacks = ability_callbacks
	ability_info.exit_callbacks = exit_callbacks
	ability_info.migration_callbacks = migration_callbacks

	local infinite = ability_info.mode == "infinite" or ability_info.duration == -1

	if not infinite then
		local duration = ability_info.duration

		debug_cond_error(duration, "No duration set! Should it be an event_data/ability_data? (ability_name=%t, settings_path=%t, master_version=%t)", ability_name, settings_path, master_version)

		duration = math.round(duration or 0)
		ability_info.duration = duration
	end

	local duration_in_frames = ability_info.duration

	debug_cond_error(infinite or duration_in_frames, "Invalid abilty %s [%s] missing duration or mode == \"infinite\"", ability_name, settings_path)

	ability_info.duration = not infinite and duration_in_frames / afps or -1

	if master_version then
		if ability_info.cooldown then
			local cooldown = ability_info.cooldown
			local time, duration

			if type(cooldown) == "table" then
				time = cooldown.time
				duration = cooldown.duration
			else
				time = 0
				duration = cooldown
			end

			debug_cond_error(infinite or time <= duration_in_frames, "cooldown start is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, time, closure(AbilityBuildingBlocks.set_cooldown, duration / afps))
		end

		local movements = ability_info.movements

		if movements then
			for i, movement in ipairs(movements) do
				local window = {
					movement.window[1] / afps,
					movement.window[2] / afps,
				}

				movement.duration = window[2] - window[1]

				debug_cond_error(not math.is_zero(movement.duration), "Can't have a movement window with 0 duration! (ability_name=%s)", ability_name)

				if movement.type == "slide" then
					local t = movement.duration
					local a = (movement.translation + t * t * t / 3) / t

					movement.velocity_function = function (t)
						return math.max(a - t * t, 0)
					end
				elseif movement.type == "step" or movement.type == nil then
					movement.speed = movement.translation / movement.duration
					movement.speed_z = (movement.translation_z or 0) / movement.duration
				end

				debug_cond_error(infinite or duration_in_frames >= movement.window[1], "movement contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, movement.window[1], closure(AbilityBuildingBlocks.movement_update, movement), movement.duration)
				_add_ability_callbacks(migration_callbacks, movement.window[1], closure(AbilityBuildingBlocks.movement_update, movement), movement.duration)

				movement.window = window
			end
		end

		if ability_info.set_motion_max_step_down then
			local max_step_down = ability_info.set_motion_max_step_down

			_add_ability_callbacks(ability_callbacks, 0, closure(AbilityBuildingBlocks.set_max_step_down, max_step_down))

			exit_callbacks[#exit_callbacks + 1] = closure(AbilityBuildingBlocks.set_max_step_down, nil)
		end

		local custom_movement = ability_info.custom_movement

		if custom_movement then
			_add_ability_callbacks(ability_callbacks, 0, AbilityBuildingBlocks.custom_movement_setup)
			_add_ability_callbacks(migration_callbacks, 0, AbilityBuildingBlocks.custom_movement_setup)
			debug_cond_error(custom_movement.duration, "No duration (or duration <= 0) in custom movements! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			debug_cond_error(tonumber(custom_movement.duration) > 0, "Duration must be set to more then 0 frames! (ability_name=%t, duration=%t)", ability_name, custom_movement.duration)

			local start_frame = custom_movement.start or 0
			local end_frame = start_frame + custom_movement.duration

			debug_cond_error(infinite or start_frame <= duration_in_frames, "start_frame for custom_movement is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			debug_cond_error(infinite or end_frame <= duration_in_frames, "end_frame for custom_movement is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, start_frame, closure(AbilityBuildingBlocks.custom_movement_enter, start_frame))
			_add_ability_callbacks(migration_callbacks, start_frame, closure(AbilityBuildingBlocks.custom_movement_enter, start_frame))
			_add_ability_callbacks(ability_callbacks, start_frame, AbilityBuildingBlocks.custom_movement_update, custom_movement.duration / afps)
			_add_ability_callbacks(migration_callbacks, start_frame, AbilityBuildingBlocks.custom_movement_update, custom_movement.duration / afps)
			_add_ability_callbacks(ability_callbacks, end_frame, AbilityBuildingBlocks.custom_movement_exit)
			_add_ability_callbacks(migration_callbacks, end_frame, AbilityBuildingBlocks.custom_movement_exit)

			if custom_movement.on_enter then
				AbilityAux.build_event_callbacks(custom_movement.on_enter, ability_info)
				_add_ability_callbacks(ability_callbacks, start_frame, closure(AbilityBuildingBlocks.run_ability_event_callbacks, custom_movement.on_enter))
			end

			if custom_movement.on_exit then
				AbilityAux.build_event_callbacks(custom_movement.on_exit, ability_info)
				_add_ability_callbacks(ability_callbacks, end_frame, closure(AbilityBuildingBlocks.run_ability_event_callbacks, custom_movement.on_exit))
			end

			exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.custom_movement_exit
		end

		local override_mover_filters = ability_info.override_mover_filters

		if ability_info.override_mover_filter then
			override_mover_filters = override_mover_filters or {}
			override_mover_filters[#override_mover_filters + 1] = {
				time = 0,
				filter = ability_info.override_mover_filter,
			}
		end

		if override_mover_filters then
			for i, override in ipairs(override_mover_filters) do
				debug_cond_error(infinite or duration_in_frames >= override.time, "override_mover_filters contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, override.time, closure(AbilityBuildingBlocks.mover_filter_set, override.filter))
				_add_ability_callbacks(migration_callbacks, override.time, closure(AbilityBuildingBlocks.mover_filter_set, override.filter))
			end

			exit_callbacks[#exit_callbacks + 1] = closure(AbilityBuildingBlocks.mover_filter_set, nil)
		end

		local blockings = ability_info.blockings

		if blockings then
			for i, blocking in ipairs(blockings) do
				debug_cond_error(infinite or duration_in_frames >= blocking.time, "blockings contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, blocking.time, closure(AbilityBuildingBlocks.blocking_set, blocking.activate))
				_add_ability_callbacks(migration_callbacks, blocking.time, closure(AbilityBuildingBlocks.blocking_set, blocking.activate))
			end
		end

		local enemy_collisions = ability_info.enemy_collisions

		if enemy_collisions == "disable" then
			enemy_collisions = {
				{
					activate = false,
					time = 0,
				},
				{
					activate = true,
					time = duration_in_frames,
				},
			}
		end

		if enemy_collisions then
			for i, enemy_collision in ipairs(enemy_collisions) do
				debug_cond_error(enemy_collision.time or i == #enemy_collisions, "Only the last entry (the exit event) can have 'time == nil'")

				if enemy_collision.time then
					debug_cond_error(infinite or duration_in_frames >= enemy_collision.time, "enemy_collisions contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
					_add_ability_callbacks(ability_callbacks, enemy_collision.time, closure(AbilityBuildingBlocks.enemy_collision_set, enemy_collision.activate))
					_add_ability_callbacks(migration_callbacks, enemy_collision.time, closure(AbilityBuildingBlocks.enemy_collision_set, enemy_collision.activate))
				end
			end

			exit_callbacks[#exit_callbacks + 1] = closure(AbilityBuildingBlocks.enemy_collision_exit, enemy_collisions[#enemy_collisions].activate)
		end

		local spawn_entities = ability_info.spawn_entities

		if spawn_entities then
			for i, spawn in ipairs(spawn_entities) do
				if spawn.time_interval then
					local start_time = spawn.time

					while start_time <= duration_in_frames do
						_add_ability_callbacks(ability_callbacks, start_time, closure(AbilityBuildingBlocks.spawn_ability_entity, table.clone(spawn)))

						local interval = spawn.time_interval

						if spawn.time_interval_variation then
							interval = spawn.time_interval_variation * (math.random() * 2 - 1)
						end

						start_time = start_time + interval
					end
				else
					debug_cond_error(infinite or duration_in_frames >= spawn.time, "spawn_entities contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
					_add_ability_callbacks(ability_callbacks, spawn.time, closure(AbilityBuildingBlocks.spawn_ability_entity, spawn))
				end
			end
		end

		if ability_info.rotation_lock_start then
			local allow_rotations = ability_info.allow_rotations or {}

			allow_rotations[#allow_rotations + 1] = {
				enable = false,
				time = ability_info.rotation_lock_start,
			}
			ability_info.allow_rotations = allow_rotations
		end

		local allow_rotations = ability_info.allow_rotations

		if allow_rotations then
			for i, allow_rotation in ipairs(allow_rotations) do
				debug_cond_error(allow_rotation.time, "No time given to allow_rotation! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				debug_cond_error(infinite or duration_in_frames >= allow_rotation.time, "allow_rotations contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, allow_rotation.time, closure(AbilityBuildingBlocks.allow_rotation_update, allow_rotation))
				_add_ability_callbacks(migration_callbacks, allow_rotation.time, closure(AbilityBuildingBlocks.allow_rotation_update, allow_rotation))
			end

			exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.allow_rotation_exit
		end

		local invincibilities = ability_info.invincibilities

		if invincibilities then
			for i, invincibility in ipairs(invincibilities) do
				debug_cond_error(infinite or duration_in_frames >= invincibility.window[1], "invincibilities contains min frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)

				local stop_time = math.min(invincibility.window[2], duration_in_frames)

				_add_ability_callbacks(ability_callbacks, invincibility.window[1], closure(AbilityBuildingBlocks.invincibility_set, true))
				_add_ability_callbacks(ability_callbacks, stop_time, closure(AbilityBuildingBlocks.invincibility_set, false))
				_add_ability_callbacks(migration_callbacks, invincibility.window[1], closure(AbilityBuildingBlocks.invincibility_set, true))
				_add_ability_callbacks(migration_callbacks, stop_time, closure(AbilityBuildingBlocks.invincibility_set, false))
			end

			exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.invincibility_exit
		end

		local hero_invincibilities = ability_info.hero_invincibilities

		if hero_invincibilities then
			for i, invincibility in ipairs(hero_invincibilities) do
				debug_cond_error(infinite or duration_in_frames >= invincibility.window[1], "hero_invincibilities contains min frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				debug_cond_error(infinite or duration_in_frames >= invincibility.window[2], "hero_invincibilities contains max frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, invincibility.window[1], closure(AbilityBuildingBlocks.hero_invincibility_set, invincibility))
				_add_ability_callbacks(ability_callbacks, invincibility.window[2], closure(AbilityBuildingBlocks.hero_invincibility_exit, invincibility))

				exit_callbacks[#exit_callbacks + 1] = closure(AbilityBuildingBlocks.hero_invincibility_exit, invincibility)

				_add_ability_callbacks(migration_callbacks, invincibility.window[1], closure(AbilityBuildingBlocks.hero_invincibility_set, invincibility))
				_add_ability_callbacks(migration_callbacks, invincibility.window[2], closure(AbilityBuildingBlocks.hero_invincibility_exit, invincibility))
			end
		end
	else
		local movements = ability_info.movements

		if movements then
			for i, movement in ipairs(movements) do
				local window = {
					movement.window[1] / afps,
					movement.window[2] / afps,
				}

				movement.duration = window[2] - window[1]

				debug_cond_error(not math.is_zero(movement.duration), "Can't have a movement window with 0 duration! (ability_name=%s)", ability_name)

				if movement.type == "slide" then
					local t = movement.duration
					local a = (movement.translation + t * t * t / 3) / t

					movement.velocity_function = function (t)
						return math.max(a - t * t, 0)
					end
				elseif movement.type == "step" or movement.type == nil then
					movement.speed = movement.translation / movement.duration
					movement.speed_z = (movement.translation_z or 0) / movement.duration
				end

				_add_ability_callbacks(ability_callbacks, movement.window[1], AbilityBuildingBlocks.movement_prediction_enter)
				_add_ability_callbacks(ability_callbacks, movement.window[1], closure(AbilityBuildingBlocks.movement_prediction_update, movement), movement.duration)
				_add_ability_callbacks(ability_callbacks, movement.window[2], AbilityBuildingBlocks.movement_prediction_exit)

				movement.window = window
			end

			exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.movement_prediction_exit
		end

		local custom_movement = ability_info.custom_movement

		if custom_movement then
			_add_ability_callbacks(ability_callbacks, 0, AbilityBuildingBlocks.custom_movement_setup)

			local start_frame = custom_movement.start or 0
			local end_frame = start_frame + custom_movement.duration

			if custom_movement.on_enter then
				AbilityAux.build_event_callbacks(custom_movement.on_enter, ability_info)
				_add_ability_callbacks(ability_callbacks, start_frame, closure(AbilityBuildingBlocks.run_ability_event_callbacks, custom_movement.on_enter))
			end

			if custom_movement.on_exit then
				AbilityAux.build_event_callbacks(custom_movement.on_exit, ability_info)
				_add_ability_callbacks(ability_callbacks, end_frame, closure(AbilityBuildingBlocks.run_ability_event_callbacks, custom_movement.on_exit))
			end
		end

		if movements == nil and custom_movement == nil then
			local unit_settings = LuaSettingsManager:get_settings_by_settings_path(settings_path)

			if unit_settings.animation_driven_movement then
				_add_ability_callbacks(ability_callbacks, 0, AbilityBuildingBlocks.movement_ability_prediction_enter)

				exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.movement_ability_prediction_exit
			end
		end
	end

	local spawn_units = ability_info.spawn_units

	if spawn_units then
		for i, spawn in ipairs(spawn_units) do
			if spawn.time_interval then
				local start_time = spawn.time

				while start_time <= duration_in_frames do
					_add_ability_callbacks(ability_callbacks, start_time, closure(AbilityBuildingBlocks.spawn_ability_unit, table.clone(spawn)))

					local interval = spawn.time_interval

					if spawn.time_interval_variation then
						interval = spawn.time_interval_variation * (math.random() * 2 - 1)
					end

					start_time = start_time + interval
				end
			else
				debug_cond_error(infinite or duration_in_frames >= spawn.time, "spawn_units contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, spawn.time, closure(AbilityBuildingBlocks.spawn_ability_unit, spawn))
			end
		end
	end

	if ability_info.ignore_interrupt then
		ability_info.ignore_interrupts = {
			{
				window = {
					0,
					duration_in_frames,
				},
			},
		}
	end

	local ignore_interrupts = ability_info.ignore_interrupts

	if ignore_interrupts then
		for i, ignore_interrupt in ipairs(ignore_interrupts) do
			debug_cond_error(infinite or duration_in_frames >= ignore_interrupt.window[1], "ignore_interrupts contains min frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, ignore_interrupt.window[1], closure(AbilityBuildingBlocks.ignore_interrupt_set, true))

			if ignore_interrupt.window[2] then
				debug_cond_error(infinite or duration_in_frames >= ignore_interrupt.window[2], "ignore_interrupts contains max frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, ignore_interrupt.window[2], closure(AbilityBuildingBlocks.ignore_interrupt_set, false))
			end
		end
	end

	if ability_info.ignore_shock then
		ability_info.ignore_shocks = {
			{
				window = {
					0,
					duration_in_frames,
				},
			},
		}
	end

	local ignore_shocks = ability_info.ignore_shocks

	if ignore_shocks then
		for i, ignore_shock in ipairs(ignore_shocks) do
			debug_cond_error(infinite or duration_in_frames >= ignore_shock.window[1], "ignore_shocks contains min frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, ignore_shock.window[1], closure(AbilityBuildingBlocks.ignore_shock_set, true))

			if ignore_shock.window[2] then
				debug_cond_error(infinite or duration_in_frames >= ignore_shock.window[2], "ignore_shocks contains max frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, ignore_shock.window[2], closure(AbilityBuildingBlocks.ignore_shock_set, false))
			end
		end

		exit_callbacks[#exit_callbacks + 1] = AbilityBuildingBlocks.ignore_shock_exit
	end

	local flow_events = ability_info.flow_events

	if flow_events then
		for i, flow_event in ipairs(flow_events) do
			debug_cond_error(flow_event.event_name, "Flow event declaration without 'event_name' (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			debug_cond_error(infinite or duration_in_frames >= flow_event.time, "flow_events contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, flow_event.time, closure(AbilityBuildingBlocks.flow_event_play, flow_event.event_name))
		end
	end

	local level_flow_events = ability_info.level_flow_events

	if level_flow_events then
		for i, level_flow_event in ipairs(level_flow_events) do
			debug_cond_error(level_flow_event.event_name, "Level flow event declaration without 'event_name' (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			debug_cond_error(infinite or duration_in_frames >= level_flow_event.time, "level_flow_events contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, level_flow_event.time, closure(AbilityBuildingBlocks.level_flow_event_play, level_flow_event.event_name))
		end
	end

	local animation_events = ability_info.animation_events

	if ability_info.animation then
		animation_events = animation_events or {}
		animation_events[#animation_events + 1] = {
			time = 0,
			event_name = ability_info.animation,
		}
	end

	if animation_events then
		for i, animation_event in ipairs(animation_events) do
			debug_cond_error(animation_event.event_name, "Animation event declaration without 'event_name' (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			debug_cond_error(infinite or duration_in_frames >= animation_event.time, "animation_event contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
			_add_ability_callbacks(ability_callbacks, animation_event.time, closure(AbilityBuildingBlocks.animation_event_play, animation_event.event_name))
		end
	end

	local events = ability_info.events

	if events then
		debug_cond_error(table.map_size(events) == #events, "Events contains non-numeric keys, it must be an array of events")
		debug_cond_error(#events < 2^AbilityAux.BITS_EVENT, "Can't have more than 15 ability events in one ability!")

		local event_index = 1
		local new_events = {}

		for i, event_info in ipairs(events) do
			debug_cond_error(type(event_info) == "table", "Ability Events must be an array (ability_name=%s)", ability_name)

			event_info.index = event_index
			new_events[event_index] = event_info
			event_index = event_index + 1

			if event_info.inherit_from then
				handle_inheritance(event_info, settings, ability_name, settings_path)
			end

			if event_info.event_start then
				debug_cond_error(infinite or duration_in_frames >= event_info.event_start, "events contains start frame that is greater than duration! (ability_name=%t, settings_path=%t)", ability_name, settings_path)
				_add_ability_callbacks(ability_callbacks, event_info.event_start, closure(AbilityBuildingBlocks.start_ability_query_event, event_info))

				event_info.event_start = event_info.event_start / afps
			end

			event_info.event_duration = event_info.event_duration and event_info.event_duration / afps
			event_info.refresh_hitlist_time = event_info.refresh_hitlist_time and event_info.refresh_hitlist_time / afps
			event_info.time = event_info.event_duration
			event_info.mode = ability_info.mode

			if event_info.type then
				local query_type = event_info.type

				if AbilityEventAux.is_projectile_by_type(query_type) then
					local origin_type = event_info.stagger_origin_type

					debug_cond_error(origin_type ~= "character", "Stagger origin type cannot be set to 'character' for projectiles! (can't guarantee that caster exists when projectile hit!")
				else
					local origin_type = event_info.stagger_origin_type

					debug_cond_error(origin_type ~= "direction", "Stagger origin type cannot be set to 'direction' for non-projectiles!")
				end
			end

			local spawn_entities = event_info.spawn_entities

			if spawn_entities then
				for i, spawn in ipairs(spawn_entities) do
					if spawn.time then
						spawn.time = spawn.time / afps
					end

					if spawn.time_interval then
						spawn.time_interval = spawn.time_interval / afps
					end

					if spawn.time_interval_variation then
						spawn.time_interval_variation = spawn.time_interval_variation / afps
					end
				end
			end

			if event_info.loop then
				local loop = event_info.loop
				local last_event_info = event_info

				for i = 2, loop.count do
					local new_event_info = table.clone(last_event_info)

					if duration_in_frames >= last_event_info.event_start then
						new_event_info.event_start = last_event_info.event_start * afps + loop.frequency

						if loop.increments then
							for name, value in pairs(loop.increments) do
								new_event_info[name] = new_event_info[name] + value
							end
						end

						new_event_info.index = event_index
						new_events[event_index] = new_event_info
						event_index = event_index + 1

						_add_ability_callbacks(ability_callbacks, new_event_info.event_start, closure(AbilityBuildingBlocks.start_ability_query_event, new_event_info))

						new_event_info.event_start = new_event_info.event_start / afps
						last_event_info = new_event_info
					end
				end
			end
		end

		ability_info.events = new_events
	end

	if ability_info.on_enter then
		AbilityAux.build_event_callbacks(ability_info.on_enter, ability_info)
	end

	if ability_info.on_complete then
		AbilityAux.build_event_callbacks(ability_info.on_complete, ability_info)
		_add_ability_callbacks(ability_callbacks, duration_in_frames, closure(AbilityBuildingBlocks.run_ability_event_callbacks, ability_info.on_complete))
	end

	if ability_info.custom_update then
		_add_ability_callbacks(ability_callbacks, 0, ability_info.custom_update, math.huge)
	end

	if ability_info.on_exit then
		AbilityAux.build_event_callbacks(ability_info.on_exit, ability_info)

		exit_callbacks[#exit_callbacks + 1] = closure(AbilityBuildingBlocks.run_ability_event_callbacks, ability_info.on_exit)
	end

	if master_version and ability_info.on_collided then
		AbilityAux.build_event_callbacks(ability_info.on_collided, ability_info)
		_add_ability_callbacks(ability_callbacks, ability_info.on_collided.time, closure(AbilityBuildingBlocks.check_collided, ability_info.on_collided), math.huge)
	end

	if ability_info.duration >= 0 then
		_add_ability_callbacks(ability_callbacks, duration_in_frames, AbilityBuildingBlocks.on_ability_done)
	end

	Profiler.stop()

	return ability_info
end

AbilityAux.create_combo_node = function (settings, ability_name, settings_path)
	local ability_settings = settings[ability_name]

	if ability_settings.event_data or ability_settings.ability_data then
		return
	end

	Profiler.start("create_combo_node %s", ability_name)

	local ability_info = table.clone(ability_settings)

	ability_info.name = ability_name
	ability_info.settings_path = settings_path

	if ability_info.inherit_from then
		handle_inheritance(ability_info, settings, ability_name, settings_path)
	end

	local afps = _G.ANIMFRAMES_PER_SECOND
	local infinite = ability_info.mode == "infinite"

	if not infinite then
		local duration = ability_info.duration

		duration = math.round(duration)
		ability_info.duration = duration
	end

	local duration_in_frames = ability_info.duration

	ability_info.duration = not infinite and duration_in_frames / afps or -1

	if not infinite then
		ability_info.combo_end = (ability_info.combo_end or duration_in_frames) / afps
	end

	local buffer_to = ability_info.buffer_to

	if buffer_to then
		for key, value in pairs(buffer_to) do
			if type(value) == "table" then
				buffer_to[key] = {
					value[1] / afps,
					value[2] / afps,
				}
			else
				buffer_to[key] = value / afps
			end
		end
	end

	local cancel_to = ability_info.cancel_to

	if cancel_to then
		for key, value in pairs(cancel_to) do
			if type(value) == "table" then
				cancel_to[key] = {
					value[1] / afps,
					value[2] / afps,
				}
			else
				cancel_to[key] = value / afps
			end
		end
	end

	Profiler.stop()

	return ability_info
end

AbilityAux.build_event_callbacks = function (event_info, ability_info)
	local event_callbacks = {}

	event_info.event_callbacks = event_callbacks

	if event_info.animation_event then
		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.animation_event_play, event_info.animation_event)
	end

	if event_info.flow_event then
		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.flow_event_play, event_info.flow_event)
	end

	if event_info.timpani_event then
		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.timpani_event_play, event_info.timpani_event)
	end

	if event_info.custom_callback then
		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.trigger_custom_callback, event_info.custom_callback)
	end

	if event_info.ability then
		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.execute_ability, event_info.ability)
	end

	if event_info.run_ability_event_index then
		local event = ability_info.events[event_info.run_ability_event_index]

		event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.start_ability_query_event, event)
	end

	if event_info.run_ability_event_indices then
		for i, event_index in ipairs(event_info.run_ability_event_indices) do
			local event = ability_info.events[event_index]

			event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.start_ability_query_event, event)
		end
	end

	if event_info.spawn_entities then
		local spawn_entities = event_info.spawn_entities

		for i, spawn in ipairs(spawn_entities) do
			event_callbacks[#event_callbacks + 1] = closure(AbilityBuildingBlocks.spawn_ability_entity, spawn)
		end
	end
end

AbilityAux.scale_delta_time = function (unit, dt)
	if not EntityAux.has_component(unit, "animation") then
		return dt
	end

	return dt * EntityAux.state(unit, "animation").animation_speed
end

AbilityAux.modify_target_position = function (component, caster_unit, target_position, target_modifiers)
	local pass_through_walls = target_modifiers.pass_through_walls

	if pass_through_walls then
		local radius = target_modifiers.max_radius or target_modifiers.radius
		local theta = component.randomizer:rangef(0, math.tau)
		local offset = Vector3(math.sin(theta) * radius, math.cos(theta) * radius, 0)
		local z = target_position.z

		target_position = QueryManager:snap_to_navgrid(target_position + offset, radius)
		target_position.z = z
	elseif target_modifiers.distance then
		local origin_position = Unit.world_position(caster_unit, 0)
		local towards_target = Vector3.normalize(target_position - origin_position)
		local target_position = origin_position + towards_target * target_modifiers.distance
		local sweep_position, _ = component.nav_grid:sweep_circle(origin_position, target_position, 0.5)

		target_position = sweep_position or target_position
	else
		local min_radius = target_modifiers.min_radius or 0
		local max_radius = target_modifiers.max_radius or target_modifiers.radius

		target_position = QueryManager:query_position_in_hollow_disc(target_position, min_radius, max_radius, 0.5)
	end

	return target_position
end
