﻿-- chunkname: @lua/components/monster_spawner_component.lua

require("foundation/lua/component/base_component")
require("lua/ai_states/state_machine_ai")
require("lua/ai_states/state_common_builder_spawner")
require("lua/ai_states/state_common_spawner")

MonsterSpawnerComponent = class("MonsterSpawnerComponent", "BaseComponent")

MonsterSpawnerComponent.init = function (self, creation_context)
	BaseComponent.init(self, "monster_spawner", creation_context)
	self:register_events("on_death", "on_entity_unregistering", "on_party_changed")

	self.all_state_machines = {}

	self:register_flow_events("spawner_switch_on", "spawner_switch_off")

	self.spawning_disabled = false
	self.nav_grid = creation_context.nav_grid
	self.players_count = 1
	self.waves_info = require("gameobjects/spawners/spawner_waves")
end

MonsterSpawnerComponent.on_script_reload = function (self)
	self.all_state_machines = {}
	self.waves_info = require("gameobjects/spawners/spawner_waves")

	BaseComponent.on_script_reload(self)
end

MonsterSpawnerComponent.reload_master = function (self, unit, context)
	local state, settings = context.state, context.settings
	local settings_path = Unit.get_data(unit, "settings_path")
	local states = self.all_state_machines[settings_path]

	if states == nil then
		states = settings.states(self)
		self.all_state_machines[settings_path] = states
	end

	state.all_states = states

	local spawner_info = self:get_spawner_info(unit, context)

	state.spawner_info = spawner_info

	local spawn_nodes = spawner_info.spawn_nodes

	if spawn_nodes then
		state.spawn_nodes = {}

		self:verify_spawn_nodes(unit, context, spawn_nodes)
	end
end

MonsterSpawnerComponent.verify_spawn_nodes = function (self, unit, context, spawn_nodes)
	local state = context.state

	for i, spawn_info in ipairs(spawn_nodes) do
		local s_info = table.clone(spawn_info)

		if s_info.duration then
			local frames = s_info.duration

			s_info.duration = frames * 0.03333333333333333
		end

		s_info.node_index = Unit.node(unit, s_info.node_name)
		state.spawn_nodes[#state.spawn_nodes + 1] = s_info
	end
end

MonsterSpawnerComponent.setup_master = function (self, unit, context, setup_info)
	local state, settings = context.state, context.settings

	state.spawner_wave_selection = setup_info and setup_info.spawner_wave_selection or settings.spawner_wave_selection

	self:reload_master(unit, context)

	state.current_state_name = "active"
	state.previous_state_name = state.current_state_name

	StateMachineAI.on_enter(self, unit, context)

	state.nr_enemies = 0
	state.spawned_monsters = {}
	state.turbo_duration = nil
	state.turbo_buffed = false
end

MonsterSpawnerComponent.setup_slave = function (self, unit, context)
	self:register_unit_events(unit, "unit_on_death")

	local spawner_info = self:get_spawner_info(unit, context)
	local visibility_group = spawner_info.visibility_group

	if visibility_group and Unit.has_visibility_group(unit, visibility_group) then
		Unit.set_visibility(unit, visibility_group, true)
	end

	local light_color = spawner_info.light_color

	if light_color and Unit.has_light(unit, "light") then
		local light = Unit.light(unit, "light")
		local color = Vector3(unpack(light_color))

		Light.set_color(light, color)
	end
end

MonsterSpawnerComponent.remove_slave = function (self, unit, context)
	self:unregister_unit_event(unit, "unit_on_death")
end

MonsterSpawnerComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		StateMachineAI.update(self, unit, context, dt)
	end
end

MonsterSpawnerComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.turbo_buffed then
			if not state.previous_turbo_buffed then
				Unit.flow_event(unit, "on_turbo_buff_enabled")

				state.previous_turbo_buffed = true
			end
		elseif state.previous_turbo_buffed then
			Unit.flow_event(unit, "on_turbo_buff_disabled")

			state.previous_turbo_buffed = false
		end
	end
end

MonsterSpawnerComponent.spawn = function (self, unit, context, path)
	if self.spawning_disabled then
		return
	end

	local state = context.state
	local spawn_info

	if state.spawn_nodes and #state.spawn_nodes > 0 then
		local found = false

		for i = 1, 100 do
			local index = math.random(#state.spawn_nodes)

			spawn_info = state.spawn_nodes[index]

			if _G.GAME_TIME > (spawn_info.dont_spawn_until or 0) then
				spawn_info.dont_spawn_until = _G.GAME_TIME + spawn_info.duration
				found = true

				break
			end
		end

		if not found then
			return
		end
	end

	if spawn_info == nil then
		state.spawning_disabled = true

		return
	end

	local pose = Unit.world_pose(unit, spawn_info.node_index)
	local setup_info = {
		spawn_info_key = spawn_info.spawn_info_key or "default",
	}

	for i, tag in SpawnedEntityTags.tags_iterator(unit) do
		local info = SpawnedEntityTags[tag]

		if info then
			for k, v in pairs(info) do
				setup_info[k] = v
			end
		end
	end

	local position = Matrix4x4.translation(pose)
	local rotation = Matrix4x4.rotation(pose)

	if spawn_info.random_rotation then
		rotation = Quaternion.random_direction_xy()
	end

	if spawn_info.random_position_offset then
		local random_info = spawn_info.random_position_offset
		local max_radius = random_info.max_radius
		local min_radius = random_info.min_radius
		local unit_radius = random_info.unit_radius or 1

		position = QueryManager:query_position_in_hollow_disc(position, min_radius, max_radius, unit_radius)
	elseif spawn_info.position_offset then
		local rotation = Matrix4x4.rotation(pose)
		local position_offset = spawn_info.position_offset and Vector3Aux.unbox(spawn_info.position_offset) or Vector3.zero()

		position_offset = Quaternion.rotate(rotation, position_offset)
		position = position + position_offset
	end

	local monster = AIManager:spawn_monster(path, position, rotation, nil, setup_info)

	if monster then
		state.spawned_monsters[monster] = true
		state.nr_enemies = table.map_size(state.spawned_monsters)

		Unit.set_flow_variable(unit, "enemy", monster)
		Unit.flow_event(unit, "enemy_spawned")

		return true
	end
end

MonsterSpawnerComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "spawn" then
		self:spawn(unit, context, data)
	elseif command_name == "toggle" then
		state.spawning_disabled = not state.spawning_disabled
	elseif command_name == "set_enable" then
		state.spawning_disabled = not data

		local wave = state.current_wave

		if wave then
			wave.timer = nil

			local info = state.current_wave_info

			if info.timer then
				info.timer = 0
			end
		end
	elseif command_name == "force_initialize" then
		state.force_initialize = true
	elseif command_name == "turbo_buff" then
		local waves_info = self:get_waves_info(unit, context)

		state.turbo_buffed = data.is_buffed
	end
end

MonsterSpawnerComponent.get_waves_info = function (self, unit, context)
	local state = context.state

	return self.waves_info[state.spawner_wave_selection]
end

MonsterSpawnerComponent.get_spawner_info = function (self, unit, context)
	local state = context.state

	return self.waves_info[state.spawner_wave_selection].spawner_info
end

MonsterSpawnerComponent.spawner_switch_on = function (self, params)
	local unit = params.unit

	if EntityAux.owned(unit) then
		self:queue_command_master(unit, "monster_spawner", "set_enable", true)
		self:queue_command_master(unit, "monster_spawner", "force_initialize")
	end
end

MonsterSpawnerComponent.spawner_switch_off = function (self, params)
	local unit = params.unit

	if EntityAux.owned(unit) then
		self:queue_command_master(unit, "monster_spawner", "set_enable", false)
	end
end

MonsterSpawnerComponent.unit_on_death = function (self, unit)
	local num_actors = Unit.num_actors(unit)

	for i = 1, num_actors do
		Unit.destroy_actor(unit, i - 1)
	end

	if EntityAux.has_component(unit, "ability") then
		self:queue_command(unit, "ability", "set_enabled", false)
	end
end

MonsterSpawnerComponent.on_death = function (self, dead_unit)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		state.spawned_monsters[dead_unit] = nil
		state.nr_enemies = table.map_size(state.spawned_monsters)
	end
end

MonsterSpawnerComponent.on_entity_unregistering = function (self, entity)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		state.spawned_monsters[entity] = nil
		state.nr_enemies = table.map_size(state.spawned_monsters)
	end
end

MonsterSpawnerComponent.on_party_changed = function (self, players, players_map, players_type, players_count)
	self.players_count = players_count > 0 and players_count or 1
end

MonsterSpawnerComponent.setup_console_plugin = function (self)
	local unit_paths = require("lua/generated/unit_paths")
	local plugin = {
		spawner = function (argument_array, command_string)
			if argument_array[2] == "spawn" then
				local unit_path, target = argument_array[3], argument_array[4]

				if tonumber(target) == nil then
					return {
						error = true,
						message = "Must specify a GOID of the spawner you which to spawn from.",
					}
				end

				local path_exists, msg = PluginComponentAux.path_exists(unit_path)

				if path_exists then
					msg = {
						message = sprintf("Spawns %s from %s.", unit_path, PluginComponentAux.target_description(target)),
					}
					msg = PluginComponentAux.execute_command(self, "spawn", unit_path, target) or msg
				else
					msg = {
						error = true,
						message = sprintf("Path not found %s.", unit_path),
					}
				end

				return msg
			elseif argument_array[2] == "toggle" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Toggling spawning for %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "toggle", true, target) or msg

				return msg
			elseif argument_array[2] == "toggle_all_spawning" then
				self.spawning_disabled = not self.spawning_disabled

				return {
					message = sprintf("Spawning is now %s", self.spawning_disabled and "disabled" or "enabled"),
				}
			end
		end,
	}
	local units = {}

	for k, v in pairs(unit_paths) do
		if type(v) == "string" then
			units[#units + 1] = v
		end
	end

	table.sort(units)

	local auto_complete = {
		spawner = {
			"toggle",
			"toggle_all_spawning",
			spawn = units,
		},
	}
	local docs = {
		spawner = {
			text = "Toggle or spawn units from spawners.",
			spawn = {
				text = "Spawn a unit from a spawner. You must specify a go_id for the spawner.",
				usage = "spawn <unit_path> go_id",
			},
			toggle = {
				text = "Toggles spawning from a spawner. You must specify a go_id for the spawner.",
				usage = "spawn <unit_path> go_id",
			},
			toggle_all_spawning = {
				text = "Completely turns on/off all current and future spawners.",
				usage = "toggle_all_spawning",
			},
		},
	}

	return plugin, auto_complete, docs
end
