﻿-- chunkname: @lua/components/boss_health_bar_component.lua

BossHealthBarComponent = class("BossHealthBarComponent", "BaseComponent")

BossHealthBarComponent.init = function (self, creation_context)
	BaseComponent.init(self, "boss_health_bar", creation_context)
end

BossHealthBarComponent.destroy = function (self)
	for unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local state = context.state

		if state.widget then
			GUI:destroy_widget(state.widget)

			state.widget = nil
		end
	end

	BaseComponent.destroy(self)
end

BossHealthBarComponent.setup_master = function (self, unit, context, setup_info)
	context.state.bar_active = false
end

BossHealthBarComponent.setup_slave = function (self, unit, context, setup_info)
	self:reload_slave(unit, context)
end

BossHealthBarComponent.reload_slave = function (self, unit, context)
	local state = context.state

	if state.widget then
		GUI:destroy_widget(state.widget)

		state.widget = nil
	end

	state.widget = GUI:load_widget_at("gui/boss_ui")

	state.widget:get("name"):set_text(tr(context.settings.name))
	state.widget:set_alpha(0)
	GUI:add_widget(state.widget)
end

BossHealthBarComponent.remove_slave = function (self, unit, context)
	local state = context.state

	if state.widget then
		GUI:destroy_widget(state.widget)

		state.widget = nil
	end
end

BossHealthBarComponent.call_master_set_active = function (self, unit, context, data)
	context.state.bar_active = data

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).bar_active = data
end

BossHealthBarComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entities = self.entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(entities) do
		local state = context.state
		local health = 0
		local widget = state.widget

		if DamageReceiverComponent.is_alive(unit) then
			local alpha = widget:get_alpha()

			alpha = math.saturate(alpha + dt)

			widget:set_alpha(alpha)

			local damage_state = EntityAux.state_interface(unit, "i_damage_receiver")

			health = damage_state.hitpoints / damage_state.max_hitpoints
			alpha = state.bar_active and Game:get_hud_alpha() or 0

			widget:set_alpha(alpha)
		else
			local alpha = widget:get_alpha()

			alpha = math.saturate(alpha - dt)

			widget:set_alpha(alpha)

			health = 0
		end

		local health_bar = widget:get("health")
		local health_bar_glow = widget:get("health_glow")
		local healthbar_width = health * 100

		health_bar:set_size({
			sprintf("%d%%", healthbar_width),
			"90%",
		})
		health_bar_glow:set_size({
			sprintf("%d%%", healthbar_width),
			"210%",
		})
		health_bar:set_bg_color(TempTableFactory:get_array(255, 255, 255))
		health_bar_glow:set_alpha(0.5)
	end

	Profiler.stop()
end
