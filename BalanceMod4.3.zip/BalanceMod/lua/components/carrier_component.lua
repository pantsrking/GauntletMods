﻿-- chunkname: @lua/components/carrier_component.lua

require("foundation/lua/component/base_component")

CarrierComponent = class("CarrierComponent", "BaseComponent")

CarrierComponent.init = function (self, creation_context)
	BaseComponent.init(self, "carrier", creation_context)

	self.nav_grid = creation_context.nav_grid

	self:register_dependencies("carryable", "motion", "ability")
	self:register_rpc_events("rpc_carry_enter", "rpc_carry_exit", "game_object_sync_done")
	self:register_events("on_carry_enter", "on_carry_exit", "on_entity_unregistering")
end

local function _get_node_index(unit)
	local settings = LuaSettingsManager:get_settings_by_unit(unit)
	local node_index = Unit.node(unit, settings.carry_attach_node)

	return node_index
end

local function _set_motion_enable(unit, state, enable)
	EntityAux.queue_command_master(unit, "motion", enable and "enable" or "disable", "carrier")

	state.motion_enabled = enable
end

local function _set_rotation_enable(unit, state, enable)
	EntityAux.queue_command_master(unit, "rotation", enable and "enable" or "disable", "carrier")

	state.rotation_enabled = enable
end

CarrierComponent._enter_carrying = function (self, unit, state)
	_set_motion_enable(unit, state, true)
	_set_rotation_enable(unit, state, true)

	state.carry_state = "carrying"
end

CarrierComponent._exit_carrying = function (self, unit, state)
	if not state.motion_enabled then
		_set_motion_enable(unit, state, true)
	end

	if not state.rotation_enabled then
		_set_rotation_enable(unit, state, true)
	end

	state.throw_direction = nil
	state.carry_state = "done"
	state.carrying = false
end

CarrierComponent._enter_liftup = function (self, unit, state, carryable_unit)
	_set_motion_enable(unit, state, false)
	_set_rotation_enable(unit, state, false)

	local carryable_settings = LuaSettingsManager:get_settings_by_unit(carryable_unit)

	state.carry_data = {
		migrated = false,
		carryable_unit = carryable_unit,
		carryable_settings = carryable_settings,
	}
	state.animation_timer = (carryable_settings.carry_info.enter.duration or 30) / _G.ANIMFRAMES_PER_SECOND
	state.carry_state = "liftup"
end

CarrierComponent._update_liftup = function (self, unit, state, dt)
	local carry_data = state.carry_data

	state.animation_timer = state.animation_timer - dt

	local carryable_unit = carry_data.carryable_unit
	local status = InteractableComponent.check_interaction_migration_status(unit, carryable_unit)

	if status == InteractableComponent.MIGRATION_DONE then
		if not carry_data.migrated then
			carry_data.migrated = true

			self:trigger_event("on_carry_enter", unit, carryable_unit)
			self:trigger_rpc_event_to_others("rpc_carry_enter", unit, carryable_unit)
		end

		if state.animation_timer <= 0 then
			self:_enter_carrying(unit, state)
		end
	elseif status == InteractableComponent.MIGRATION_ERROR then
		self:_exit_carrying(unit, state)
	end
end

CarrierComponent._enter_throwing = function (self, unit, state, throw_direction)
	local carry_data = state.carry_data
	local carryable_settings = carry_data.carryable_settings
	local should_throw = throw_direction ~= nil
	local animation_info

	if should_throw then
		state.throw_direction = Vector3Aux.box_copy({}, throw_direction)
		animation_info = carryable_settings.carry_info.throw
	else
		animation_info = carryable_settings.carry_info.dropoff
	end

	_set_motion_enable(unit, state, false)
	_set_rotation_enable(unit, state, false)

	state.animation_timer = self:start_exit_sequence(unit, carry_data.carryable_unit, animation_info, true)
	state.post_detach_timer = (animation_info.duration - animation_info.detach_at) / ANIMFRAMES_PER_SECOND
	state.carry_state = "throwing"
end

CarrierComponent._throw_or_drop = function (self, unit, state, dt)
	local carryable_unit = state.carry_data.carryable_unit

	self:trigger_event("on_carry_exit", unit, carryable_unit)
	self:trigger_rpc_event_to_others("rpc_carry_exit", unit, carryable_unit)

	if Unit.get_data(carryable_unit, "exploded") then
		return
	end

	if state.throw_direction then
		self:_throw_carryable(unit, state, Vector3Aux.unbox(state.throw_direction))
	else
		self:_drop_carryable(unit, state)
	end

	self:_enter_detached(unit, state)
end

CarrierComponent._update_throwing = function (self, unit, state, dt)
	state.animation_timer = state.animation_timer - dt

	if state.animation_timer <= 0 then
		self:_throw_or_drop(unit, state, dt)
	end
end

CarrierComponent._enter_detached = function (self, unit, state)
	if state.post_detach_timer then
		state.carry_state = "detached"
		state.animation_timer = state.post_detach_timer or 0
	else
		self:_exit_carrying(unit, state)
	end
end

CarrierComponent._update_detached = function (self, unit, state, dt)
	state.animation_timer = state.animation_timer - dt

	if state.animation_timer <= 0 then
		self:_exit_carrying(unit, state)
	end
end

CarrierComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entity_manager = self.entity_manager
	local master_entities = entity_manager:get_master_entities(self.name)
	local slave_entities = entity_manager:get_slave_entities(self.name)

	Profiler.start("command_masters")
	self:command_masters(master_entities)
	Profiler.stop()
	Profiler.start("update_masters")
	self:update_masters(master_entities, dt)
	Profiler.stop()
	Profiler.start("command_slaves")
	self:command_slaves(slave_entities)
	Profiler.stop()
	Profiler.start("update_slaves")
	self:update_slaves(slave_entities, dt)
	Profiler.stop()
	Profiler.stop()
end

CarrierComponent.update_masters = function (self, entities, dt)
	for unit, context in pairs(entities) do
		repeat
			local state = context.state

			if state.carry_state == nil then
				break
			end

			if state.carry_state == "liftup" then
				self:_update_liftup(unit, state, dt)

				break
			end

			if state.carry_state == "carrying" then
				break
			end

			if state.carry_state == "throwing" then
				self:_update_throwing(unit, state, dt)

				break
			end

			if state.carry_state == "detached" then
				self:_update_detached(unit, state, dt)
			end
		until true
	end
end

CarrierComponent.find_dropoff_position = function (unit, carryable_unit, physics_world, nav_grid, search_radius)
	local current_position = Unit.world_position(carryable_unit, 0)
	local my_position = Unit.world_position(unit, 0)
	local snapped_position = nav_grid:snap_to_grid(my_position, search_radius)
	local to_snapped_position = snapped_position - my_position
	local any_hit, _, _, _, _ = PhysicsWorld.immediate_raycast(physics_world, my_position, Vector3.normalize(to_snapped_position), Vector3.length(to_snapped_position), "closest", "types", "both", "collision_filter", "wall")
	local position

	if any_hit then
		position = my_position
	else
		position = nav_grid:sweep_circle(snapped_position, current_position, 0.4)
		position.z = current_position.z
	end

	return position, snapped_position
end

CarrierComponent._drop_carryable = function (self, unit, state)
	local data = state.carry_data
	local carryable_unit = data.carryable_unit

	self:detach_carryable(carryable_unit)

	local dropoff_position = CarrierComponent.find_dropoff_position(unit, carryable_unit, self.world_proxy:get_physics_world(), self.nav_grid, 2)

	Unit.teleport_local_position(carryable_unit, 0, dropoff_position)
	self:trigger_rpc_event_to_others("rpc_teleport_slaves", carryable_unit, dropoff_position)
	EntityAux.queue_command_master(carryable_unit, "motion", "force_set_position", Vector3Aux.box_temp(dropoff_position))
	Unit.flow_event(carryable_unit, "on_dropped")
	self:trigger_rpc_event_to_others("flow_event", carryable_unit, "on_dropped")
	EntityAux.queue_command_master(carryable_unit, "carryable", "reactivate", true)
end

CarrierComponent._throw_carryable = function (self, unit, state, throw_direction)
	local data = state.carry_data
	local carryable_unit = data.carryable_unit

	self:detach_carryable(carryable_unit)

	local dropoff_position = CarrierComponent.find_dropoff_position(unit, carryable_unit, self.world_proxy:get_physics_world(), self.nav_grid, 5)

	EntityAux.queue_command_master(carryable_unit, "motion", "enable", "carryable")
	EntityAux.queue_command_master(carryable_unit, "motion", "change_state", "dynamic")
	EntityAux.queue_command_master(carryable_unit, "motion", "constrain_to_mover", true)
	EntityAux.queue_command_master(carryable_unit, "motion", "force_set_position", Vector3Aux.box_temp(dropoff_position))
	Unit.flow_event(carryable_unit, "on_thrown")
	self:trigger_rpc_event_to_others("flow_event", carryable_unit, "on_thrown")
	Unit.flow_event(unit, "carryable_thrown")
	self:trigger_rpc_event_to_others("flow_event", unit, "carryable_thrown")

	local carry_info = data.carryable_settings.carry_info
	local upward_speed, directional_speed = carry_info.throw.upward_speed, carry_info.throw.directional_speed
	local velocity = Vector3.up() * upward_speed + throw_direction * directional_speed

	EntityAux.queue_command_master(carryable_unit, "motion", "set_velocity", Vector3Aux.box(TempTableFactory:get(), velocity))

	local settings = LuaSettingsManager:get_settings_by_unit(carryable_unit)
	local ability_name = settings.carryable_thrown_ability_name or "barrel_toss"
	local settings_path = settings.carryable_thrown_ability_name == nil and "characters/generic_abilities" or nil
	local command = TempTableFactory:get_map("ability_name", ability_name, "settings_path", settings_path, "owner_unit", unit)

	EntityAux.queue_command_master(carryable_unit, "ability", "execute_ability", command)
	self.scheduler:repeat_action(0.1, function ()
		if Unit.alive(carryable_unit) then
			if not EntityAux.owned(carryable_unit) then
				return false
			end

			local velocity = MotionState.get_velocity(EntityAux.state_master(carryable_unit, "motion").motion_state)
			local done = Vector3.length_squared(velocity) <= math.EPSILON

			if done then
				EntityAux.queue_command_master(carryable_unit, "carryable", "reactivate", true)
				EntityAux.queue_command_master(carryable_unit, "motion", "constrain_to_mover", false)
			end

			return not done
		end

		return false
	end)
end

CarrierComponent.update_slaves = function (self, entities, dt)
	for unit, context in pairs(entities) do
		local state = context.state

		if state.active_attachment then
			local info = state.active_attachment
			local carryable_unit = info.carryable_unit
			local source_rotation = QuaternionAux.unbox(info.source_rotation)
			local source_position = Vector3Aux.unbox(info.source_position)
			local node_index = _get_node_index(unit)
			local target_rotation = Unit.world_rotation(unit, node_index)
			local target_position = Unit.world_position(unit, node_index)

			info.timer = info.timer + dt * info.speed

			if info.timer < info.duration then
				local timer = info.timer - info.translation_window[1]
				local t = math.saturate(timer / (info.translation_window[2] - info.translation_window[1]))
				local slerp = -2 * t * t * t + 3 * t * t
				local position = Vector3.lerp(source_position, target_position, slerp)

				Unit.set_local_position(carryable_unit, 0, position)

				if info.rotation_window then
					timer = info.timer - info.rotation_window[1]
					t = math.saturate(timer / (info.rotation_window[2] - info.rotation_window[1]))
					slerp = -2 * t * t * t + 3 * t * t

					local rotation = Quaternion.lerp(source_rotation, target_rotation, slerp)

					Unit.set_local_rotation(carryable_unit, 0, rotation)
				end
			else
				self:attach_carryable(unit, carryable_unit, info.carry_info.attach_node)

				state.active_attachment = nil
			end
		end
	end
end

CarrierComponent.command_master = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "set_carryable_ready" then
		state.carryable_ready = data
	elseif command_name == "remove_carryable_ready" then
		if Unit.alive(state.carryable_ready) then
			EntityAux.queue_command_master(state.carryable_ready, "interactable", "set_enabled", true)
			EntityAux.queue_command_master(unit, "interactor", "enable")
		end

		state.carryable_ready = nil
	elseif command_name == "enter_carry" then
		state.carrying = true

		self:_enter_liftup(unit, state, state.carryable_ready)

		state.carryable_ready = nil
	elseif command_name == "drop_carryable" then
		if state.carry_state == "carrying" then
			self:_enter_throwing(unit, state, nil)
		end
	elseif command_name == "throw_carryable" then
		if state.carry_state == "carrying" then
			self:_enter_throwing(unit, state, data)
		end
	elseif command_name == "force_drop_carryable" then
		if state.carry_state == "detached" then
			state.carrying = false
		elseif state.carry_state == "liftup" and not state.carry_data.migrated then
			local data = state.carry_data
			local carryable_unit = data.carryable_unit

			EntityAux.queue_command_slave(carryable_unit, "interactable", "set_cancelled_interaction")
			self:_exit_carrying(unit, state)

			state.carry_data = nil
			state.animation_timer = nil
		elseif state.carry_state ~= "done" then
			state.throw_direction = Vector3Aux.box({}, UnitAux.unit_forward(unit) * 0.75)

			self:_throw_or_drop(unit, state)

			state.carrying = false

			self:queue_command_slave(unit, self.name, command_name, data)
		end
	elseif command_name == "exit_carry" then
		self:_exit_carrying(unit, state)
	end
end

CarrierComponent.command_slave = function (self, unit, context, command_name, data)
	local state = context.state

	if command_name == "attach_to" then
		local carryable_unit = data

		if not Unit.alive(carryable_unit) then
			return
		end

		local carry_settings = LuaSettingsManager:get_settings_by_unit(carryable_unit)
		local carry_info = carry_settings.carry_info
		local source_rotation = QuaternionAux.box({}, Unit.local_rotation(carryable_unit, 0))
		local source_position = Vector3Aux.box({}, Unit.local_position(carryable_unit, 0))
		local window = carry_info.enter.translation_window
		local translation_window = {
			window[1] / 30,
			window[2] / 30,
		}

		window = carry_info.enter.rotation_window

		local rotation_window

		if window ~= nil and not math.equals(window[1], window[2]) then
			rotation_window = {
				window[1] / 30,
				window[2] / 30,
			}
		end

		state.active_attachment = {
			node = 0,
			speed = 2,
			timer = 0,
			carryable_unit = carryable_unit,
			duration = carry_info.enter.duration / 30,
			translation_window = translation_window,
			rotation_window = rotation_window,
			source_rotation = source_rotation,
			source_position = source_position,
			carry_info = carry_info,
		}
	elseif command_name == "force_drop_carryable" or command_name == "exit_carry" then
		local carryable_unit = data

		if Unit.alive(carryable_unit) then
			self:detach_carryable(carryable_unit)
		end

		state.active_attachment = nil
	end
end

CarrierComponent.attach_carryable = function (self, unit, carryable_unit, attach_node_name)
	local world = self.world_proxy:get_world()
	local node_index = _get_node_index(unit)

	World.link_unit(world, carryable_unit, 0, unit, node_index)
end

CarrierComponent.detach_carryable = function (self, carryable_unit)
	local world = self.world_proxy:get_world()

	World.unlink_unit(world, carryable_unit)
end

CarrierComponent.start_idle_sequence = function (self, unit, carryable_unit, carry_info)
	local animations = carry_info.idle

	EntityAux.queue_command_master(unit, "animation", "trigger_event", animations.animation)

	return animations.duration / _G.ANIMFRAMES_PER_SECOND
end

CarrierComponent.start_exit_sequence = function (self, unit, carryable_unit, carry_info, success)
	local animations = carry_info

	EntityAux.queue_command_master(unit, "animation", "trigger_event", animations.animation)

	return animations.detach_at / _G.ANIMFRAMES_PER_SECOND
end

CarrierComponent.on_entity_unregistering = function (self, unit)
	for carrier_unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state
		local carry_data = state.carry_data

		if unit == state.carryable_ready then
			state.carryable_ready = nil
		end

		if carry_data and (unit == carrier_unit or unit == carry_data.carryable_unit) and context.state.carry_state ~= "done" then
			local state = context.state
			local carryable_unit = carry_data.carryable_unit

			if EntityAux.owned(carryable_unit) then
				state.throw_direction = Vector3Aux.box_copy({}, UnitAux.unit_forward(carrier_unit) * 0.75)

				self:detach_carryable(carryable_unit)
				CarryableComponent.set_rotation(carryable_unit)
				self:_throw_or_drop(carrier_unit, state)
			end

			self:_exit_carrying(carrier_unit, state)
		end
	end

	for carrier_unit, context in self.entity_manager:all_slaves_iterator(self.name) do
		local active_attachment = context.state.active_attachment

		if active_attachment and active_attachment.carryable_unit == unit then
			context.state.active_attachment = nil
		end
	end
end

CarrierComponent.on_carry_enter = function (self, unit, carryable_unit)
	local settings = LuaSettingsManager:get_settings_by_unit(carryable_unit)
	local carry_info = settings.carry_info

	self:queue_command(unit, "ability", "interrupt")
	self:queue_command(carryable_unit, "carryable", "enter_carry", unit)
	self:queue_command_slave(unit, self.name, "attach_to", carryable_unit)
	EntityAux.queue_command(unit, "animation", "trigger_event_local", carry_info.enter.animation)
end

CarrierComponent.on_carry_exit = function (self, unit, carryable_unit)
	self:queue_command(carryable_unit, "carryable", "exit_carry")
end

CarrierComponent.rpc_carry_enter = function (self, sender, unit, carryable_unit)
	if not unit then
		return
	end

	self:trigger_event("on_carry_enter", unit, carryable_unit)
end

CarrierComponent.rpc_carry_exit = function (self, sender, unit, carryable_unit)
	if not unit then
		return
	end

	self:trigger_event("on_carry_exit", unit, carryable_unit)
	EntityAux.command_slave_immediately(unit, self.name, "exit_carry", carryable_unit)
end

CarrierComponent.game_object_sync_done = function (self, sender)
	for unit, context in self.entity_manager:all_masters_iterator(self.name) do
		local state = context.state

		if state.carry_state == "carrying" then
			local carryable_unit = state.carry_data.carryable_unit

			self:trigger_rpc_event_to(sender, "rpc_carry_enter", unit, carryable_unit)
		end
	end
end

CarrierComponent.setup_console_plugin = function (self)
	local plugin = {
		carrier = function (argument_array, command_string)
			if argument_array[2] == "draw" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Mounter draw toggled for %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_command(self, "plugin_draw", true, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		carrier = {
			"draw",
		},
	}
	local docs = {
		carrier = {
			text = "",
			draw = {
				text = "",
				usage = "",
			},
		},
	}

	return plugin, auto_complete, docs
end
