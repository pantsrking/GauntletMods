﻿-- chunkname: @lua/components/encounter_door_component.lua

require("foundation/lua/component/base_component")

EncounterDoorComponent = class("EncounterDoorComponent", "BaseComponent")

EncounterDoorComponent.init = function (self, creation_context)
	BaseComponent.init(self, "encounter_door", creation_context)
	self:register_flow_events("encounter_door_open", "encounter_door_close")
end

EncounterDoorComponent.setup_master = function (self, unit, context, setup_info)
	context.state.open = Unit.get_data(unit, "start_opened")
end

EncounterDoorComponent.setup_slave = function (self, unit, context, setup_info)
	local state = context.state

	Unit.flow_event(unit, state.open and "_instant_open" or "_instant_close")
	EntityAux.call_slave(unit, "dynamic_blocker", state.open and "unblock" or "block")

	state.previous_open = state.open
end

EncounterDoorComponent.call_master_set_open = function (self, unit, context, open)
	context.state.open = open

	self.replicator:write_fields(context)

	EntityAux._state_raw(unit, self.name).open = open
end

EncounterDoorComponent.update = function (self, dt)
	Profiler.start(self.name)

	local entities = self.entity_manager:get_slave_entities(self.name)

	for unit, context in pairs(entities) do
		local state = context.state

		if state.open ~= state.previous_open then
			Unit.flow_event(unit, state.open and "_open" or "_close")
			EntityAux.call_slave(unit, "dynamic_blocker", state.open and "unblock" or "block")

			state.previous_open = state.open
		end
	end

	Profiler.stop()
end

EncounterDoorComponent.encounter_door_open = function (self, params)
	if EntityAux.owned(params.door_unit) then
		EntityAux.call_master(params.door_unit, self.name, "set_open", true)
	end
end

EncounterDoorComponent.encounter_door_close = function (self, params)
	if EntityAux.owned(params.door_unit) then
		EntityAux.call_master(params.door_unit, self.name, "set_open", false)
	end
end

EncounterDoorComponent.setup_console_plugin = function (self)
	local plugin = {
		encounter_door = function (argument_array, command_string)
			if argument_array[2] == "open" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Encounter door opened %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_call(self, "set_open", true, target) or msg

				return msg
			elseif argument_array[2] == "close" then
				local target = argument_array[3]
				local msg = {
					message = sprintf("Encounter door closed %s.", PluginComponentAux.target_description(target)),
				}

				msg = PluginComponentAux.execute_call(self, "set_open", false, target) or msg

				return msg
			end
		end,
	}
	local auto_complete = {
		encounter_door = {
			"open",
			"close",
		},
	}
	local docs = {
		encounter_door = {
			text = "Can open / close encounter doors.",
			open = {
				text = "Opens given door(s).",
				usage = "open [go_id|all]",
			},
			close = {
				text = "Closes given door(s).",
				usage = "close [go_id|all]",
			},
		},
	}

	return plugin, auto_complete, docs
end
