﻿-- chunkname: @characters/avatar_necromagus/abilities/skeleton_heavy.lua

local DAMAGE_INNER = 25
local DAMAGE_MIDDLE = 5
local DAMAGE_OUTER = 2
local RADIUS_MIDDLE = 1.5
local RADIUS_OUTER = 2
local CLEAVE_COLLISION_ORIGIN = {
	x = 0,
	y = -0.5,
	z = 0,
}
local CLEAVE_COLLISION_HALF_EXTENTS = {
	x = 1,
	y = 1.5,
	z = 1,
}
local CLEAVE_ORIGIN = CLEAVE_COLLISION_ORIGIN
local CLEAVE_HALF_EXTENTS = CLEAVE_COLLISION_HALF_EXTENTS
local CLEAVE_EXIT_OFFSET_Y = 0.7

CLEAVE_ORIGIN.y = CLEAVE_ORIGIN.y - CLEAVE_EXIT_OFFSET_Y
CLEAVE_HALF_EXTENTS.y = CLEAVE_HALF_EXTENTS.y + CLEAVE_EXIT_OFFSET_Y

local t = SettingsAux.override_settings("characters/skeleton_base", {
	discovery_disabled = true,
	enemy_type = "skeleton_soldier",
	global_ability_cooldown = 1,
	hitpoints = 8,
	instakill_on = "nil",
	name = "loc_enemy_skeleton_soldier",
	treasure_joints = "nil",
	use_simple_mover = false,
	faction = {
		"good",
	},
	animation_merge_options = {
		clock_fidelity = 0.75,
		max_drift = 0.2,
		max_start_time = 0.2,
	},
	scale_info = {
		scale = 1.5,
		variation = 0.05,
	},
	ability_selection = {},
	abilities = {
		cleave = {
			animation = "attack_heavy",
			duration = 41,
			rotation_lock_start = 0,
			flow_events = {
				{
					event_name = "ability_attack",
					time = 16,
				},
			},
			events = {
				{
					collision_filter = "damageable_and_wall",
					event_duration = 10,
					event_start = 10,
					radius = 1,
					type = "box",
					origin = CLEAVE_COLLISION_ORIGIN,
					half_extents = CLEAVE_COLLISION_HALF_EXTENTS,
				},
				{
					behind_wall_test = "relative_caster",
					break_food = true,
					damage_type = "punch",
					event_duration = 1,
					event_start = 25,
					hit_react = "thrust",
					inherit_from = "default_event_data",
					type = "sphere",
					damage_amount = DAMAGE_OUTER,
					origin = {
						x = 0,
						y = 1,
						z = 0,
					},
					radius = RADIUS_OUTER,
				},
				{
					behind_wall_test = "relative_caster",
					event_duration = 1,
					event_start = 25,
					hit_react = "thrust",
					type = "sphere",
					damage_amount = DAMAGE_MIDDLE,
					origin = {
						x = 0,
						y = 1,
						z = 0,
					},
					radius = RADIUS_MIDDLE,
				},
				{
					behind_wall_test = "relative_caster",
					damage_type = "cleave",
					event_duration = 1,
					event_start = 25,
					execute = true,
					hit_react = "crush",
					inherit_from = "default_event_data",
					on_enter_flow = "attack_heavy_hit",
					type = "box",
					damage_amount = DAMAGE_INNER,
					origin = CLEAVE_ORIGIN,
					half_extents = CLEAVE_HALF_EXTENTS,
				},
			},
			movements = {
				{
					translation = 0.2,
					window = {
						1,
						3,
					},
				},
				{
					translation = 4.2,
					window = {
						3,
						22,
					},
				},
			},
			on_complete = {
				custom_callback = function (ability_component, unit, ability)
					if EntityAux.owned(unit) then
						ability_component.entity_spawner:despawn_entity(unit)
					end
				end,
			},
		},
		cleave_exit = {
			animation = "attack_heavy_execute",
			duration = 21,
			rotation_lock_start = 0,
			on_exit = {
				custom_callback = function (ability_component, unit, ability)
					if EntityAux.owned(unit) then
						ability_component.entity_spawner:despawn_entity(unit)
					end
				end,
			},
			flow_events = {
				{
					event_name = "ability_attack",
					time = 2,
				},
			},
			events = {
				{
					behind_wall_test = "relative_caster",
					break_food = true,
					damage_type = "punch",
					event_duration = 1,
					event_start = 5,
					hit_react = "thrust",
					inherit_from = "default_event_data",
					type = "sphere",
					damage_amount = DAMAGE_OUTER,
					origin = {
						x = 0,
						y = 1,
						z = 0,
					},
					radius = RADIUS_OUTER,
				},
				{
					behind_wall_test = "relative_caster",
					event_duration = 1,
					event_start = 5,
					hit_react = "thrust",
					type = "sphere",
					damage_amount = DAMAGE_MIDDLE,
					origin = {
						x = 0,
						y = 1,
						z = 0,
					},
					radius = RADIUS_MIDDLE,
				},
				{
					behind_wall_test = "relative_caster",
					damage_type = "cleave",
					event_duration = 1,
					event_start = 5,
					execute = true,
					hit_react = "crush",
					inherit_from = "default_event_data",
					on_enter_flow = "attack_heavy_hit",
					type = "box",
					damage_amount = DAMAGE_INNER,
					origin = CLEAVE_ORIGIN,
					half_extents = CLEAVE_HALF_EXTENTS,
				},
			},
		},
	},
})

t.on_created_by_ability = function (unit, parent_ability)
	if EntityAux.owned(unit) then
		local stat_creditor_go_id = AbilityAux.get_stat_creditor_go_id(parent_ability.owner_unit)

		Unit.set_data(unit, "stat_creditor_go_id", stat_creditor_go_id)
		EntityAux.queue_command_master(unit, "motion", "constrain_to_mover", true)
		EntityAux.queue_command_master(unit, "motion", "constrain_to_navgrid", false)
	end
end

t.states = function (component)
	local cache_component_states = closure(StateCommon.cache_component_states, component)

	return {
		setup = StateCommonBuilder.build_skip_state(component, "select_action"),
		select_action = StateCommonBuilder.build_skip_state(component, "attack"),
		attack = {
			on_enter = {
				closure(StateNecromagus.heavy_attack_enter, component),
				closure(StateCommon.attack_enter_owned, component),
			},
			pre_transitions = {},
			update = {
				closure(StateNecromagus.update_heavy, component),
				closure(StateCommon.rotate_towards_target, component),
			},
			post_transitions = {},
			on_exit = {},
		},
	}, cache_component_states
end

return t
